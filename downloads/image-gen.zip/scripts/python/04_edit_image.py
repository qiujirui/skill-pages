#!/usr/bin/env python3
"""
04_edit_image.py - 图片编辑（Images Edits）

功能：基于已有图片进行编辑，支持单图编辑和多图合成。

用法：
    # 单图编辑
    python 04_edit_image.py input.png "将背景改为星空"

    # 多图合成
    python 04_edit_image.py img1.png img2.png "合成一张海报"

    # 指定输出尺寸
    python 04_edit_image.py input.png "编辑指令" 960x2112

    # 指定模型和前缀
    python 04_edit_image.py input.png "指令" --model=gpt-image-2 --prefix=poster

输出：
    - 编辑图片保存到 prefix_时间戳.png
    - 响应详情保存到 edit_response.json

依赖：仅使用 Python 标准库，无需安装任何第三方包。
"""

import urllib.request
import urllib.error
import base64
import os
import sys
import json
import mimetypes
from datetime import datetime

# Windows 控制台 UTF-8 支持
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# ==================== 配置区（修改这里）====================
API_KEY = os.getenv("LITELLM_API_KEY", "sk-self-你的APIKey")
BASE_URL = os.getenv("LITELLM_BASE_URL", "http://10.225.9.142:31888/api/v1")
MODEL = os.getenv("LITELLM_IMAGE_MODEL", "gpt-image-2")
DEFAULT_QUALITY = "medium"
# ==========================================================


def generate_multipart_body(files: list, fields: dict, boundary: str) -> bytes:
    """
    构建 multipart/form-data 请求体

    Args:
        files: [(name, filepath), ...]
        fields: {name: value, ...}
        boundary: 边界字符串

    Returns:
        请求体字节
    """
    body_lines = []
    CRLF = b'\r\n'
    
    # 添加普通字段
    for name, value in fields.items():
        body_lines.append(b'--' + boundary.encode())
        body_lines.append(f'Content-Disposition: form-data; name="{name}"'.encode())
        body_lines.append(b'')
        body_lines.append(str(value).encode('utf-8'))
    
    # 添加文件
    for name, filepath in files:
        filename = os.path.basename(filepath)
        
        # 推断 MIME 类型
        mime_type, _ = mimetypes.guess_type(filepath)
        if mime_type is None:
            mime_type = 'application/octet-stream'
        
        body_lines.append(b'--' + boundary.encode())
        body_lines.append(
            f'Content-Disposition: form-data; name="{name}"; filename="{filename}"'.encode()
        )
        body_lines.append(f'Content-Type: {mime_type}'.encode())
        body_lines.append(b'')
        
        # 读取文件内容
        with open(filepath, 'rb') as f:
            body_lines.append(f.read())
    
    # 结束边界
    body_lines.append(b'--' + boundary.encode() + b'--')
    body_lines.append(b'')
    
    return CRLF.join(body_lines)


def edit_image(image_paths: list, prompt: str, size: str = None, quality: str = None, model: str = None) -> bytes:
    """
    调用图片编辑接口

    Args:
        image_paths: 图片路径列表
        prompt: 编辑指令
        size: 输出尺寸（如 "1024x1024"）
        quality: 质量 low/medium/high
        model: 模型名称

    Returns:
        图片二进制数据（PNG 格式）
    """
    url = f"{BASE_URL.rstrip('/')}/images/edits"
    
    # 构建 multipart 请求
    boundary = '----PythonFormBoundary' + datetime.now().strftime('%Y%m%d%H%M%S')
    
    # 文件列表
    files = [('image', path) for path in image_paths]
    
    # 表单字段
    fields = {
        'prompt': prompt,
        'model': model or MODEL,
    }
    if size:
        fields['size'] = size
    if quality:
        fields['quality'] = quality
    
    body = generate_multipart_body(files, fields, boundary)
    
    req = urllib.request.Request(url, data=body, method='POST')
    req.add_header("Authorization", f"Bearer {API_KEY}")
    req.add_header("Content-Type", f"multipart/form-data; boundary={boundary}")
    
    print(f"[生成] 正在编辑图片...（约需 150~300 秒）")
    
    with urllib.request.urlopen(req, timeout=360) as resp:
        result = json.loads(resp.read().decode('utf-8'))
    
    # 保存原始响应
    with open("edit_response.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    
    # 解码 Base64
    try:
        b64_data = result["data"][0]["b64_json"]
        img_bytes = base64.b64decode(b64_data)
    except (KeyError, IndexError) as e:
        raise ValueError(f"响应中未找到图片数据：{e}")
    
    print(f"[OK] 编辑完成，图片大小：{len(img_bytes) / 1024:.1f} KB")
    return img_bytes


def generate_filename(prefix: str = "edit") -> str:
    """生成带时间戳的文件名"""
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    return f"{prefix}_{timestamp}.png"


def main():
    # 解析命令行参数
    # 用法: python 04_edit_image.py <图片> [更多图片...] "指令" [尺寸] [--model=xxx] [--prefix=关键词]
    args = sys.argv[1:]
    
    # 扫描 --model 和 --prefix 参数
    model = MODEL
    prefix = "edit"
    size = None
    filtered_args = []
    
    for arg in args:
        if arg.startswith("--model="):
            model = arg.split("=", 1)[1]
        elif arg.startswith("--prefix="):
            prefix = arg.split("=", 1)[1]
        else:
            filtered_args.append(arg)
    args = filtered_args
    
    if len(args) < 1:
        print("用法: python 04_edit_image.py <图片> [更多图片...] \"指令\" [尺寸]")
        sys.exit(1)
    
    # 尝试解析参数
    # 最后一个参数如果是尺寸（如 960x2112），则倒数第二个是 prompt
    # 否则最后一个参数是 prompt
    if len(args) >= 2 and args[-1].lower().replace('x', '').isdigit():
        size = args[-1]
        prompt = args[-2]
        image_paths = args[:-2]
    else:
        # 最后一个参数是 prompt，前面都是图片
        prompt = args[-1]
        image_paths = args[:-1]
    
    # 验证图片文件存在
    for path in image_paths:
        if not os.path.exists(path):
            print(f"[ERR] 图片文件不存在：{path}")
            sys.exit(1)
    
    print(f"[图片] {len(image_paths)} 张")
    for i, path in enumerate(image_paths):
        print(f"       {i+1}. {path}")
    print(f"[指令] {prompt}")
    print(f"[模型] {model}")
    if size:
        print(f"[尺寸] {size}")
    
    try:
        img_data = edit_image(image_paths, prompt, size=size, quality=DEFAULT_QUALITY, model=model)
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8')
        print(f"[ERR] 请求失败（{e.code}）：{error_body}")
        sys.exit(1)
    except urllib.error.URLError as e:
        print(f"[ERR] 连接失败：{e.reason}")
        sys.exit(1)
    except Exception as e:
        print(f"[ERR] 错误：{e}")
        sys.exit(1)
    
    # 保存图片
    output_path = generate_filename(prefix)
    with open(output_path, "wb") as f:
        f.write(img_data)
    print(f"[保存] 图片已保存：{os.path.abspath(output_path)}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
01_check_quota.py - 查询额度与验证 API Key

功能：验证 API Key 有效性，查询剩余额度、已用额度、可用模型列表。

用法：
    python 01_check_quota.py

输出示例：
    [OK] API Key 有效
    [额度] 已用 5,000 / 总额 100,000（剩余 95,000）
    [模型] 可用模型：
       - gpt-5.4-mini（文本对话）
       - gpt-image-2（图像生成）

依赖：仅使用 Python 标准库，无需安装任何第三方包。
"""

import urllib.request
import urllib.error
import os
import sys
import json

# Windows 控制台 UTF-8 支持
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# ==================== 配置区（修改这里）====================
API_KEY = os.getenv("LITELLM_API_KEY", "sk-self-你的APIKey")
BASE_URL = os.getenv("LITELLM_BASE_URL", "http://10.225.9.142:31888/api/v1")
# ==========================================================


def check_quota():
    """查询额度并打印结果"""
    url = f"{BASE_URL.rstrip('/')}/quota"
    
    # 构建请求
    req = urllib.request.Request(url)
    req.add_header("Authorization", f"Bearer {API_KEY}")
    
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode('utf-8'))
    except urllib.error.URLError as e:
        print(f"[ERR] 连接失败：{e.reason}")
        print("      请检查后端服务是否已启动，或 BASE_URL 是否正确。")
        sys.exit(1)
    except urllib.error.HTTPError as e:
        if e.code == 401:
            print("[ERR] API Key 无效（401）")
        elif e.code == 403:
            print("[ERR] API Key 已停用（403）")
        else:
            error_body = e.read().decode('utf-8')
            print(f"[ERR] 请求失败（{e.code}）：{error_body}")
        sys.exit(1)

    total = data.get("total_quota", 0)
    used = data.get("used_quota", 0)
    remaining = data.get("remaining_quota", 0)
    models = data.get("models", [])

    print("[OK] API Key 有效")
    print(f"[额度] 已用 {used:,} / 总额 {total:,}（剩余 {remaining:,}）")

    if models:
        print("[模型] 可用模型：")
        for m in models:
            mtype = m.get("model_type", "unknown")
            name = m.get("model_id", "unknown")
            type_label = "文本对话" if mtype == "text" else "图像生成" if mtype == "image" else mtype
            print(f"   - {name}（{type_label}）")
    else:
        print("[WARN] 未返回模型列表")

    return data


if __name__ == "__main__":
    check_quota()

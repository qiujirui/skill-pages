#!/usr/bin/env python3
"""
03_generate_image.py - 文生图（Images Generations）

功能：根据文字描述生成图片，自动处理尺寸合规（16 倍数），自动解码 Base64 保存为 PNG。

用法：
    # 直接运行（使用默认参数）
    python 03_generate_image.py

    # 命令行指定参数
    python 03_generate_image.py "一只在草地上奔跑的金毛犬" 1024 1024 medium

    # 只改 prompt
    python 03_generate_image.py "futuristic city at night"

    # 指定模型和前缀
    python 03_generate_image.py "prompt" 1024 1024 medium --model=gpt-image-2 --prefix=city

输出：
    - 生成图片保存到 prefix_时间戳.png
    - 响应详情保存到 image_response.json

依赖：仅使用 Python 标准库，无需安装任何第三方包。
"""

import urllib.request
import urllib.error
import base64
import os
import sys
import json
import math
from datetime import datetime

# Windows 控制台 UTF-8 支持
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# ==================== 配置区（修改这里）====================
API_KEY = os.getenv("LITELLM_API_KEY", "sk-self-你的APIKey")
BASE_URL = os.getenv("LITELLM_BASE_URL", "http://10.225.9.142:31888/api/v1")
MODEL = os.getenv("LITELLM_IMAGE_MODEL", "gpt-image-2")

# 默认参数
DEFAULT_PROMPT = "A serene Chinese landscape painting with mountains, misty rivers, and pine trees, traditional ink wash style"
DEFAULT_WIDTH = 1024
DEFAULT_HEIGHT = 1024
DEFAULT_QUALITY = "medium"
# ==========================================================

# 尺寸约束常量
MIN_PIXELS = 655_360
MAX_PIXELS = 8_294_400


def align_to_16(value: int) -> int:
    """向上对齐到 16 的倍数"""
    return ((value + 15) // 16) * 16


def validate_size(width: int, height: int) -> tuple:
    """
    校验并调整尺寸，确保满足所有约束：
    1. 宽高为 16 的倍数
    2. 总像素在 [655,360, 8,294,400] 范围内
    3. 单维度不低于 816

    Returns:
        (adjusted_width, adjusted_height)
    """
    w = align_to_16(width)
    h = align_to_16(height)

    # 确保不低于最小维度
    w = max(w, 816)
    h = max(h, 816)

    total = w * h

    if total > MAX_PIXELS:
        # 超出上限，等比例缩小
        scale = math.sqrt(MAX_PIXELS / total)
        w = align_to_16(int(w * scale))
        h = align_to_16(int(h * scale))
        print(f"[WARN] 像素超出上限，已自动缩小到 {w}x{h}")
    elif total < MIN_PIXELS:
        # 低于下限，等比例放大
        scale = math.sqrt(MIN_PIXELS / total)
        w = align_to_16(int(w * scale))
        h = align_to_16(int(h * scale))
        print(f"[WARN] 像素低于下限，已自动放大到 {w}x{h}")

    return w, h


def size_from_ratio(ratio: str, target_pixels: int = 2_000_000) -> tuple:
    """
    根据宽高比例计算推荐尺寸

    Args:
        ratio: 比例字符串，如 "16:9", "9:16", "1:1", "4:3"
        target_pixels: 目标总像素（默认 200 万）

    Returns:
        (width, height)
    """
    w_ratio, h_ratio = map(int, ratio.split(':'))
    base = math.sqrt(target_pixels / (w_ratio * h_ratio))
    return validate_size(int(base * w_ratio), int(base * h_ratio))


def generate_image(prompt: str, width: int, height: int, quality: str, model: str = None) -> bytes:
    """
    调用文生图接口

    Args:
        prompt: 图片描述
        width, height: 期望尺寸（会被自动调整为合规值）
        quality: 质量 low/medium/high
        model: 模型名称，默认使用全局 MODEL

    Returns:
        图片二进制数据（PNG 格式）
    """
    # 1. 尺寸合规处理
    w, h = validate_size(width, height)
    if (w, h) != (width, height):
        print(f"[尺寸] 调整：{width}x{height} -> {w}x{h}（16 倍数 + 像素范围合规）")
    else:
        print(f"[尺寸] 使用：{w}x{h}")

    # 2. 构建请求
    url = f"{BASE_URL.rstrip('/')}/images/generations"
    payload = {
        "model": model or MODEL,
        "prompt": prompt,
        "size": f"{w}x{h}",
        "quality": quality,
        "n": 1,
    }
    
    body = json.dumps(payload, ensure_ascii=False).encode('utf-8')
    
    req = urllib.request.Request(url, data=body, method='POST')
    req.add_header("Authorization", f"Bearer {API_KEY}")
    req.add_header("Content-Type", "application/json; charset=utf-8")
    
    print(f"[生成] 正在生成图片...（quality={quality}，约需 47~250 秒）")

    # 3. 发送请求（长超时）
    with urllib.request.urlopen(req, timeout=360) as resp:
        result = json.loads(resp.read().decode('utf-8'))

    # 4. 保存原始响应
    with open("image_response.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    # 5. 解码 Base64
    try:
        b64_data = result["data"][0]["b64_json"]
        img_bytes = base64.b64decode(b64_data)
    except (KeyError, IndexError) as e:
        raise ValueError(f"响应中未找到图片数据：{e}")

    print(f"[OK] 生成完成，图片大小：{len(img_bytes) / 1024:.1f} KB")
    return img_bytes


def generate_filename(prefix: str = "image") -> str:
    """生成带时间戳的文件名"""
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    return f"{prefix}_{timestamp}.png"


def main():
    # 解析命令行参数
    # 用法: python 03_generate_image.py "prompt" [width] [height] [quality] [--model=xxx] [--prefix=关键词]
    args = sys.argv[1:]

    # 扫描 --model 和 --prefix 参数
    model = MODEL
    prefix = "image"
    filtered_args = []
    for arg in args:
        if arg.startswith("--model="):
            model = arg.split("=", 1)[1]
        elif arg.startswith("--prefix="):
            prefix = arg.split("=", 1)[1]
        else:
            filtered_args.append(arg)
    args = filtered_args

    if len(args) > 0:
        prompt = args[0]
    else:
        prompt = DEFAULT_PROMPT

    if len(args) > 2:
        width = int(args[1])
        height = int(args[2])
    else:
        width, height = DEFAULT_WIDTH, DEFAULT_HEIGHT

    if len(args) > 3:
        quality = args[3]
    else:
        quality = DEFAULT_QUALITY

    print(f"[Prompt] {prompt}")
    print(f"[Model] {model}")
    print(f"[Quality] {quality}")

    try:
        img_data = generate_image(prompt, width, height, quality, model=model)
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8')
        print(f"[ERR] 请求失败（{e.code}）：{error_body}")
        sys.exit(1)
    except urllib.error.URLError as e:
        print(f"[ERR] 连接失败：{e.reason}")
        sys.exit(1)
    except Exception as e:
        print(f"[ERR] 错误：{e}")
        sys.exit(1)

    # 保存图片
    output_path = generate_filename(prefix)
    with open(output_path, "wb") as f:
        f.write(img_data)
    print(f"[保存] 图片已保存：{os.path.abspath(output_path)}")


if __name__ == "__main__":
    main()

#!/bin/bash
# 01_check_quota.sh - 验证 API Key 并查询额度
# 用法: ./01_check_quota.sh [-k "sk-self-xxx"] [-u "http://10.225.9.142:31888/api/v1"]
# 依赖: curl, jq

set -e

API_KEY="${LITELLM_API_KEY:-}"
BASE_URL="http://10.225.9.142:31888/api/v1"

# 解析参数
while getopts "k:u:" opt; do
    case $opt in
        k) API_KEY="$OPTARG" ;;
        u) BASE_URL="$OPTARG" ;;
        *) echo "用法: $0 [-k API_KEY] [-u BASE_URL]"; exit 1 ;;
    esac
done

# 尝试从配置文件读取 API Key
if [ -z "$API_KEY" ]; then
    CONFIG_PATH="$HOME/.litellm/config.json"
    if [ -f "$CONFIG_PATH" ]; then
        API_KEY=$(jq -r '.api_key // empty' "$CONFIG_PATH" 2>/dev/null)
    fi
fi

if [ -z "$API_KEY" ]; then
    CONFIG_PATH="$HOME/.workbuddy/skills/litellm-gateway-user/config.json"
    if [ -f "$CONFIG_PATH" ]; then
        API_KEY=$(jq -r '.api_key // empty' "$CONFIG_PATH" 2>/dev/null)
        BASE_URL=$(jq -r '.base_url // "'"$BASE_URL"'"' "$CONFIG_PATH" 2>/dev/null)
    fi
fi

if [ -z "$API_KEY" ]; then
    echo '{"error": "NO_API_KEY", "message": "未找到 API Key，请先自助申请"}'
    exit 1
fi

# 发送请求
RESPONSE=$(curl -s -w "\n%{http_code}" -X GET "$BASE_URL/quota" \
    -H "Authorization: Bearer $API_KEY" \
    -H "Content-Type: application/json")

HTTP_CODE=$(echo "$RESPONSE" | tail -n1)
BODY=$(echo "$RESPONSE" | sed '$d')

if [ "$HTTP_CODE" = "200" ]; then
    echo "$BODY" | jq '{
        status: "OK",
        api_key_valid: true,
        total_quota: .total_quota,
        used_quota: .used_quota,
        remaining_quota: .remaining_quota,
        models: .models
    }'
elif [ "$HTTP_CODE" = "401" ]; then
    echo '{"error": "INVALID_KEY", "message": "API Key 无效，请重新申请"}'
    exit 1
elif [ "$HTTP_CODE" = "403" ]; then
    echo '{"error": "KEY_DISABLED", "message": "API Key 已停用或额度不足"}'
    exit 1
else
    echo "{\"error\": \"REQUEST_FAILED\", \"message\": \"HTTP $HTTP_CODE: $BODY\"}"
    exit 1
fi

#!/bin/bash
# 04_edit_image.sh - 图片编辑（多图 + 参考图合成）
# 用法: ./04_edit_image.sh -p "编辑指令" -i "img1.png,img2.png" -w 1728 -h 3072 -q "high"
# 依赖: curl, jq
# 注意: 使用 curl 构建 multipart，支持多图上传

set -e

API_KEY="${LITELLM_API_KEY:-}"
BASE_URL="http://10.225.9.142:31888/api/v1"
PROMPT=""
IMAGES=""
WIDTH=1088
HEIGHT=1920
QUALITY="medium"
MODEL="gpt-image-2"
PREFIX="edited"

# 解析参数
while getopts "p:i:w:h:q:m:x:k:u:o:" opt; do
    case $opt in
        p) PROMPT="$OPTARG" ;;
        i) IMAGES="$OPTARG" ;;
        w) WIDTH="$OPTARG" ;;
        h) HEIGHT="$OPTARG" ;;
        q) QUALITY="$OPTARG" ;;
        m) MODEL="$OPTARG" ;;
        x) PREFIX="$OPTARG" ;;
        k) API_KEY="$OPTARG" ;;
        u) BASE_URL="$OPTARG" ;;
        o) OUTPUT_DIR="$OPTARG" ;;
        *) echo "用法: $0 -p PROMPT -i IMAGES [-w WIDTH] [-h HEIGHT] [-q QUALITY]"; exit 1 ;;
    esac
done

if [ -z "$PROMPT" ]; then
    echo '{"error": "NO_PROMPT"}'
    exit 1
fi

if [ -z "$IMAGES" ]; then
    echo '{"error": "NO_IMAGES"}'
    exit 1
fi

# 尝试从配置文件读取 API Key
if [ -z "$API_KEY" ]; then
    CONFIG_PATH="$HOME/.litellm/config.json"
    if [ -f "$CONFIG_PATH" ]; then
        API_KEY=$(jq -r '.api_key // empty' "$CONFIG_PATH" 2>/dev/null)
    fi
fi

if [ -z "$API_KEY" ]; then
    CONFIG_PATH="$HOME/.workbuddy/skills/litellm-gateway-user/config.json"
    if [ -f "$CONFIG_PATH" ]; then
        API_KEY=$(jq -r '.api_key // empty' "$CONFIG_PATH" 2>/dev/null)
        BASE_URL=$(jq -r '.base_url // "'"$BASE_URL"'"' "$CONFIG_PATH" 2>/dev/null)
    fi
fi

if [ -z "$API_KEY" ]; then
    echo '{"error": "NO_API_KEY"}'
    exit 1
fi

OUTPUT_DIR="${OUTPUT_DIR:-$(pwd)}"

# 尺寸自动对齐到 16 的倍数
ALIGN_16() {
    echo $(($1 / 16 * 16))
}

WIDTH=$(ALIGN_16 $WIDTH)
HEIGHT=$(ALIGN_16 $HEIGHT)

# 检查图片文件
IFS=',' read -ra IMG_ARRAY <<< "$IMAGES"
for IMG in "${IMG_ARRAY[@]}"; do
    if [ ! -f "$IMG" ]; then
        echo '{"error": "FILE_NOT_FOUND", "message": "'"$IMG"'"}'
        exit 1
    fi
done

TIMESTAMP=$(date +%Y%m%d%H%M%S)
OUT_FILE="${PREFIX}_${TIMESTAMP}.png"

echo "[INFO] 发送请求: ${WIDTH}x${HEIGHT}, quality=$QUALITY"
echo "[INFO] 参考图: $IMAGES"

# 构建 curl multipart 请求
CURL_ARGS=()
for IMG in "${IMG_ARRAY[@]}"; do
    CURL_ARGS+=(-F "image=@$IMG;type=image/png")
done

RESPONSE=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/images/edits" \
    -H "Authorization: Bearer $API_KEY" \
    -F "model=$MODEL" \
    -F "prompt=$PROMPT" \
    -F "size=${WIDTH}x${HEIGHT}" \
    -F "quality=$QUALITY" \
    "${CURL_ARGS[@]}" \
    --max-time 480)

HTTP_CODE=$(echo "$RESPONSE" | tail -n1)
BODY=$(echo "$RESPONSE" | sed '$d')

if [ "$HTTP_CODE" = "200" ]; then
    # 解码 Base64
    B64_JSON=$(echo "$BODY" | jq -r '.data[0].b64_json')
    OUT_PATH="$OUTPUT_DIR/$OUT_FILE"
    echo "$B64_JSON" | base64 -d > "$OUT_PATH"
    
    FILE_SIZE=$(stat -f%z "$OUT_PATH" 2>/dev/null || stat -c%s "$OUT_PATH" 2>/dev/null)
    FILE_SIZE_KB=$((FILE_SIZE / 1024))
    
    INPUT_TOKENS=$(echo "$BODY" | jq -r '.usage.input_tokens // 0')
    OUTPUT_TOKENS=$(echo "$BODY" | jq -r '.usage.output_tokens // 0')
    TOTAL_TOKENS=$(echo "$BODY" | jq -r '.usage.total_tokens // 0')
    
    jq -n \
        --arg status "OK" \
        --arg output "$OUT_PATH" \
        --arg size "${WIDTH}x${HEIGHT}" \
        --arg quality "$QUALITY" \
        --argjson file_size "$FILE_SIZE_KB" \
        --argjson input_tokens "$INPUT_TOKENS" \
        --argjson output_tokens "$OUTPUT_TOKENS" \
        --argjson total_tokens "$TOTAL_TOKENS" \
        '{status: $status, output_path: $output, size: $size, quality: $quality, file_size_kb: $file_size, input_tokens: $input_tokens, output_tokens: $output_tokens, total_tokens: $total_tokens}'
    
elif [ "$HTTP_CODE" = "401" ]; then
    echo '{"error": "INVALID_KEY"}'
    exit 1
elif [ "$HTTP_CODE" = "403" ]; then
    echo '{"error": "QUOTA_INSUFFICIENT"}'
    exit 1
elif [ "$HTTP_CODE" = "413" ]; then
    echo '{"error": "REQUEST_TOO_LARGE", "message": "参考图片太大"}'
    exit 1
else
    echo "{\"error\": \"REQUEST_FAILED\", \"message\": \"HTTP $HTTP_CODE: $BODY\"}"
    exit 1
fi
#!/bin/bash
# 03_generate_image.sh - 文生图（Text-to-Image）
# 用法: ./03_generate_image.sh -p "提示词" -w 1088 -h 1920 -q "low" -x "output"
# 依赖: curl, jq, base64
# 输出: 生成的 PNG 图片到当前目录

set -e

API_KEY="${LITELLM_API_KEY:-}"
BASE_URL="http://10.225.9.142:31888/api/v1"
PROMPT=""
WIDTH=1024
HEIGHT=1024
QUALITY="low"
MODEL="gpt-image-2"
PREFIX="generated"

# 解析参数
while getopts "p:w:h:q:m:x:k:u:o:" opt; do
    case $opt in
        p) PROMPT="$OPTARG" ;;
        w) WIDTH="$OPTARG" ;;
        h) HEIGHT="$OPTARG" ;;
        q) QUALITY="$OPTARG" ;;
        m) MODEL="$OPTARG" ;;
        x) PREFIX="$OPTARG" ;;
        k) API_KEY="$OPTARG" ;;
        u) BASE_URL="$OPTARG" ;;
        o) OUTPUT_DIR="$OPTARG" ;;
        *) echo "用法: $0 -p PROMPT [-w WIDTH] [-h HEIGHT] [-q QUALITY] [-x PREFIX]"; exit 1 ;;
    esac
done

if [ -z "$PROMPT" ]; then
    echo '{"error": "NO_PROMPT", "message": "必须提供提示词"}'
    exit 1
fi

# 尝试从配置文件读取 API Key
if [ -z "$API_KEY" ]; then
    CONFIG_PATH="$HOME/.litellm/config.json"
    if [ -f "$CONFIG_PATH" ]; then
        API_KEY=$(jq -r '.api_key // empty' "$CONFIG_PATH" 2>/dev/null)
    fi
fi

if [ -z "$API_KEY" ]; then
    CONFIG_PATH="$HOME/.workbuddy/skills/litellm-gateway-user/config.json"
    if [ -f "$CONFIG_PATH" ]; then
        API_KEY=$(jq -r '.api_key // empty' "$CONFIG_PATH" 2>/dev/null)
        BASE_URL=$(jq -r '.base_url // "'"$BASE_URL"'"' "$CONFIG_PATH" 2>/dev/null)
    fi
fi

if [ -z "$API_KEY" ]; then
    echo '{"error": "NO_API_KEY"}'
    exit 1
fi

# 默认输出目录
OUTPUT_DIR="${OUTPUT_DIR:-$(pwd)}"

# 尺寸自动对齐到 16 的倍数
ALIGN_16() {
    echo $(($1 / 16 * 16))
}

WIDTH=$(ALIGN_16 $WIDTH)
HEIGHT=$(ALIGN_16 $HEIGHT)

# 检查像素范围
TOTAL_PIXELS=$((WIDTH * HEIGHT))
if [ $TOTAL_PIXELS -lt 655360 ]; then
    echo '{"error": "SIZE_TOO_SMALL", "message": "总像素不能低于 655360"}'
    exit 1
fi
if [ $TOTAL_PIXELS -gt 8294400 ]; then
    echo '{"error": "SIZE_TOO_LARGE", "message": "总像素不能超过 8294400"}'
    exit 1
fi

TIMESTAMP=$(date +%Y%m%d%H%M%S)
OUT_FILE="${PREFIX}_${TIMESTAMP}.png"

echo "[INFO] 发送请求: ${WIDTH}x${HEIGHT}, quality=$QUALITY"
echo "[INFO] 提示词: $PROMPT"

# 构建 JSON body
JSON_BODY=$(jq -n \
    --arg model "$MODEL" \
    --arg prompt "$PROMPT" \
    --arg size "${WIDTH}x${HEIGHT}" \
    --arg quality "$QUALITY" \
    '{model: $model, prompt: $prompt, size: $size, quality: $quality, n: 1}')

# 发送请求
RESPONSE=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/images/generations" \
    -H "Authorization: Bearer $API_KEY" \
    -H "Content-Type: application/json; charset=utf-8" \
    -d "$JSON_BODY" \
    --max-time 360)

HTTP_CODE=$(echo "$RESPONSE" | tail -n1)
BODY=$(echo "$RESPONSE" | sed '$d')

if [ "$HTTP_CODE" = "200" ]; then
    # 解码 Base64
    B64_JSON=$(echo "$BODY" | jq -r '.data[0].b64_json')
    OUT_PATH="$OUTPUT_DIR/$OUT_FILE"
    echo "$B64_JSON" | base64 -d > "$OUT_PATH"
    
    FILE_SIZE=$(stat -f%z "$OUT_PATH" 2>/dev/null || stat -c%s "$OUT_PATH" 2>/dev/null)
    FILE_SIZE_KB=$((FILE_SIZE / 1024))
    
    INPUT_TOKENS=$(echo "$BODY" | jq -r '.usage.input_tokens // 0')
    OUTPUT_TOKENS=$(echo "$BODY" | jq -r '.usage.output_tokens // 0')
    TOTAL_TOKENS=$(echo "$BODY" | jq -r '.usage.total_tokens // 0')
    
    jq -n \
        --arg status "OK" \
        --arg output "$OUT_PATH" \
        --arg size "${WIDTH}x${HEIGHT}" \
        --arg quality "$QUALITY" \
        --argjson file_size "$FILE_SIZE_KB" \
        --argjson input_tokens "$INPUT_TOKENS" \
        --argjson output_tokens "$OUTPUT_TOKENS" \
        --argjson total_tokens "$TOTAL_TOKENS" \
        '{status: $status, output_path: $output, size: $size, quality: $quality, file_size_kb: $file_size, input_tokens: $input_tokens, output_tokens: $output_tokens, total_tokens: $total_tokens}'
    
elif [ "$HTTP_CODE" = "401" ]; then
    echo '{"error": "INVALID_KEY", "message": "API Key 无效"}'
    exit 1
elif [ "$HTTP_CODE" = "403" ]; then
    echo '{"error": "QUOTA_INSUFFICIENT", "message": "额度不足"}'
    exit 1
else
    echo "{\"error\": \"REQUEST_FAILED\", \"message\": \"HTTP $HTTP_CODE\"}"
    exit 1
fi
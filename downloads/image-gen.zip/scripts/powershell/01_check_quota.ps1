# 01_check_quota.ps1 - 验证 API Key 并查询额度
# 用法: .\01_check_quota.ps1 [-ApiKey "sk-self-xxx"] [-BaseUrl "http://10.225.9.142:31888/api/v1"]
# 返回: JSON 格式的额度信息

param(
    [string]$ApiKey = "",
    [string]$BaseUrl = "http://10.225.9.142:31888/api/v1"
)

# 输出 UTF-8 编码
$OutputEncoding = [System.Text.Encoding]::UTF8

# 尝试从多个位置读取 API Key
if ($ApiKey -eq "") {
    # 1. 环境变量
    $ApiKey = $env:LITELLM_API_KEY
    if ($ApiKey -eq "") {
        # 2. ~/.litellm/config.json
        $configPath1 = Join-Path $env:USERPROFILE ".litellm" "config.json"
        if (Test-Path $configPath1) {
            $config = Get-Content $configPath1 | ConvertFrom-Json
            $ApiKey = $config.api_key
        }
    }
    if ($ApiKey -eq "") {
        # 3. ~/.workbuddy/skills/litellm-gateway-user/config.json
        $configPath2 = Join-Path $env:USERPROFILE ".workbuddy" "skills" "litellm-gateway-user" "config.json"
        if (Test-Path $configPath2) {
            $config = Get-Content $configPath2 | ConvertFrom-Json
            $ApiKey = $config.api_key
            if ($config.base_url) { $BaseUrl = $config.base_url }
        }
    }
}

if ($ApiKey -eq "") {
    Write-Output '{"error": "NO_API_KEY", "message": "未找到 API Key，请先自助申请"}'
    exit 1
}

$headers = @{ Authorization = "Bearer $ApiKey" }

try {
    $resp = Invoke-RestMethod -Uri "$BaseUrl/quota" `
        -Headers $headers -Method Get -TimeoutSec 10

    # 构建输出
    $result = @{
        status = "OK"
        api_key_valid = $true
        total_quota = $resp.total_quota
        used_quota = $resp.used_quota
        remaining_quota = $resp.remaining_quota
        models = $resp.models
    }
    Write-Output ($result | ConvertTo-Json -Depth 3)

} catch {
    $statusCode = $_.Exception.Response.StatusCode.value__
    if ($statusCode -eq 401) {
        Write-Output '{"error": "INVALID_KEY", "message": "API Key 无效，请重新申请"}'
    } elseif ($statusCode -eq 403) {
        Write-Output '{"error": "KEY_DISABLED", "message": "API Key 已停用或额度不足"}'
    } else {
        Write-Output '{"error": "REQUEST_FAILED", "message": "' + $_.Exception.Message + '"}'
    }
    exit 1
}
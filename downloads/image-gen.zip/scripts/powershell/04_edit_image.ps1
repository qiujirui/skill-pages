# 04_edit_image.ps1 - 图片编辑（多图 + 参考图合成）
# 用法: .\04_edit_image.ps1 -Prompt "编辑指令" -Images @("D:\img1.png","D:\img2.png") -Width 1728 -Height 3072 -Quality "high" -Prefix "edited"
# 注意: 使用 [System.Net.WebRequest] 手动构建 multipart，兼容 PowerShell 5.1

param(
    [Parameter(Mandatory=$true)]
    [string]$Prompt,

    [Parameter(Mandatory=$true)]
    [string[]]$Images,

    [int]$Width = 1088,
    [int]$Height = 1920,

    [ValidateSet("low", "medium", "high")]
    [string]$Quality = "medium",

    [string]$Model = "gpt-image-2",

    [string]$Prefix = "edited",

    [string]$ApiKey = "",

    [string]$BaseUrl = "http://10.225.9.142:31888/api/v1",

    [string]$OutputDir = ""
)

$OutputEncoding = [System.Text.Encoding]::UTF8

# 读取 API Key
if ($ApiKey -eq "") {
    $ApiKey = $env:LITELLM_API_KEY
    if ($ApiKey -eq "") {
        $configPath1 = Join-Path $env:USERPROFILE ".litellm" "config.json"
        if (Test-Path $configPath1) {
            $config = Get-Content $configPath1 | ConvertFrom-Json
            $ApiKey = $config.api_key
        }
    }
    if ($ApiKey -eq "") {
        $configPath2 = Join-Path $env:USERPROFILE ".workbuddy" "skills" "litellm-gateway-user" "config.json"
        if (Test-Path $configPath2) {
            $config = Get-Content $configPath2 | ConvertFrom-Json
            $ApiKey = $config.api_key
            if ($config.base_url) { $BaseUrl = $config.base_url }
        }
    }
}

if ($ApiKey -eq "") {
    Write-Output '{"error": "NO_API_KEY"}'
    exit 1
}

if ($OutputDir -eq "") {
    $OutputDir = $PWD.Path
}

# 尺寸自动对齐到 16 的倍数
function Align-16([int]$value) {
    return [Math]::Floor($value / 16) * 16
}

$Width = Align-16 $Width
$Height = Align-16 $Height

# 检查图片是否存在
foreach ($imgPath in $Images) {
    if (-not (Test-Path $imgPath)) {
        Write-Output '{"error": "FILE_NOT_FOUND", "message": "' + $imgPath + '"}'
        exit 1
    }
}

# ==================== 构建 multipart 请求体 ====================
$boundary = "----FormBoundary" + [DateTime]::Now.Ticks.ToString("x")
$url = "$BaseUrl/images/edits"
$memStream = New-Object System.IO.MemoryStream

# 辅助函数：添加文本字段
function Add-TextField($stream, $boundary, $name, $value) {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes(
        "--$boundary`r`nContent-Disposition: form-data; name=`"$name`"`r`n`r`n$value`r`n"
    )
    $stream.Write($bytes, 0, $bytes.Length)
}

# 辅助函数：添加文件字段
function Add-FileField($stream, $boundary, $name, $filename, $fileBytes) {
    $header = "--$boundary`r`nContent-Disposition: form-data; name=`"$name`"; filename=`"$filename`"`r`nContent-Type: image/png`r`n`r`n"
    $headerBytes = [System.Text.Encoding]::UTF8.GetBytes($header)
    $stream.Write($headerBytes, 0, $headerBytes.Length)
    $stream.Write($fileBytes, 0, $fileBytes.Length)
    $stream.Write([System.Text.Encoding]::UTF8.GetBytes("`r`n"), 0, 2)
}

# 添加文本字段
Add-TextField $memStream $boundary "model" $Model
Add-TextField $memStream $boundary "prompt" $Prompt
Add-TextField $memStream $boundary "size" "${Width}x${Height}"
Add-TextField $memStream $boundary "quality" $Quality

# 添加图片文件
foreach ($imgPath in $Images) {
    $filename = Split-Path $imgPath -Leaf
    $fileBytes = [System.IO.File]::ReadAllBytes($imgPath)
    Add-FileField $memStream $boundary "image" $filename $fileBytes
}

# 结束边界
$endBytes = [System.Text.Encoding]::UTF8.GetBytes("--$boundary--`r`n")
$memStream.Write($endBytes, 0, $endBytes.Length)

$body = $memStream.ToArray()
$memStream.Close()

# ==================== 发送请求 ====================
$startTime = Get-Date
Write-Output "[INFO] 发送请求: $Width x $Height, quality=$Quality"
Write-Output "[INFO] 参考图: $($Images -join ', ')"
Write-Output "[INFO] 请求体大小: $([Math]::Round($body.Length / 1KB, 1)) KB"

[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
$request = [System.Net.WebRequest]::Create($url)
$request.Method = "POST"
$request.Headers.Add("Authorization", "Bearer $apiKey")
$request.ContentType = "multipart/form-data; boundary=$boundary"
$request.ContentLength = $body.Length
$request.Timeout = 480000  # 8 分钟超时

$reqStream = $request.GetRequestStream()
$reqStream.Write($body, 0, $body.Length)
$reqStream.Close()

# ==================== 接收响应 ====================
try {
    $response = $request.GetResponse()
    $reader = New-Object System.IO.StreamReader($response.GetResponseStream())
    $responseText = $reader.ReadToEnd()
    $reader.Close()
    $response.Close()

    $endTime = Get-Date
    $duration = ($endTime - $startTime).TotalSeconds

    # 解码保存
    $result = $responseText | ConvertFrom-Json
    $b64 = $result.data[0].b64_json
    $imgBytes = [System.Convert]::FromBase64String($b64)
    $timestamp = Get-Date -Format "yyyyMMddHHmmss"
    $outPath = Join-Path $OutputDir "${Prefix}_${timestamp}.png"
    [System.IO.File]::WriteAllBytes($outPath, $imgBytes)

    $output = @{
        status = "OK"
        output_path = $outPath
        size = "${Width}x${Height}"
        quality = $Quality
        file_size_kb = [Math]::Round($imgBytes.Length / 1KB, 1)
        duration_seconds = [Math]::Round($duration, 1)
        input_tokens = $result.usage.input_tokens
        output_tokens = $result.usage.output_tokens
        total_tokens = $result.usage.total_tokens
    }
    Write-Output ($output | ConvertTo-Json -Depth 2)

} catch [System.Net.WebException] {
    if ($_.Exception.Status -eq [System.Net.WebExceptionStatus]::Timeout) {
        Write-Output '{"error": "TIMEOUT", "message": "请求超时，请检查 nginx proxy_read_timeout 设置"}'
    } elseif ($_.Exception.Response -and $_.Exception.Response.StatusCode -eq 413) {
        Write-Output '{"error": "REQUEST_TOO_LARGE", "message": "参考图片太大，请缩小后重新上传"}'
    } else {
        $errMsg = $_.Exception.Message
        if ($_.Exception.Response) {
            $errReader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
            $errMsg = $errReader.ReadToEnd()
        }
        Write-Output '{"error": "REQUEST_FAILED", "message": "' + $errMsg + '"}'
    }
    exit 1
}

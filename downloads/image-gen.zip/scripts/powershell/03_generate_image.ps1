# 03_generate_image.ps1 - 文生图（Text-to-Image）
# 用法: .\03_generate_image.ps1 -Prompt "提示词" -Width 1088 -Height 1920 -Quality "low" -Prefix "output" [-ApiKey ""] [-BaseUrl ""]
# 输出: 生成的 PNG 图片到指定目录

param(
    [Parameter(Mandatory=$true)]
    [string]$Prompt,

    [int]$Width = 1024,
    [int]$Height = 1024,

    [ValidateSet("low", "medium", "high")]
    [string]$Quality = "low",

    [string]$Model = "gpt-image-2",

    [string]$Prefix = "generated",

    [string]$ApiKey = "",

    [string]$BaseUrl = "http://10.225.9.142:31888/api/v1",

    [string]$OutputDir = ""
)

$OutputEncoding = [System.Text.Encoding]::UTF8

# 读取 API Key（同 01_check_quota.ps1）
if ($ApiKey -eq "") {
    $ApiKey = $env:LITELLM_API_KEY
    if ($ApiKey -eq "") {
        $configPath1 = Join-Path $env:USERPROFILE ".litellm" "config.json"
        if (Test-Path $configPath1) {
            $config = Get-Content $configPath1 | ConvertFrom-Json
            $ApiKey = $config.api_key
        }
    }
    if ($ApiKey -eq "") {
        $configPath2 = Join-Path $env:USERPROFILE ".workbuddy" "skills" "litellm-gateway-user" "config.json"
        if (Test-Path $configPath2) {
            $config = Get-Content $configPath2 | ConvertFrom-Json
            $ApiKey = $config.api_key
            if ($config.base_url) { $BaseUrl = $config.base_url }
        }
    }
}

if ($ApiKey -eq "") {
    Write-Output '{"error": "NO_API_KEY", "message": "未找到 API Key"}'
    exit 1
}

# 确定输出目录
if ($OutputDir -eq "") {
    $OutputDir = $PWD.Path
}

# 尺寸自动对齐到 16 的倍数
function Align-16([int]$value) {
    return [Math]::Floor($value / 16) * 16
}

$Width = Align-16 $Width
$Height = Align-16 $Height

# 检查像素范围
$totalPixels = $Width * $Height
if ($totalPixels -lt 655360) {
    Write-Output '{"error": "SIZE_TOO_SMALL", "message": "总像素不能低于 655360"}'
    exit 1
}
if ($totalPixels -gt 8294400) {
    Write-Output '{"error": "SIZE_TOO_LARGE", "message": "总像素不能超过 8294400 (4K)"}'
    exit 1
}

$headers = @{ Authorization = "Bearer $ApiKey" }

$body = @{
    model   = $Model
    prompt  = $Prompt
    size    = "${Width}x${Height}"
    quality = $Quality
    n       = 1
} | ConvertTo-Json -Depth 3

$startTime = Get-Date
Write-Output "[INFO] 发送请求: $Width x $Height, quality=$Quality"
Write-Output "[INFO] 提示词: $Prompt"

try {
    $resp = Invoke-RestMethod -Uri "$BaseUrl/images/generations" `
        -Headers $headers -Method Post -Body $body `
        -ContentType "application/json; charset=utf-8" -TimeoutSec 360

    $endTime = Get-Date
    $duration = ($endTime - $startTime).TotalSeconds

    # 解码 Base64 保存
    $b64 = $resp.data[0].b64_json
    $timestamp = Get-Date -Format "yyyyMMddHHmmss"
    $outPath = Join-Path $OutputDir "${Prefix}_${timestamp}.png"
    $imgBytes = [System.Convert]::FromBase64String($b64)
    [System.IO.File]::WriteAllBytes($outPath, $imgBytes)

    $result = @{
        status = "OK"
        output_path = $outPath
        size = "${Width}x${Height}"
        quality = $Quality
        file_size_kb = [Math]::Round($imgBytes.Length / 1KB, 1)
        duration_seconds = [Math]::Round($duration, 1)
        input_tokens = $resp.usage.input_tokens
        output_tokens = $resp.usage.output_tokens
        total_tokens = $resp.usage.total_tokens
    }
    Write-Output ($result | ConvertTo-Json -Depth 2)

} catch {
    $statusCode = $_.Exception.Response.StatusCode.value__
    if ($statusCode -eq 401) {
        Write-Output '{"error": "INVALID_KEY", "message": "API Key 无效"}'
    } elseif ($statusCode -eq 403) {
        Write-Output '{"error": "QUOTA_INSUFFICIENT", "message": "额度不足或 Key 已停用"}'
    } elseif ($statusCode -eq 400) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $reader.BaseStream.Position = 0
        $errDetail = $reader.ReadToEnd()
        Write-Output '{"error": "BAD_REQUEST", "message": "' + $errDetail + '"}'
    } else {
        Write-Output '{"error": "REQUEST_FAILED", "message": "' + $_.Exception.Message + '"}'
    }
    exit 1
}

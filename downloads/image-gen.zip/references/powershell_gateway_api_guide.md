# PowerShell 调用 LiteLLM Gateway 图片生成 API 指南

> 背景：当前环境为 Windows ACP（Application Control/Protection）模式，
> PowerShell 对外部子进程（Python/node 等）有严格限制，无法直接运行 `.py` 脚本。
> 因此改用 PowerShell 原生 cmdlet 直接调用 HTTP API。

---

## 1. 问题：ACP 模式下哪些方式被阻止

| 尝试方式                                 | 结果   | 错误原因                          |
| ------------------------------------ | ---- | ----------------------------- |
| `python script.py`                   | ❌ 阻止 | `python` 可能指向 WindowsApps 占位符 |
| `& $pythonExe script.py`             | ❌ 阻止 | 变量调用运算符隐藏了子进程，静态检查不通过         |
| `Start-Process -FilePath python.exe` | ❌ 阻止 | 子进程脱离窗口隐藏控制                   |
| 任何原生可执行文件启动                          | ❌ 阻止 | ACP 模式限制                      |

**结论：** PowerShell ACP 模式下无法启动任何原生可执行文件作为子进程（包括 Python、Node、curl 等）。

## 2. 解决方案：PowerShell 原生 cmdlet

ACP 模式下 **仅允许** 使用 PowerShell 内置 cmdlet 和 .NET 运行时方法：

| 操作               | 可用 cmdlet / 方法                                       |
| ---------------- | ---------------------------------------------------- |
| HTTP 请求 - JSON   | `Invoke-RestMethod`                                  |
| HTTP 请求 - 原始     | `[System.Net.WebRequest]`                            |
| JSON 序列化         | `ConvertTo-Json`                                     |
| JSON 反序列化        | `ConvertFrom-Json`                                   |
| Base64 解码        | `[System.Convert]::FromBase64String()`               |
| 文件写入             | `[System.IO.File]::WriteAllBytes()`                  |
| 文件读取             | `[System.IO.File]::ReadAllBytes()`（支持中文路径）         |
| 内存流             | `[System.IO.MemoryStream]`                           |
| 字节编码            | `[System.Text.Encoding]::UTF8.GetBytes()`            |
| 时间戳             | `Get-Date -Format "yyyyMMddHHmmss"` / `-Format "yyyy-MM-dd HH:mm:ss.fff"` |
| 高精度计时           | 两次 `Get-Date` 相减得 `TotalSeconds`                   |

---

## 3. 完整调用步骤

### 3.1 查询额度（验证 API Key）

```powershell
$headers = @{ Authorization = "Bearer sk-self-你的APIKey" }

try {
    $resp = Invoke-RestMethod -Uri "http://10.225.9.142:31888/api/v1/quota" `
        -Headers $headers -Method Get -TimeoutSec 10

    Write-Host "[OK] API Key 有效"
    Write-Host "[额度] 已用 $($resp.used_quota) / 总额 $($resp.total_quota)（剩余 $($resp.remaining_quota)）"

    if ($resp.models) {
        Write-Host "[模型] 可用模型："
        foreach ($m in $resp.models) {
            Write-Host "   - $($m.model_id)（$($m.model_type)）"
        }
    }
} catch {
    Write-Host "[ERR] $($_.Exception.Message)"
}
```

### 3.2 文生图（Text-to-Image）

```powershell
$headers = @{ Authorization = "Bearer sk-self-你的APIKey" }

$body = @{
    model   = "gpt-image-2"
    prompt  = "你的中文提示词"
    size    = "1088x1920"       # 9:16 竖版，宽高需为 16 的倍数
    quality = "low"          # low / medium / high
    n       = 1
} | ConvertTo-Json -Depth 3

try {
    $resp = Invoke-RestMethod -Uri "http://10.225.9.142:31888/api/v1/images/generations" `
        -Headers $headers -Method Post -Body $body `
        -ContentType "application/json; charset=utf-8" -TimeoutSec 360

    # 解码 Base64 保存
    $b64       = $resp.data[0].b64_json
    $timestamp = Get-Date -Format "yyyyMMddHHmmss"
    $outPath   = "D:\path\to\output\poster_$timestamp.png"
    $imgBytes  = [System.Convert]::FromBase64String($b64)
    [System.IO.File]::WriteAllBytes($outPath, $imgBytes)

    Write-Host "[OK] 保存到 $outPath"
    Write-Host "[大小] $($imgBytes.Length / 1KB) KB"
} catch {
    Write-Host "[ERR] 状态码：$($_.Exception.Response.StatusCode.value__)"
    $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
    $reader.BaseStream.Position = 0
    $reader.DiscardBufferedData()
    Write-Host "[ERR] 详情：$($reader.ReadToEnd())"
}
```

### 3.3 图片编辑（多图 + 参考图合成）— ✅ 已验证

> 实测成功，使用 `[System.Net.WebRequest]` + `[System.IO.MemoryStream]` 手动构建 multipart。
> 
> **注意：** PowerShell 5.1 的 `Invoke-RestMethod` 的 `-Form` 参数不可用（仅 PS 6+ 支持），
> 且 .NET 的 `[System.Net.Http.MultipartFormDataContent]` 在 PS 5.1 上加载复杂。
> 因此直接手动构建 multipart 请求体是最可靠的方式。

```powershell
# ==================== 配置 ====================
$apiKey = "sk-self-你的APIKey"
$baseUrl = "http://10.225.9.142:31888/api/v1"
$url = "$baseUrl/images/edits"
$workDir = "D:\你的工作目录"

# 参考图片路径（支持中文路径）
$imagePaths = @(
    "C:\Users\xxx\Desktop\参考图_工装.png",
    "C:\Users\xxx\Desktop\参考图_食物.png"
)

# 读取图片到内存
$imageBytes = $imagePaths | ForEach-Object { [System.IO.File]::ReadAllBytes($_) }

# ==================== 构建 multipart 请求体 ====================
$boundary = "----FormBoundary" + [DateTime]::Now.Ticks.ToString("x")
$memStream = New-Object System.IO.MemoryStream

# 辅助函数：添加文本字段
function Add-TextField($stream, $boundary, $name, $value) {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes(
        "--$boundary`r`nContent-Disposition: form-data; name=`"$name`"`r`n`r`n$value`r`n"
    )
    $stream.Write($bytes, 0, $bytes.Length)
}

# 辅助函数：添加文件字段
function Add-FileField($stream, $boundary, $name, $filename, $fileBytes) {
    $header = "--$boundary`r`nContent-Disposition: form-data; name=`"$name`"; filename=`"$filename`"`r`nContent-Type: image/png`r`n`r`n"
    $headerBytes = [System.Text.Encoding]::UTF8.GetBytes($header)
    $stream.Write($headerBytes, 0, $headerBytes.Length)
    $stream.Write($fileBytes, 0, $fileBytes.Length)
    $stream.Write([System.Text.Encoding]::UTF8.GetBytes("`r`n"), 0, 2)
}

# 添加字段
Add-TextField $memStream $boundary "model" "gpt-image-2"
Add-TextField $memStream $boundary "prompt" "编辑指令（支持中文）"
Add-TextField $memStream $boundary "size" "1728x3072"        # 输出尺寸
Add-TextField $memStream $boundary "quality" "high"          # low/medium/high

# 添加多张参考图（同一字段名 "image"，重复调用即可）
for ($i = 0; $i -lt $imagePaths.Count; $i++) {
    $filename = Split-Path $imagePaths[$i] -Leaf
    Add-FileField $memStream $boundary "image" $filename $imageBytes[$i]
}

# 结束边界
$endBytes = [System.Text.Encoding]::UTF8.GetBytes("--$boundary--`r`n")
$memStream.Write($endBytes, 0, $endBytes.Length)

$body = $memStream.ToArray()
$memStream.Close()

# ==================== 发送请求 ====================
$startTime = Get-Date
Write-Host "[请求] 发送时间: $($startTime.ToString('yyyy-MM-dd HH:mm:ss.fff'))"
Write-Host "[请求] 请求体: $(($body.Length / 1KB -as [int])) KB"

[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
$request = [System.Net.WebRequest]::Create($url)
$request.Method = "POST"
$request.Headers.Add("Authorization", "Bearer $apiKey")
$request.ContentType = "multipart/form-data; boundary=$boundary"
$request.ContentLength = $body.Length
$request.Timeout = 480000  # 毫秒，建议设为 nginx proxy_read_timeout + 120s

$reqStream = $request.GetRequestStream()
$reqStream.Write($body, 0, $body.Length)
$reqStream.Close()

# ==================== 接收响应 ====================
try {
    $response = $request.GetResponse()
    $reader = New-Object System.IO.StreamReader($response.GetResponseStream())
    $responseText = $reader.ReadToEnd()
    $reader.Close()
    $response.Close()

    $endTime = Get-Date
    $duration = ($endTime - $startTime).TotalSeconds
    Write-Host "[完成] 结束时间: $($endTime.ToString('yyyy-MM-dd HH:mm:ss.fff'))"
    Write-Host "[用时] API 用时: $($duration -as [int]) 秒"

    # 解码保存
    $result = $responseText | ConvertFrom-Json
    $b64 = $result.data[0].b64_json
    $imgBytes = [System.Convert]::FromBase64String($b64)
    $timestamp = Get-Date -Format "yyyyMMddHHmmss"
    $outPath = Join-Path $workDir "output_${timestamp}.png"
    [System.IO.File]::WriteAllBytes($outPath, $imgBytes)

    Write-Host "[保存] $outPath"
    Write-Host "[大小] $(($imgBytes.Length / 1KB -as [int])) KB"

} catch [System.Net.WebException] {
    # 区分不同的错误场景
    if ($_.Exception.Status -eq [System.Net.WebExceptionStatus]::Timeout) {
        Write-Host "[ERR] 请求超时！请检查 nginx proxy_read_timeout 设置"
        Write-Host "[ERR] 建议措施：增大 timeout 或降低分辨率/质量"
    } elseif ($_.Exception.Response -and $_.Exception.Response.StatusCode -eq 413) {
        Write-Host "[ERR] 413 Request Entity Too Large"
        Write-Host "[ERR] 参考图片太大，请缩小后重新上传（nginx client_max_body_size）"
    } else {
        Write-Host "[ERR] $($_.Exception.Message)"
        if ($_.Exception.Response) {
            $errReader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
            Write-Host "[ERR] 详情: $($errReader.ReadToEnd())"
        }
    }
}
```

---

## 4. 尺寸速查与选取策略

### 基础尺寸表

| 比例   | 推荐尺寸          | 总像素     | 说明          |
| ---- | ------------- | -------- | ----------- |
| 1:1  | 1024×1024     | 1,048,576 | 方形，头像       |
| 16:9 | 1920×1088     | 2,088,960 | 横版海报        |
| 9:16 | **1088×1920** | 2,088,960 | 竖版海报（推荐首选） |
| 4:3  | 1440×1088     | 1,566,720 | 传统照片        |

### 9:16 竖版更多选择（宽高均为 16 倍数）

> 9:16 比例下，宽 = 144n, 高 = 256n（n 为正整数）

| n   | 尺寸          | 总像素      | 长边    | 推荐场景              |
| --- | ----------- | --------- | ----- | ----------------- |
| 6   | 864×1536    | 1,327,104 | 1536  | 快速预览              |
| 7   | 1008×1792   | 1,806,336 | 1792  | 常规竖版              |
| **8** | **1152×2048** | 2,359,296 | 2048  | 2K 竖版             |
| 9   | 1296×2304   | 2,985,984 | 2304  |                     |
| 10  | 1440×2560   | 3,686,400 | 2560  | 2.5K 竖版            |
| 11  | 1584×2816   | 4,460,544 | 2816  |                     |
| **12** | **1728×3072** | 5,308,416 | **3072** | **推荐：长边 > 3000px 首选** |
| 13  | 1872×3328   | 6,230,016 | 3328  |                     |
| 14  | 2016×3584   | 7,225,344 | 3584  |                     |
| **15** | **2160×3840** | 8,294,400 | **3840** | **4K 竖版（极限大小）**    |

### 尺寸选取决策

```
需求 长边 > 3000px?
├─ 是 → 用 1728×3072（推荐，5.3M 像素，生成时间可控）
│    └─ 需要 4K → 2160×3840（极限大小，生成时间 > 8min，需设定足够 timeout）
└─ 否 → 用 1088×1920（推荐首选，2.1M 像素，生成最快）
```

> **约束条件：**
> - 宽高必须为 **16 的倍数**（API 硬性要求，否则报 400 错误）
> - 总像素在 [655,360, 8,294,400] 范围内
> - 单维度不低于 816

---

## 5. 手动构建 multipart 请求体（核心方案）

> ⚠️ **重要：** 这是 3.3 节中使用的核心方法。`-Form` 参数在 PS 5.1 中不可用，
> 且 `[System.Net.Http.MultipartFormDataContent]` 需要额外加载程序集，
> 因此手动构建是最可靠的方案。

### 5.1 核心函数（可直接复用）

```powershell
function Build-MultipartBody {
    param(
        [hashtable]$TextFields,       # @{ "name" = "value" }
        [hashtable]$FileFields,        # @{ "fieldName" = @("filePath1", "filePath2") }
        [string]$Boundary             # 边界字符串
    )

    $stream = New-Object System.IO.MemoryStream

    # 文本字段
    foreach ($kv in $TextFields.GetEnumerator()) {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes(
            "--$Boundary`r`nContent-Disposition: form-data; name=`"$($kv.Name)`"`r`n`r`n$($kv.Value)`r`n"
        )
        $stream.Write($bytes, 0, $bytes.Length)
    }

    # 文件字段（同一字段名可多次出现）
    foreach ($kv in $FileFields.GetEnumerator()) {
        foreach ($path in $kv.Value) {
            $fileBytes = [System.IO.File]::ReadAllBytes($path)
            $filename = Split-Path $path -Leaf
            $header = "--$Boundary`r`nContent-Disposition: form-data; name=`"$($kv.Name)`"; filename=`"$filename`"`r`nContent-Type: image/png`r`n`r`n"
            $headerBytes = [System.Text.Encoding]::UTF8.GetBytes($header)
            $stream.Write($headerBytes, 0, $headerBytes.Length)
            $stream.Write($fileBytes, 0, $fileBytes.Length)
            $stream.Write([System.Text.Encoding]::UTF8.GetBytes("`r`n"), 0, 2)
        }
    }

    # 结束边界
    $stream.Write([System.Text.Encoding]::UTF8.GetBytes("--$Boundary--`r`n"), 0, 6)

    $body = $stream.ToArray()
    $stream.Close()
    return $body
}

# 使用示例
$boundary = "----FormBoundary" + [DateTime]::Now.Ticks.ToString("x")
$body = Build-MultipartBody -TextFields @{
    model   = "gpt-image-2"
    prompt  = "中文编辑指令"
    size    = "1728x3072"
    quality = "high"
} -FileFields @{
    image   = @(
        "D:\参考图1.png",
        "D:\参考图2.png"
    )
} -Boundary $boundary
```

### 5.2 执行请求

```powershell
$request = [System.Net.WebRequest]::Create("http://10.225.9.142:31888/api/v1/images/edits")
$request.Method = "POST"
$request.Headers.Add("Authorization", "Bearer sk-self-xxx")
$request.ContentType = "multipart/form-data; boundary=$boundary"
$request.ContentLength = $body.Length
$request.Timeout = 480000  # 毫秒

$reqStream = $request.GetRequestStream()
$reqStream.Write($body, 0, $body.Length)
$reqStream.Close()

$response = $request.GetResponse()
$reader = New-Object System.IO.StreamReader($response.GetResponseStream())
$responseText = $reader.ReadToEnd()
$reader.Close()
$response.Close()

$result = $responseText | ConvertFrom-Json
$b64 = $result.data[0].b64_json
$imgBytes = [System.Convert]::FromBase64String($b64)
$outPath = "D:\output_$(Get-Date -Format 'yyyyMMddHHmmss').png"
[System.IO.File]::WriteAllBytes($outPath, $imgBytes)
```

---

## 6. 性能基准数据（实测）

> 以下数据来自 gpt-image-2 模型，后端为 LiteLLM Gateway 部署在 TKE。

### 6.1 尺寸 × 质量 × 用时

| 场景 | 尺寸 | 像素 | 质量 | 用时 | 输出大小 |
|:---:|:---:|:---:|:---:|:---:|:---:|
| 快速预览 | 1024×1024 | 1.0M | low | ~47s | ~500KB |
| 常规竖版 | 1088×1920 | 2.1M | medium | ~120s | ~1-2MB |
| **竖版海报** | **1088×1920** | **2.1M** | **high** | **~180-300s** | **~3MB** |
| 大尺寸竖版 | 1728×3072 | 5.3M | high | **~482s (8min)** | **~8MB** |
| 4K 竖版 | 2160×3840 | 8.3M | high | **>420s (超时)** | - |

### 6.2 质量等级说明

| 质量 | 速度 | 备注 |
|:---:|:---:|:---:|
| low | ~47s | 快速预览用 |
| medium | ~120s | 日常使用，性价比最高 |
| high | 2-8min | 消耗约 15x tokens，仅最终输出使用 |

---

## 7. Nginx 部署注意事项

> LiteLLM Gateway 部署在 TKE，外层 nginx ingress 有默认限制，需根据实际需求调整。

### 7.1 常见错误与配置

| 错误 | 状态码 | 原因 | nginx 配置 | 建议值 |
|:---:|:---:|:---:|:---:|:---:|
| 请求体过大 | 413 | 参考图太大 | `client_max_body_size` | 10MB |
| 连接超时 | 504 / 操作超时 | 生成耗时 > 超时 | `proxy_read_timeout` | 360-600s |

### 7.2 时间线：谁的超时了？

```
客户端（PowerShell）    nginx ingress   后端（LiteLLM Gateway）
   │                        │                   │
   │─── POST /images/edits ──→──── 请求转发 ─────→── 开始生成 ─┐
   │                        │                   │            │
   │                        │                   │    (生成中...)
   │                        │                   │            │
   │   ←── nginx 断开 ─────  timeout!           │            │
   │                        │  proxy_read_timeout│           │
   │                        │  耗尽，关闭连接     │           │
   │                        │                   │            │
   │   [PowerShell 超时]    │                   │   (仍在生成) │
   │   .NET Timeout 才触发   │                   │            │
```

**关键规则：** 三者的超时时间必须满足：
```
nginx proxy_read_timeout < .NET 请求 Timeout
```
推荐：nginx = 360s（6 分钟），.NET = 480s（8 分钟）

### 7.3 参考图大小限制

| 参考图 | 上传大小 | 避免 413 的条件 |
|:---:|:---:|:---:|
| 单张 < 512KB | ✅ 安全 | 默认 1MB 限制即可 |
| 单张 < 5MB | 多图需注意 | 需设 `client_max_body_size 10M` |
| 多图合计 > 10MB | ❌ 必 413 | 需先缩小图片再上传 |

**缩小参考图的方法（备用）：** 手动用画图工具/PS 将图片最长边缩到 1600px 以内再保存。

---

## 8. 最佳实践总结

| 需求                 | 推荐做法                                                       |
| ------------------ | ---------------------------------------------------------- |
| **调用 HTTP API**    | 简单 JSON API 用 `Invoke-RestMethod`；multipart 用 `[System.Net.WebRequest]` |
| **JSON 序列化**       | `ConvertTo-Json -Depth 3`                                    |
| **生成超时设置**        | nginx `proxy_read_timeout 360s`，.NET `Timeout=480000ms`       |
| **大图生成**           | 从 1088×1920 开始试，确认效果后再逐步增大尺寸                            |
| **首次快速验证**         | 先用 `quality=low` + 小尺寸验证 prompt 和图片路径是否正确                   |
| **参考图路径含中文**      | `[System.IO.File]::ReadAllBytes()` 支持中文路径，无需特殊处理            |
| **Base64 解码**       | `[System.Convert]::FromBase64String()`                      |
| **写入二进制文件**       | `[System.IO.File]::WriteAllBytes()`                         |
| **错误信息提取**        | `$_.Exception.Response.GetResponseStream()`                 |
| **中文提示词（JSON）**    | 设置 `Content-Type: application/json; charset=utf-8`         |
| **中文提示词（multipart）** | 文本字段用 `[System.Text.Encoding]::UTF8.GetBytes()` 编码       |
| **高精度计时**          | 两次 `Get-Date` 相减取 `.TotalSeconds`                        |
| **文件命名**           | `Get-Date -Format 'yyyyMMddHHmmss'` 做时间戳后缀                 |
| **参考图文件大小**        | 控制在单张 < 5MB，总上传 < 8MB，避免 413                              |

> 关键原则：所有操作必须使用 **PowerShell 内置 cmdlet** 或 **.NET 运行时类**，
> 不得启动任何外部子进程（exe / py / js）。

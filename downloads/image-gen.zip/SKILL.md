# 基于内部网关的 GPT-Image 2 用户端 Skill

> 版本：v4.1
> 最后更新：2026-05-10

## 简介

本 Skill 为企业员工提供基于内部 LLM 网关的 AI 图像生成服务，核心聚焦于 **GPT-Image 2 图像生成**。

**核心能力：**

- 📋 **自助申请**：员工无需管理员介入，独立完成 API Key 申请
- 🎨 **图像生成**：文生图、单图编辑、多图合成（使用 gpt-image-2）
- 📊 **额度管理**：实时查询剩余 Token 额度

**多平台支持：**

- Python 脚本（首选，零依赖）
- PowerShell 脚本（Windows ACP 环境兼容）
- Bash 脚本（macOS / Linux）

---

## 1. 触发条件

当用户提到以下关键词时，自动触发本 Skill：

- "AI Token Key"、"申请 AI Key"、"API Key"
- "生成图片"、"文生图"、"图片编辑"、"图像合成"
- "查额度"、"还剩多少 token"

---

## 2. 环境检测与脚本选择（Bot 必读）

> ⚠️ **重要**：本 Skill 支持多平台脚本，Bot 必须先检测环境再选择正确的脚本路径。

### 2.1 检测流程

```
开始
  ↓
检测 Python 是否可用
  ├── 可用 → 使用 scripts/python/ 目录下的脚本
  │
  └── 不可用 → 检测操作系统
                ├── Windows → 使用 scripts/powershell/ 目录下的脚本
                └── macOS/Linux → 使用 scripts/bash/ 目录下的脚本
```

### 2.2 Python 可用性检测方法

**PowerShell 环境：**

```powershell
# 方法1：检查 Python 可执行文件
$pythonExe = Get-Command python.exe -ErrorAction SilentlyContinue
if ($pythonExe) {
    # Python 可用
} else {
    # Python 不可用
}

# 方法2：尝试执行 Python 命令（会被 ACP 模式阻止）
try {
    python --version 2>&1
    # 如果执行到这里，说明 Python 可用
} catch {
    # Python 不可用（或被 ACP 阻止）
}
```

**Bash 环境（macOS/Linux）：**

```bash
if command -v python3 &> /dev/null; then
    # Python 可用
else
    # Python 不可用
fi
```

### 2.3 脚本路径对照表

| 环境                 | 额度查询                                    | 文生图                                        | 图片编辑                                   |
| ------------------ | --------------------------------------- | ------------------------------------------ | -------------------------------------- |
| Python（首选）         | `scripts/python/01_check_quota.py`      | `scripts/python/03_generate_image.py`      | `scripts/python/04_edit_image.py`      |
| Windows PowerShell | `scripts/powershell/01_check_quota.ps1` | `scripts/powershell/03_generate_image.ps1` | `scripts/powershell/04_edit_image.ps1` |
| macOS/Linux Bash   | `scripts/bash/01_check_quota.sh`        | `scripts/bash/03_generate_image.sh`        | `scripts/bash/04_edit_image.sh`        |

### 2.4 Windows ACP 模式特殊处理

> **重要**：Windows ACP（Application Control/Protection）模式下，PowerShell 无法启动任何外部子进程（包括 Python）。
> 
> 如果检测到 Python 调用被阻止（错误信息包含 "blocked"、"ACP" 等关键词），必须自动切换到 PowerShell 脚本。

**ACP 模式特征：**

- 错误信息：`PowerShell command blocked in Windows ACP mode`
- 错误信息：`Direct native executable launch from PowerShell can create a visible console window`

**处理方式：**

```
检测到 ACP 阻止 → 自动切换到 scripts/powershell/ 目录 → 使用 .ps1 脚本
```

---

## 3. 工作流程

```
用户请求
  ↓
检查是否已配置 API Key（依次尝试）
  ├─ 环境变量 LITELLM_API_KEY
  ├─ ~/.litellm/config.json
  └─ ~/.workbuddy/skills/litellm-gateway-user/config.json
  ↓
  ├── 有 Key → 调用额度查询脚本验证
  │              ↓
  │        验证通过 → 显示额度和模型列表 → 进入服务环节
  │              ↓
  │        验证失败（401/403）→ 引导重新申请
  │
  └── 无 Key → 引导用户自助申请（见第 4 节）
                  ↓
            用户完成申请并提供 Key
                  ↓
            保存配置 → 调用额度查询脚本验证 → 进入服务环节
```

---

## 4. 引导自助申请（无 Key 时）

**对用户说：**

```
您还没有配置 AI Token Key，需要先完成自助申请。

📋 申请步骤：

1. 访问自助申请页面：
   http://10.225.9.142:31888/#/self-service

2. 填写信息：
   - 姓名（真实姓名）
   - 企业邮箱
   - 工号（12位纯数字）
   - 企微部门

3. 提交后获取 API Key（格式：sk-self-xxx）

⚠️ 重要：API Key 仅显示一次，请立即保存！

完成申请后，请把 Key 发给我，我来帮您配置。
```

**用户发送 Key 后，Bot 自动：**

1. 保存 Key 到 `~/.workbuddy/skills/litellm-gateway-user/config.json`
2. 调用额度查询脚本验证 Key
3. 向用户展示验证结果和额度信息
4. 进入服务环节

**保存配置的代码（Bot 内部执行）：**

```python
import json, os

config_dir = os.path.expanduser("~/.workbuddy/skills/litellm-gateway-user")
os.makedirs(config_dir, exist_ok=True)

config = {"api_key": "sk-self-xxx", "base_url": "http://10.225.9.142:31888/api/v1"}
with open(os.path.join(config_dir, "config.json"), "w") as f:
    json.dump(config, f, indent=2)
```

---

## 5. 验证 Key 并展示信息

**调用脚本示例（Python 环境）：**

```python
import subprocess, sys
result = subprocess.run(
    [sys.executable, "scripts/python/01_check_quota.py"],
    capture_output=True, text=True, encoding='utf-8'
)
print(result.stdout)
```

**调用脚本示例（PowerShell 环境）：**

```powershell
$result = & ".\scripts\powershell\01_check_quota.ps1"
$result | ConvertFrom-Json
```

**验证通过后，对用户展示：**

```
✅ API Key 验证成功！

📊 您的额度信息：
- 总额度：100,000 tokens
- 已使用：5,000 tokens
- 剩余：95,000 tokens

🎨 可用模型：
- gpt-image-2（图像生成）
```

**多模型场景处理：**

如果 quota 返回多个图像模型，Bot 需要让用户选择：

```
🎨 检测到多个图像模型，请选择：
1. gpt-image-2（推荐）
2. dall-e-3

请回复数字 1 或 2。
```

**然后介绍图像生成能力：**

```
🎨 图像生成能力：
- 文生图：根据文字描述生成图片
- 单图编辑：修改已有图片
- 多图合成：多张图片融合创作

📐 图片尺寸：您只需提供宽高比例（如 1:1、16:9、9:16），Bot 自动计算最合适的尺寸

🎯 质量选项（影响处理耗时，不影响 token 消耗）：
- 标准（low）：快速预览，约 60 秒
- 高（medium）：一般用途，约 150 秒
- 超高（high）：最终交付，约 360 ~ 600 秒，**消耗的token数量是标准的15倍**
```

---

## 6. 调用注意事项（Bot 必读）

### Windows 编码问题

**Python subprocess 调用示例：**

```python
import subprocess, sys

result = subprocess.run(
    [sys.executable, "scripts/python/03_generate_image.py", "提示词"],
    capture_output=True,
    text=True,
    encoding='utf-8'  # 关键：设置 UTF-8 编码
)
print(result.stdout)
```

> ⚠️ **不要写死 `python` 命令**：在 Git Bash / PowerShell 环境中，`python` 可能指向 Microsoft Store 占位符。应使用 `sys.executable`（Python 解释器自身路径）。

### Python 环境要求

**所有 Python 脚本仅使用标准库，无需安装任何第三方依赖。**

| 脚本                     | 依赖                              | Python 版本要求 |
| ---------------------- | ------------------------------- | ----------- |
| `01_check_quota.py`    | urllib, json                    | Python 3.0+ |
| `03_generate_image.py` | urllib, json, base64, math      | Python 3.0+ |
| `04_edit_image.py`     | urllib, json, base64, mimetypes | Python 3.0+ |

### PowerShell 环境要求

| 脚本         | 依赖    | PowerShell 版本要求 |
| ---------- | ----- | --------------- |
| 所有 .ps1 脚本 | 无外部依赖 | PowerShell 5.1+ |

**PowerShell 脚本特点：**

- 使用 `Invoke-RestMethod` 和 `[System.Net.WebRequest]` 进行 HTTP 调用
- 使用 `[System.Convert]::FromBase64String()` 解码图片
- 兼容 Windows ACP 模式（无需启动外部子进程）

### Bash 环境要求

| 脚本        | 依赖               |
| --------- | ---------------- |
| 所有 .sh 脚本 | curl, jq, base64 |

---

## 7. 铁律：不得擅自修改用户提示词

**Bot 调用模型能力时，必须原封不动传递用户的提示词，禁止任何形式的修改、润色或翻译。**

**绝对禁止的行为：**

- ❌ 将中文提示词翻译成英文传给模型
- ❌ 在用户提示词前后擅自添加修饰语
- ❌ 修改用户指定的专有名词、品牌名、人物名
- ❌ 将用户的简洁描述"扩写"成一大段英文 prompt

**正确行为：**

- ✅ 用户说 `"生成一张 GTA 风格的狗狗封面"` → 直接传 `"生成一张 GTA 风格的狗狗封面"`
- ✅ 用户说 `"一只可爱的猫咪坐在咖啡厅"` → 直接传 `"一只可爱的猫咪坐在咖啡厅"`

> 唯一的例外：当用户明确要求"帮我把这段话改成一个适合 AI 生成图片的 prompt"时，Bot 可以在用户确认后修改。

### 7.1 铁律：不得读取图片内容

**Bot 调用图片编辑功能时，禁止读取图片内容。图片的"理解"由 API（gpt-image-2）完成，不是 Bot。**

**错误做法 ❌**

- Bot 把图片当作"输入内容"来读取/查看
- Bot 尝试"理解"图片内容后再生成编辑指令
- Bot 在对话中展示图片或分析图片

**正确做法 ✅**

- Bot 只需要知道图片的 **文件路径**
- Bot 把路径和用户指令直接传给脚本
- **脚本负责**：读取文件、构建 multipart 请求、上传到 API
- **API 负责**：理解图片内容、执行编辑指令
- Bot 只需要知道 **输出文件的路径**，告诉用户结果在哪

**图片路径获取规则**

场景 1：用户给出明确路径

```
用户："编辑这张图 D:\photo.png，改成水墨风格"
Bot：提取路径 "D:\photo.png"，不调用 Read 工具
Bot：调用脚本 .\04_edit_image.ps1 -Images @("D:\photo.png") -Prompt "改成水墨风格"
```

场景 2：用户插入截图

当用户插入截图时，系统会自动提供 `<image_local_path>` 标签：

```
用户消息示例：
把这两张图合成一张海报
<image_local_path>C:\Users\Danny\.workbuddy\clipboard-images\clipboard-2026-05-07T01-57-43-546Z-f5be26d0.png</image_local_path>
<image_local_path>C:\Users\Danny\.workbuddy\clipboard-images\clipboard-2026-05-07T01-57-43-547Z-e129fe81.png</image_local_path>
```

**Bot 应：**
1. 从 `<image_local_path>` 标签中提取绝对路径
2. **禁止**调用 Read 工具查看图片内容
3. 将路径直接传给脚本参数

```powershell
.\04_edit_image.ps1 `
    -Prompt "合成一张海报" `
    -Images @(
        "C:\Users\Danny\.workbuddy\clipboard-images\clipboard-2026-05-07T01-57-43-546Z-f5be26d0.png",
        "C:\Users\Danny\.workbuddy\clipboard-images\clipboard-2026-05-07T01-57-43-547Z-e129fe81.png"
    ) `
    -Width 1728 -Height 3072 -Quality high -Prefix "merged_poster"
```

**职责边界**

| 场景 | Bot 职责 | 不该做的事 |
|------|----------|------------|
| 文生图 | 传递 prompt 字符串 | — |
| 图片编辑 | 传递图片路径 + 编辑指令 | ❌ 不要读取图片、不要"看"图片、不要理解图片内容 |
| 结果展示 | 告诉用户输出文件路径 | ❌ 不要展示/分析生成的图片 |

---

## 8. 提供服务：脚本调用指南

用户提出具体需求后，Bot 根据环境选择正确的脚本并执行。

### 8.1 文生图

**用户说**："帮我生成一张 9:16 的中国山水画"、"生成一张猫咪海报，高质量"

**脚本参数**：

| 参数      | 说明                 | 示例                  |
| ------- | ------------------ | ------------------- |
| prompt  | 提示词（必填）            | "中国山水画"             |
| width   | 宽度（自动对齐16）         | 1088                |
| height  | 高度（自动对齐16）         | 1920                |
| quality | 质量：low/medium/high | "medium"            |
| prefix  | 文件名前缀              | "chinese_landscape" |
| model   | 模型名（多模型场景）         | "gpt-image-2"       |

**Python 调用示例**：

```bash
python scripts/python/03_generate_image.py "中国山水画" 1088 1920 medium --prefix=chinese_landscape
```

**PowerShell 调用示例**：

```powershell
.\scripts\powershell\03_generate_image.ps1 -Prompt "中国山水画" -Width 1088 -Height 1920 -Quality medium -Prefix "chinese_landscape"
```

**Bash 调用示例**：

```bash
./scripts/bash/03_generate_image.sh -p "中国山水画" -w 1088 -h 1920 -q medium -x chinese_landscape
```

### 8.2 图片编辑

**用户说**："把这张图改成山水画风格"、"把这两张图合成一张海报"

**脚本参数**：

| 参数      | 说明       | 示例                                |
| ------- | -------- | --------------------------------- |
| prompt  | 编辑指令（必填） | "改成山水画风格"                         |
| images  | 图片路径（必填） | `@("D:\img1.png", "D:\img2.png")` |
| width   | 输出宽度     | 1728                              |
| height  | 输出高度     | 3072                              |
| quality | 质量       | "high"                            |
| prefix  | 文件名前缀    | "edited_poster"                   |

**Python 调用示例**：

```bash
python scripts/python/04_edit_image.py D:\img1.png D:\img2.png "改成山水画风格" --width 1728 --height 3072 --quality high --prefix edited_poster
```

**PowerShell 调用示例**：

```powershell
.\scripts\powershell\04_edit_image.ps1 -Prompt "改成山水画风格" -Images @("D:\img1.png", "D:\img2.png") -Width 1728 -Height 3072 -Quality high -Prefix "edited_poster"
```

**Bash 调用示例**：

```bash
./scripts/bash/04_edit_image.sh -p "改成山水画风格" -i "/path/img1.png,/path/img2.png" -w 1728 -h 3072 -q high -x edited_poster
```

### 8.3 额度查询

**用户说**："我还剩多少额度"、"查一下我的 token"

直接调用对应平台的 `01_check_quota` 脚本即可。

---

## 9. 图片尺寸速查表

### 常用比例推荐尺寸

| 比例   | 推荐尺寸          | 总像素       | 用途       |
| ---- | ------------- | --------- | -------- |
| 1:1  | 1024×1024     | 1,048,576 | 头像、主图    |
| 16:9 | **1920×1088** | 2,088,960 | 横版海报     |
| 9:16 | **1088×1920** | 2,088,960 | 竖版海报（推荐） |
| 4:3  | **1440×1088** | 1,566,720 | 传统照片     |
| 3:2  | 1536×1024     | 1,572,864 | 官方横向     |
| 2:3  | 1024×1536     | 1,572,864 | 官方纵向     |

> ⚠️ 所有尺寸宽高必须为 16 的倍数。脚本会自动处理对齐，无需手动计算。

---

## 10. 错误速查

| 状态码 | 含义            | Bot 处理                  |
| --- | ------------- | ----------------------- |
| 401 | Key 无效        | 引导用户检查 Key 或重新申请        |
| 403 | Key 停用 / 额度不足 | 显示剩余额度，建议联系管理员          |
| 408 | 请求超时          | 图片生成正常需要 47~250 秒，属预期行为 |
| 413 | 请求体过大         | 建议缩小参考图后重试              |
| 500 | 服务器错误         | 建议联系管理员                 |

---

## 11. 实战经验与踩坑记录

### 1. 提示词必须原封不动传递

**问题**：Bot 擅自将中文提示词翻译成英文传给模型，导致生成结果偏离用户意图。

**解决**：用户说 `"生成一张 GTA 风格的狗狗封面"` → 直接原样传递。禁止任何形式的修改、润色或翻译。

**唯一例外**：用户明确要求"帮我把这段话改成一个适合 AI 生成图片的 prompt"时，可以在用户确认后修改。

### 2. Bot 禁止读取图片内容

**问题**：图片编辑时 Bot 尝试"理解"图片内容后再生成编辑指令，这是错误的。

**解决**：Bot 只需要知道图片的**文件路径**，直接传给脚本即可。图片的"理解"由 API（gpt-image-2）完成，不是 Bot。

**正确职责边界**：
- Bot 传递图片路径 + 编辑指令
- 脚本负责读取文件、构建 multipart 请求、上传到 API
- API 负责理解图片内容、执行编辑指令
- Bot 只告诉用户输出文件的路径

### 3. Windows ACP 模式必须切换脚本

**问题**：Windows ACP（Application Control/Protection）模式下，PowerShell 无法启动外部子进程（包括 Python）。

**特征错误**：`PowerShell command blocked in Windows ACP mode`

**解决**：检测到 ACP 阻止后，自动切换到 `scripts/powershell/` 目录下的 `.ps1` 脚本。PowerShell 脚本使用 `Invoke-RestMethod` 和 `[System.Net.WebRequest]`，无需启动外部进程。

### 4. Python 环境编码问题

**问题**：Python subprocess 调用脚本时，中文提示词乱码。

**解决**：调用时必须显式设置 `encoding='utf-8'`：

```python
result = subprocess.run(
    [sys.executable, "scripts/python/03_generate_image.py", "提示词"],
    capture_output=True, text=True, encoding='utf-8'
)
```

### 5. 图片尺寸自动对齐

**问题**：手动计算 16 的倍数容易出错。

**解决**：脚本会自动将宽高对齐到 16 的倍数，用户只需提供比例（如 1:1、16:9、9:16）。

**常用比例推荐**：
- 1:1 → 1024×1024（头像、主图）
- 16:9 → 1920×1088（横版海报）
- 9:16 → 1088×1920（竖版海报，推荐）

### 6. 质量选项与 Token 消耗

**注意**：质量选项只影响处理耗时，不影响 token 消耗。

| 质量 | 耗时 | 说明 |
|:---|:---|:---|
| low | ~60 秒 | 快速预览 |
| medium | ~150 秒 | 一般用途 |
| high | ~360-600 秒 | 最终交付，消耗 token 是标准的 15 倍 |

### 7. 错误码速查

| 状态码 | 含义 | 处理 |
|:---|:---|:---|
| 401 | Key 无效 | 引导检查 Key 或重新申请 |
| 403 | Key 停用 / 额度不足 | 显示剩余额度，联系管理员 |
| 408 | 请求超时 | 正常，图片生成需要 47~250 秒 |
| 413 | 请求体过大 | 缩小参考图后重试 |
| 500 | 服务器错误 | 联系管理员 |

---

## 12. 目录结构

```
skills/image_gen_skill/
├── SKILL.md                          # 本文档（环境检测 + 使用指南）
├── scripts/
│   ├── python/                       # Python 脚本（首选，零依赖）
│   │   ├── 01_check_quota.py
│   │   ├── 03_generate_image.py
│   │   └── 04_edit_image.py
│   ├── powershell/                   # Windows PowerShell 脚本（ACP 兼容）
│   │   ├── 01_check_quota.ps1
│   │   ├── 03_generate_image.ps1
│   │   └── 04_edit_image.ps1
│   └── bash/                         # macOS/Linux Bash 脚本
│       ├── 01_check_quota.sh
│       ├── 03_generate_image.sh
│       └── 04_edit_image.sh
└── references/
    └── powershell_gateway_api_guide.md  # PowerShell API 详细技术文档
```

---

## 13. 详细技术参考

如需了解 PowerShell 在 Windows ACP 模式下的完整实现细节，请参阅：

- `references/powershell_gateway_api_guide.md` — 包含 multipart 构建方法、错误处理、性能基准等

---

*免责声明：本服务仅供内部使用，请合理使用 AI 资源。*
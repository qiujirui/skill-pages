"""
ZIP → RAR 自动转换工具
使用 7-Zip 打包 + CloudConvert API 转换格式

用法:
    python zip_to_rar.py --api-key <KEY> --source <文件或目录路径> --output-dir <输出目录> [--cleanup]

参数:
    --api-key     CloudConvert API Key (必填)
    --source      要压缩的源文件或目录路径 (必填)
    --output-dir  输出目录 (必填)
    --cleanup     转换完成后删除中间 ZIP 文件 (可选)
    --seven-zip   7-Zip 可执行文件路径 (默认: C:\Program Files\7-Zip\7z.exe)
"""

import argparse
import os
import subprocess
import sys
import time


def check_dependency(seven_zip_path):
    """检查依赖是否满足"""
    if not os.path.exists(seven_zip_path):
        print(f"ERROR: 7-Zip not found at {seven_zip_path}")
        print("  Please install 7-Zip from https://7-zip.org/")
        sys.exit(1)

    try:
        import cloudconvert
        import requests
    except ImportError as e:
        print(f"ERROR: Missing Python package: {e}")
        print("  Run: pip install cloudconvert requests")
        sys.exit(1)


def zip_with_7zip(source_path, zip_path, seven_zip_path):
    """用 7-Zip 将源文件/目录打包成 ZIP"""
    # 如果 source_path 是目录，需要处理路径
    source_dir = os.path.dirname(source_path)
    source_name = os.path.basename(source_path.rstrip("\\/"))

    if os.path.isdir(source_path):
        cmd = [seven_zip_path, "a", "-tzip", zip_path, source_name]
        cwd = source_dir
    else:
        cmd = [seven_zip_path, "a", "-tzip", zip_path, source_path]
        cwd = None

    print(f"[1/4] 打包 ZIP: {source_path}")
    result = subprocess.run(cmd, capture_output=True, text=True, cwd=cwd)
    if result.returncode != 0:
        print(f"ERROR: 7-Zip failed: {result.stderr}")
        sys.exit(1)

    file_size_mb = os.path.getsize(zip_path) / (1024 * 1024)
    print(f"  ✓ ZIP 创建成功: {zip_path} ({file_size_mb:.1f} MB)")
    return zip_path


def convert_zip_to_rar(api_key, zip_path, rar_path):
    """用 CloudConvert API 将 ZIP 转换为 RAR"""
    import cloudconvert
    import requests

    cloudconvert.configure(api_key=api_key, sandbox=False)

    print(f"[2/4] 上传 ZIP 到 CloudConvert...")

    # 创建 Job
    job = cloudconvert.Job.create(payload={
        "tasks": {
            "upload": {
                "operation": "import/upload"
            },
            "convert": {
                "operation": "convert",
                "input": "upload",
                "input_format": "zip",
                "output_format": "rar"
            },
            "export": {
                "operation": "export/url",
                "input": "convert"
            }
        }
    })

    upload_task = job["tasks"][0]
    upload_task_id = upload_task["id"]

    # 上传文件
    res = cloudconvert.Task.upload(
        file_name=os.path.basename(zip_path),
        file_path=zip_path,
        task_id=upload_task_id
    )
    print(f"  ✓ 上传完成")

    # 等待转换完成
    print(f"[3/4] CloudConvert 转换中...")
    job = cloudconvert.Job.wait(id=job["id"])

    # 检查是否成功
    for task in job["tasks"]:
        if task.get("status") == "error":
            print(f"ERROR: Task '{task['name']}' failed: {task.get('message', 'unknown error')}")
            sys.exit(1)

    # 获取下载链接
    export_task = [t for t in job["tasks"] if t["name"] == "export"][0]
    download_url = export_task["result"]["files"][0]["url"]

    # 下载 RAR 文件
    print(f"[4/4] 下载 RAR...")
    response = requests.get(download_url, stream=True)
    with open(rar_path, "wb") as f:
        for chunk in response.iter_content(chunk_size=8192):
            f.write(chunk)

    file_size_mb = os.path.getsize(rar_path) / (1024 * 1024)
    print(f"  ✓ RAR 下载完成: {rar_path} ({file_size_mb:.1f} MB)")
    return rar_path


def main():
    parser = argparse.ArgumentParser(description="ZIP → RAR 自动转换工具")
    parser.add_argument("--api-key", required=True, help="CloudConvert API Key")
    parser.add_argument("--source", required=True, help="要压缩的源文件或目录路径")
    parser.add_argument("--output-dir", required=True, help="输出目录")
    parser.add_argument("--cleanup", action="store_true", help="转换完成后删除中间 ZIP 文件")
    parser.add_argument("--seven-zip", default=r"C:\Program Files\7-Zip\7z.exe", help="7-Zip 路径")

    args = parser.parse_args()

    # 检查依赖
    check_dependency(args.seven_zip)

    # 检查源路径
    if not os.path.exists(args.source):
        print(f"ERROR: 源路径不存在: {args.source}")
        sys.exit(1)

    # 创建输出目录
    os.makedirs(args.output_dir, exist_ok=True)

    # 生成文件名
    base_name = os.path.basename(args.source.rstrip("\\/"))
    if os.path.isdir(args.source):
        name_without_ext = base_name
    else:
        name_without_ext = os.path.splitext(base_name)[0]

    zip_path = os.path.join(args.output_dir, f"{name_without_ext}.zip")
    rar_path = os.path.join(args.output_dir, f"{name_without_ext}.rar")

    print(f"=== ZIP → RAR 转换 ===")
    print(f"源: {args.source}")
    print(f"目标: {rar_path}")
    print()

    # Step 1: 打包 ZIP
    zip_with_7zip(args.source, zip_path, args.seven_zip)

    # Step 2-4: 上传、转换、下载
    convert_zip_to_rar(args.api_key, zip_path, rar_path)

    # 清理临时 ZIP
    if args.cleanup:
        try:
            os.remove(zip_path)
            print(f"\n  清理临时 ZIP: {zip_path}")
        except OSError:
            pass

    print(f"\n✅ 完成！RAR 文件: {rar_path}")


if __name__ == "__main__":
    main()

---
name: zip-to-rar
description: "将文件或目录打包为 RAR 压缩包。当用户要求将文件转成 RAR 格式、打包成 RAR、生成 RAR 压缩包、或者任何需要 RAR 格式输出的场景时使用此 Skill。触发词：RAR、打包成RAR、转RAR、压缩成RAR、生成RAR。"
---

# ZIP → RAR 转换工具

## 概述

将文件或目录打包为 RAR 格式压缩包。由于 RAR 是 WinRAR 公司的专有格式，只有 WinRAR 的 rar.exe 才能创建 RAR 文件。本 Skill 通过以下流程实现：

1. **7-Zip** 将源文件/目录打包为 ZIP
2. **CloudConvert API** 将 ZIP 在线转换为 RAR
3. 下载 RAR 文件到本地

## 前置条件

### 系统依赖
- **7-Zip**：默认路径 `C:\Program Files\7-Zip\7z.exe`，用于本地打包 ZIP
- **Python 依赖**：`cloudconvert`、`requests`

### CloudConvert API Key
- 需要用户提供 CloudConvert API Key
- 免费注册地址：https://cloudconvert.com/register
- API Key 获取：Dashboard → API → API Keys → Create API Key
- 免费额度：每天 25 次转换，单文件最大 1GB
- 如果用户没有 API Key，引导其注册获取

## 使用流程

### 1. 获取源文件
- 如果用户通过企微发送了文件附件，先下载到本地临时目录
- 如果用户指定了本地路径，直接使用

### 2. 执行转换
运行脚本：

```bash
python scripts/zip_to_rar.py \
  --api-key <CLOUDCONVERT_API_KEY> \
  --source <源文件或目录路径> \
  --output-dir <输出目录> \
  --cleanup
```

参数说明：
- `--api-key`：CloudConvert API Key（必填）
- `--source`：要压缩的文件或目录（必填）
- `--output-dir`：输出目录，默认使用 `D:\WorkBuddyOutput\YYYY-MM\`（必填）
- `--cleanup`：转换完成后删除中间 ZIP 文件（推荐加上）
- `--seven-zip`：7-Zip 路径，默认 `C:\Program Files\7-Zip\7z.exe`（可选）

### 3. 输出结果
- RAR 文件保存到 `--output-dir` 指定目录
- 文件名与源文件同名，扩展名改为 `.rar`
- 通过 `deliver_attachments` 将 RAR 文件发送给用户

## 注意事项

1. **API Key 隐私**：不要在日志或输出中打印完整的 API Key
2. **文件大小**：CloudConvert 免费版单文件最大 1GB，超出需升级
3. **网络依赖**：转换过程需要上传和下载，网速慢时可能耗时较长
4. **转换额度**：每天 25 次，注意不要浪费在测试上
5. **7-Zip 不可用**：如果系统没有 7-Zip，提示用户安装或改用 Python 的 zipfile 模块替代打包步骤
6. **中间文件**：加上 `--cleanup` 参数自动清理中间 ZIP 文件

## 故障排查

| 问题 | 原因 | 解决方案 |
|------|------|---------|
| `7-Zip not found` | 7-Zip 未安装或路径不对 | 安装 7-Zip 或用 `--seven-zip` 指定路径 |
| `Unauthenticated` | API Key 无效或过期 | 重新生成 API Key |
| `Task 'convert' failed` | 文件格式不支持或损坏 | 检查源文件是否正常 |
| 下载超时 | 网络问题 | 重试 |

# TKE Web 服务部署快速入门

> 版本：v2.0
> 最后更新：2026-04-15

## 快速开始（5 分钟）

### 第一步：获取 JWT Token

**⚠️ 重要**：部署服务必须先获取 JWT Token，Token 无法找回！

1. **联系管理员**
   - 📧 邮件：tangqijun@example.com
   - 💬 微信：13681949855

2. **提供信息**
   - 姓名：张三
   - 工号：12345
   - 部门：研发部

3. **获取 Token**
   ```
   eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6InpoYW5nc2FuIiwibmFtZXNwYWNlIjoidXNlci16aGFuZ3NhbiJ9...
   ```

4. **配置 Token**
   ```bash
   export TKE_JWT_TOKEN="your-token-here"
   ```

### 第二步：准备工程代码

创建一个简单的 Vue + SQLite 应用：

```bash
mkdir demo-app
cd demo-app

# 创建目录结构
mkdir frontend database

# 创建 project.yaml
cat > project.yaml <<EOF
name: demo-app
version: 1.0.0
description: 演示应用

components:
  - name: frontend
    type: frontend
    framework: vue
    version: 18
    port: 80
    path: ./frontend
    
  - name: database
    type: database
    framework: sqlite
    path: ./database
    storage: 1Gi
EOF

# 创建数据库初始化脚本
cat > database/init.sql <<EOF
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL
);

INSERT INTO users (name, email) VALUES 
    ('张三', 'zhangsan@example.com'),
    ('李四', 'lisi@example.com');
EOF

# 创建前端代码（简化示例）
cat > frontend/index.html <<EOF
<!DOCTYPE html>
<html>
<head>
    <title>Demo App</title>
</head>
<body>
    <h1>Hello TKE!</h1>
</body>
</html>
EOF
```

### 第三步：部署到云端

**方法 1：使用小龙虾（推荐）**

对小龙虾说：
```
帮我部署 demo-app
```

**方法 2：使用 Skill 脚本**

```bash
python3 skill/scripts/deploy.py --path=demo-app
```

### 第四步：访问应用

部署成功后，会返回访问地址：
```
✅ 部署成功！你的应用已经上线。

📋 服务信息：
   - 服务名称: demo-app
   - 访问地址: http://10.225.9.142:30001

💡 提示：
   - 在浏览器中打开 http://10.225.9.142:30001 即可访问你的应用
   - 数据库文件已持久化存储，重启不会丢失
   - 如需更新，重新部署即可（服务名称相同会自动覆盖）
```

在浏览器中打开即可访问！

## 工作流程详解

### 1. 检查 JWT Token

Skill 会检查以下位置：
1. 环境变量 `TKE_JWT_TOKEN`
2. 配置文件 `~/.tke/config`
3. Skill 配置 `~/.workbuddy/skills/tke-deploy/config.json`

如果未配置，会提示：
```
❌ 未检测到 JWT Token，无法部署服务。

请按以下步骤获取 Token：
1. 联系管理员：tangqijun@example.com 或微信 13681949855
2. 提供你的姓名和工号，申请创建账号
3. 获取 JWT Token 后，配置到环境变量：
   export TKE_JWT_TOKEN="your-token-here"

⚠️ 注意：Token 无法找回，请妥善保管。
```

### 2. 分析工程类型

Skill 会自动分析：
- ✅ 前端框架（Vue/React/Static）
- ✅ 后端框架（Flask/Django/FastAPI/Express/Spring）
- ✅ 数据库类型（SQLite/MySQL/PostgreSQL/MongoDB/Redis）

示例输出：
```
📁 分析工程: /Users/openclaw/demo-app
   ✅ 检测到 package.json: /Users/openclaw/demo-app/frontend/package.json
   ✅ 检测到 Vue 框架
   ✅ 检测到 SQLite 数据库文件: 1 个
```

### 3. 判断是否支持

如果工程不支持，会提示：
```
❌ 不支持该工程类型

你的工程：
   - 类型: backend
   - 框架: unknown
   - 数据库: mysql

网关支持：
   - 前端框架: Vue, React, Static
   - 后端框架: Flask, Django, FastAPI, Express, Spring
   - 数据库: SQLite（完整支持）
   - 其他数据库: MySQL/PostgreSQL/MongoDB/Redis（无 PVC，不推荐）

建议：
   - 使用 SQLite 数据库替代其他数据库
   - 或联系管理员了解如何使用外部数据库服务
```

### 4. 验证工程格式

如果工程格式不符合要求，Skill 会调用本地模型调整：
```
=== 验证工程格式 ===
🔍 检查工程目录结构...
✅ 工程格式符合要求
```

### 5. 自动打包

如果工程未打包，Skill 会自动创建 zip 文件：
```
=== 打包工程 ===
📦 打包工程到: /var/folders/xxx/demo-app.zip
✅ 打包完成: /var/folders/xxx/demo-app.zip
```

### 6. 部署服务

```
=== 上传代码包 ===
📤 上传: /var/folders/xxx/demo-app.zip
✅ 上传成功: /tmp/uploads/demo-app.zip

=== 部署服务 ===
🚀 服务名称: demo-app
✅ 部署成功!
```

### 7. 转换结果

Skill 会将 API 结果转换为用户可理解的措辞：
```
=== 部署结果 ===
✅ 部署成功！你的应用已经上线。

📋 服务信息：
   - 服务名称: demo-app
   - 访问地址: http://10.225.9.142:30001

💡 提示：
   - 在浏览器中打开 http://10.225.9.142:30001 即可访问你的应用
   - 数据库文件已持久化存储，重启不会丢失
   - 如需更新，重新部署即可（服务名称相同会自动覆盖）
```

## 常见问题

### 1. 如何查看部署日志？

**方法 1：使用 kubectl**
```bash
kubectl logs -f demo-app-xxx -n user-zhangsan
```

**方法 2：使用 API**
```bash
curl -H "Authorization: Bearer $TKE_JWT_TOKEN" \
  https://devops.dicos.com.cn/api/v1/services/demo-app/logs
```

### 2. 如何查看服务状态？

**方法 1：使用 kubectl**
```bash
kubectl get pods -n user-zhangsan
kubectl get svc -n user-zhangsan
kubectl get pvc -n user-zhangsan
```

**方法 2：使用 Skill 脚本**
```bash
python3 skill/scripts/list_services.py
```

### 3. 如何删除服务？

**方法 1：使用小龙虾**

对小龙虾说：
```
帮我删除 demo-app 服务
```

**方法 2：使用 Skill 脚本**
```bash
python3 skill/scripts/delete_service.py --name=demo-app
```

### 4. 如何更新服务？

重新部署即可，服务名称相同会自动覆盖：
```bash
python3 skill/scripts/deploy.py --path=demo-app
```

### 5. Token 丢失了怎么办？

Token 无法找回，需要重新申请：
1. 联系管理员：tangqijun@example.com 或微信 13681949855
2. 说明情况，申请重新生成 Token
3. 旧 Token 会自动失效

### 6. 如何查看我的命名空间和配额？

Token 已绑定你的账号信息，无需手动查看。部署时会自动使用你的命名空间和配额。

## 进阶用法

### 1. 自定义存储大小

修改 `project.yaml`：
```yaml
- name: database
  type: database
  framework: sqlite
  path: ./database
  storage: 5Gi  # 修改为 5Gi
```

### 2. 使用 React 框架

修改 `project.yaml`：
```yaml
- name: frontend
  type: frontend
  framework: react  # 改为 react
  version: 18
  port: 80
  path: ./frontend
```

### 3. 使用 Python Flask

修改 `project.yaml`：
```yaml
components:
  - name: backend
    type: backend
    framework: flask
    version: 3.9
    port: 5000
    path: .
```

### 4. 多个数据库初始化脚本

```
database/
├── 01-create-tables.sql
├── 02-insert-data.sql
└── 03-create-index.sql
```

脚本会按文件名顺序执行。

## 目录结构示例

### Vue + SQLite

```
demo-app/
├── project.yaml
├── README.md
├── frontend/
│   ├── package.json
│   ├── src/
│   │   ├── App.vue
│   │   └── main.js
│   └── public/
│       └── index.html
└── database/
    ├── init.sql
    └── app.db
```

### React + SQLite

```
demo-app/
├── project.yaml
├── README.md
├── frontend/
│   ├── package.json
│   ├── src/
│   │   ├── App.js
│   │   └── index.js
│   └── public/
│       └── index.html
└── database/
    └── init.sql
```

### 静态页面

```
demo-app/
├── project.yaml
├── index.html
├── style.css
└── script.js
```

## 技术栈支持

| 技术栈 | 框架 | 版本 | 基础镜像 |
|:---|:---|:---|:---|
| Vue | vue | 18 | node:18-alpine + nginx:alpine |
| React | react | 18 | node:18-alpine + nginx:alpine |
| Static | static | latest | nginx:alpine |
| Python | flask | 3.9 | python:3.9-slim |
| Node.js | express | 18 | node:18-alpine |
| SQLite | sqlite | latest | nginx:alpine + sqlite |

## 资源配额

每个用户账号已绑定固定的资源配额：

| 资源 | 配额 |
|:---|:---|
| CPU 请求 | 1 核 |
| CPU 限制 | 2 核 |
| 内存请求 | 1Gi |
| 内存限制 | 2Gi |
| PVC 数量 | 3 个 |
| Pod 数量 | 5 个 |

**注意**：资源配额由管理员分配，用户无法更改。

## 下一步

- 📖 阅读 [project.yaml 配置规范](references/project-yaml-spec.md)
- 🚀 部署你的第一个应用
- 💬 加入用户群交流

## 获取帮助

- 📧 邮件：tangqijun@example.com
- 💬 微信：13681949855
- 📖 文档：https://devops.dicos.com.cn/docs

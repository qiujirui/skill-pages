# TKE Web 服务部署 Skill

一键部署 Web 服务到腾讯云 TKE 集群。

## 快速开始

### 1. 获取 JWT Token

联系管理员获取 JWT Token：
- 📧 邮件：tangqijun@example.com
- 💬 微信：13681949855

### 2. 配置 Token

```bash
export TKE_JWT_TOKEN="your-token-here"
```

### 3. 部署服务

对小龙虾说：
```
帮我部署 my-project
```

或使用脚本：
```bash
python3 scripts/deploy.py --path=/path/to/project
```

## 文档

- [SKILL.md](SKILL.md) - 完整功能说明
- [QUICKSTART.md](QUICKSTART.md) - 快速入门指南

## 支持的工程类型

- **前端**：Vue, React, Static
- **后端**：Flask, Django, FastAPI, Express, Spring
- **数据库**：SQLite（完整支持）

## 联系方式

- 📧 邮件：tangqijun@example.com
- 💬 微信：13681949855

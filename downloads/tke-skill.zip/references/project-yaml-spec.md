# project.yaml 配置规范

> 版本：v1.0
> 最后更新：2026-04-15

## 概述

`project.yaml` 是 TKE Web 服务部署平台的工程配置文件，用于描述工程的组件、运行时、数据库等信息。

## 完整示例

```yaml
name: demo-app
version: 1.0.0
description: 演示应用 - Vue 前端 + SQLite 数据库

components:
  # 前端组件
  - name: frontend
    type: frontend
    framework: vue
    version: 18
    port: 80
    path: ./frontend
    
  # 数据库组件
  - name: database
    type: database
    framework: sqlite
    version: latest
    port: 0
    path: ./database
    storage: 1Gi
    
  # 后端组件（可选）
  - name: backend
    type: backend
    framework: flask
    version: 3.9
    port: 5000
    path: ./backend
```

## 字段说明

### 顶层字段

| 字段 | 类型 | 必填 | 说明 |
|:---|:---|:---|:---|
| `name` | string | 是 | 工程名称（小写字母、数字、中划线） |
| `version` | string | 否 | 工程版本（默认 `1.0.0`） |
| `description` | string | 否 | 工程描述 |
| `components` | array | 是 | 组件列表 |

### 组件字段

| 字段 | 类型 | 必填 | 说明 |
|:---|:---|:---|:---|
| `name` | string | 是 | 组件名称（小写字母、数字、中划线） |
| `type` | string | 是 | 组件类型（frontend/backend/database） |
| `framework` | string | 是 | 框架类型 |
| `version` | string | 否 | 版本号 |
| `port` | integer | 是 | 端口号 |
| `path` | string | 是 | 代码路径（相对路径） |
| `storage` | string | 否 | 存储大小（仅数据库组件，默认 `1Gi`） |

## 组件类型

### 1. frontend（前端组件）

**支持的框架**：
- `vue`: Vue.js 单页应用
- `react`: React 单页应用
- `static`: 静态页面

**示例**：
```yaml
- name: frontend
  type: frontend
  framework: vue
  version: 18
  port: 80
  path: ./frontend
```

**构建流程**：
1. 使用 `node:18-alpine` 构建
2. 使用 `nginx:alpine` 运行
3. 前端代码部署到 `/usr/share/nginx/html`

### 2. backend（后端组件）

**支持的框架**：
- `flask`: Python Flask 应用
- `express`: Node.js Express 应用

**示例**：
```yaml
- name: backend
  type: backend
  framework: flask
  version: 3.9
  port: 5000
  path: ./backend
```

**构建流程**：
1. Python: 使用 `python:3.9-slim`
2. Node.js: 使用 `node:18-alpine`

### 3. database（数据库组件）

**支持的框架**：
- `sqlite`: SQLite 文件数据库
- `mysql`: MySQL 数据库（未实现）
- `postgresql`: PostgreSQL 数据库（未实现）

**示例**：
```yaml
- name: database
  type: database
  framework: sqlite
  version: latest
  port: 0
  path: ./database
  storage: 1Gi
```

**字段兼容性**：
- `framework` 字段支持多种写法：`sqlite`, `sqlite3`, `SQLite`, `SQLITE`
- 兼容字段名：`engine`, `framework`, `db`, `database`
- 如果 `type: database` 但没有明确引擎，默认为 SQLite

**构建流程**：
1. SQLite 数据库会合并到前端组件（同一个容器）
2. 数据库文件存储在 `/var/lib/data`（PVC 挂载）
3. 初始化脚本：`path` 目录下的 `.sql` 文件

## 数据库初始化脚本

**位置**：数据库组件 `path` 目录下的 `.sql` 文件

**示例**：
```
database/
├── init.sql
└── app.db
```

**执行时机**：
- 容器启动时，如果 `/var/lib/data/app.db` 不存在，则执行初始化脚本
- 初始化脚本按文件名顺序执行
- 执行后数据库文件持久化到 PVC

## 自动检测

**如果没有 `project.yaml`，网关会自动检测工程类型**：

### 1. 前端检测规则

| 检测规则 | 框架类型 |
|:---|:---|
| `package.json` + `vue` 关键词 | Vue |
| `package.json` + `react` 关键词 | React |
| `*.html` 文件 | Static |

### 2. 数据库检测规则

| 检测规则 | 数据库类型 |
|:---|:---|
| `.db` / `.sqlite` / `.sqlite3` 文件 | SQLite |
| `README.md` 中 `sqlite` 关键词 | SQLite |

### 3. 后端检测规则

| 检测规则 | 框架类型 |
|:---|:---|
| `requirements.txt` / `app.py` / `main.py` | Flask |
| `package.json`（无 vue/react） | Express |

## 最佳实践

### 1. 目录结构

```
my-project/
├── project.yaml          # 工程配置文件
├── README.md             # 工程说明文档
├── frontend/             # 前端代码目录
│   ├── package.json
│   └── src/
├── database/             # 数据库目录
│   ├── init.sql
│   └── app.db
└── backend/              # 后端代码目录（可选）
    ├── app.py
    └── requirements.txt
```

### 2. 命名规范

- 工程名称：小写字母、数字、中划线（如 `demo-app`）
- 组件名称：小写字母、数字、中划线（如 `frontend`）
- 命名空间：`user-{用户名}`（如 `user-tangqijun`）

### 3. 存储大小

- SQLite 数据库：默认 `1Gi`
- 可根据实际需求调整（如 `2Gi`、`5Gi`）
- 受命名空间 PVC 配额限制（最多 3 个）

### 4. 端口配置

| 组件类型 | 默认端口 | 说明 |
|:---|:---|:---|
| frontend | 80 | nginx 默认端口 |
| backend (flask) | 5000 | Flask 默认端口 |
| backend (express) | 3000 | Express 默认端口 |
| database (sqlite) | 0 | SQLite 无端口 |

## 错误排查

### 1. 配置文件语法错误

**错误信息**：
```
❌ Failed to parse project.yaml: ...
```

**解决方法**：
- 检查 YAML 语法（缩进、引号、冒号）
- 使用 YAML 验证工具：https://www.yamllint.com/

### 2. 组件类型不支持

**错误信息**：
```
❌ Unknown component type: xxx
```

**解决方法**：
- 检查 `type` 字段是否正确（frontend/backend/database）

### 3. 框架类型不支持

**错误信息**：
```
❌ Unknown framework: xxx
```

**解决方法**：
- 检查 `framework` 字段是否正确
- 前端：vue/react/static
- 后端：flask/express
- 数据库：sqlite

## 示例工程

### 1. Vue + SQLite

```yaml
name: vue-sqlite-app
version: 1.0.0

components:
  - name: frontend
    type: frontend
    framework: vue
    version: 18
    port: 80
    path: ./frontend
    
  - name: database
    type: database
    framework: sqlite
    version: latest
    port: 0
    path: ./database
    storage: 1Gi
```

### 2. React + SQLite

```yaml
name: react-sqlite-app
version: 1.0.0

components:
  - name: frontend
    type: frontend
    framework: react
    version: 18
    port: 80
    path: ./frontend
    
  - name: database
    type: database
    framework: sqlite
    path: ./database
```

### 3. 静态页面

```yaml
name: static-app
version: 1.0.0

components:
  - name: frontend
    type: frontend
    framework: static
    version: latest
    port: 80
    path: .
```

### 4. Python Flask

```yaml
name: flask-app
version: 1.0.0

components:
  - name: backend
    type: backend
    framework: flask
    version: 3.9
    port: 5000
    path: .
```

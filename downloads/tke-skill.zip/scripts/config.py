#!/usr/bin/env python3
"""
TKE 部署配置管理
首次使用前配置 DEPLOY_TOKEN，验证连接状态
"""

import argparse
import json
import os
import sys

CONFIG_DIR = os.path.expanduser("~/.tke-deploy")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")

DEFAULT_API_BASE = "https://deploy-api.yourcompany.com"


def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    return {}


def save_config(config):
    os.makedirs(CONFIG_DIR, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)
    # 设置文件权限，仅用户可读写
    os.chmod(CONFIG_FILE, 0o600)


def cmd_token(args):
    """配置部署 Token"""
    config = load_config()
    config["deploy_token"] = args.token
    if args.api_base:
        config["api_base"] = args.api_base
    else:
        config.setdefault("api_base", DEFAULT_API_BASE)
    save_config(config)
    print(f"✅ 配置已保存到 {CONFIG_FILE}")
    print(f"   API 地址：{config['api_base']}")
    print(f"   Token：{args.token[:8]}...（已隐藏）")
    print()
    print("💡 接下来请运行以下命令验证配置：")
    print("   python3 scripts/config.py --check")


def cmd_check(args):
    """验证配置和连接"""
    config = load_config()

    if not config.get("deploy_token"):
        print("❌ 未配置 Token，请先运行：")
        print("   python3 scripts/config.py --token <你的DEPLOY_TOKEN>")
        sys.exit(1)

    api_base = config.get("api_base", DEFAULT_API_BASE)
    token = config["deploy_token"]

    print(f"📋 配置信息：")
    print(f"   API 地址：{api_base}")
    print(f"   Token：{token[:8]}...")
    print()

    # 验证 Token 有效性
    print("🔍 验证 Token 有效性...")
    try:
        import urllib.request
        import urllib.error

        req = urllib.request.Request(
            f"{api_base}/api/v1/auth/verify",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            method="GET",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read().decode("utf-8"))

        if result.get("code") == 0:
            user_info = result.get("data", {})
            print(f"✅ Token 有效！")
            print(f"   用户：{user_info.get('username', 'unknown')}")
            print(f"   命名空间：{user_info.get('namespace', 'unknown')}")
            print(f"   资源配额：")
            quota = user_info.get("quota", {})
            print(f"     CPU：{quota.get('cpu_used', '0')}/{quota.get('cpu_limit', '?')}")
            print(f"     内存：{quota.get('memory_used', '0')}/{quota.get('memory_limit', '?')}")
            print(f"     服务数：{quota.get('services_used', 0)}/{quota.get('services_limit', '?')}")
            print(f"     磁盘：{quota.get('storage_used', '0')}/{quota.get('storage_limit', '?')}")
        else:
            print(f"❌ Token 验证失败：{result.get('message', '未知错误')}")
            sys.exit(1)
    except Exception as e:
        print(f"❌ 连接失败：{e}")
        print()
        print("💡 可能的原因：")
        print("   1. API 服务未启动")
        print("   2. 网络连接问题")
        print("   3. Token 无效")
        sys.exit(1)


def cmd_show(args):
    """显示当前配置"""
    config = load_config()
    if not config:
        print("📋 尚未配置")
        print("   运行以下命令开始配置：")
        print("   python3 scripts/config.py --token <你的DEPLOY_TOKEN>")
        return

    print("📋 当前配置：")
    print(f"   配置文件：{CONFIG_FILE}")
    print(f"   API 地址：{config.get('api_base', DEFAULT_API_BASE)}")
    token = config.get("deploy_token", "")
    if token:
        print(f"   Token：{token[:8]}...（已配置）")
    else:
        print(f"   Token：未配置")


def main():
    parser = argparse.ArgumentParser(description="TKE 部署配置管理")
    subparsers = parser.add_subparsers(dest="command", help="子命令")

    # token 命令
    p_token = subparsers.add_parser("token", help="配置部署 Token")
    p_token.add_argument("token", help="部署 Token（从管理员处获取）")
    p_token.add_argument("--api-base", help="API 服务地址（可选）")

    # check 命令
    subparsers.add_parser("check", help="验证配置和连接")

    # show 命令
    subparsers.add_parser("show", help="显示当前配置")

    args = parser.parse_args()

    if args.command == "token":
        cmd_token(args)
    elif args.command == "check":
        cmd_check(args)
    elif args.command == "show":
        cmd_show(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
TKE 服务日志查看
"""

import argparse
import json
import sys
import time
import urllib.error
import urllib.request

CONFIG_DIR = os.path.expanduser("~/.tke-deploy")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")
DEFAULT_API_BASE = "https://deploy-api.yourcompany.com"


def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    return {}


def api_request(method, path, params=None):
    config = load_config()
    api_base = config.get("api_base", DEFAULT_API_BASE)
    token = config.get("deploy_token", "")

    if not token:
        print("❌ 未配置 Token")
        sys.exit(1)

    url = f"{api_base}{path}"
    if params:
        query = "&".join(f"{k}={v}" for k, v in params.items())
        url += f"?{query}"

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    req = urllib.request.Request(url, headers=headers, method=method)

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8")
        try:
            return json.loads(body)
        except json.JSONDecodeError:
            return {"code": -1, "message": f"HTTP {e.code}"}
    except Exception as e:
        return {"code": -1, "message": str(e)}


def cmd_logs(args):
    """查看服务日志"""
    if not args.name:
        print("❌ 请指定服务名称：--name <service-name>")
        sys.exit(1)

    params = {"tail": str(args.tail)}
    if args.since:
        params["since"] = args.since

    result = api_request("GET", f"/api/v1/services/logs/{args.name}", params=params)

    if result.get("code") != 0:
        print(f"❌ 获取日志失败：{result.get('message', '未知错误')}")
        sys.exit(1)

    logs = result.get("data", {}).get("logs", "")

    if not logs:
        print(f"📋 服务 [{args.name}] 暂无日志")
        return

    print(f"📋 服务 [{args.name}] 最近日志（{args.tail} 行）：")
    print("-" * 60)
    print(logs)
    print("-" * 60)

    if args.follow:
        print("🔄 实时跟踪日志中（Ctrl+C 退出）...")
        last_timestamp = result.get("data", {}).get("last_timestamp", "")

        try:
            while True:
                time.sleep(3)
                params["since"] = last_timestamp
                params["tail"] = "50"
                result = api_request("GET", f"/api/v1/services/logs/{args.name}", params=params)

                if result.get("code") != 0:
                    time.sleep(2)
                    continue

                new_logs = result.get("data", {}).get("logs", "")
                last_timestamp = result.get("data", {}).get("last_timestamp", last_timestamp)

                if new_logs:
                    print(new_logs, end="", flush=True)
        except KeyboardInterrupt:
            print()
            print("✅ 已停止跟踪")


def main():
    parser = argparse.ArgumentParser(description="TKE 服务日志查看")
    parser.add_argument("--name", required=True, help="服务名称")
    parser.add_argument("--tail", type=int, default=50, help="最近 N 行日志（默认 50）")
    parser.add_argument("--since", help="从此时间戳开始的日志")
    parser.add_argument("--follow", action="store_true", help="实时跟踪日志")

    args = parser.parse_args()
    cmd_logs(args)


if __name__ == "__main__":
    main()

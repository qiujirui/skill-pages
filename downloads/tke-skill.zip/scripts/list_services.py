#!/usr/bin/env python3
"""
查看服务列表

用法：
    python3 list_services.py --namespace=user-username
"""

import argparse
import requests
import json
import os

# 网关地址
GATEWAY_URL = os.getenv('TKE_GATEWAY_URL', 'https://devops.dicos.com.cn/api/v1')

def list_services(namespace):
    """列出所有服务"""
    url = f"{GATEWAY_URL}/services"
    
    params = {'namespace': namespace}
    
    response = requests.get(url, params=params)
    
    if response.status_code == 200:
        result = response.json()
        services = result.get('services', [])
        
        if not services:
            print(f"📭 命名空间 {namespace} 中没有服务")
            return
        
        print(f"📋 命名空间 {namespace} 中的服务:")
        print()
        for svc in services:
            print(f"  • {svc.get('name')}")
            print(f"    状态: {svc.get('status')}")
            print(f"    地址: {svc.get('url')}")
            print(f"    创建时间: {svc.get('created_at')}")
            print()
    else:
        print(f"❌ 查询失败: {response.status_code} {response.text}")

def main():
    parser = argparse.ArgumentParser(description='查看 TKE 服务列表')
    parser.add_argument('--namespace', required=True, help='命名空间（如 user-tangqijun）')
    
    args = parser.parse_args()
    
    list_services(args.namespace)

if __name__ == '__main__':
    main()

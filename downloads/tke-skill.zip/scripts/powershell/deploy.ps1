#Requires -Version 5.1
<#
.SYNOPSIS
    TKE Web 服务部署脚本 (PowerShell版本) - 兼容 Windows ACP 模式
.DESCRIPTION
    一键部署 Web 服务到腾讯云 TKE 集群
    使用方法: .\deploy.ps1 -Path C:\path\to\project
.PARAMETER Path
    工程路径或zip文件路径
.PARAMETER Name
    服务名称（可选，默认使用工程目录名）
.EXAMPLE
    .\deploy.ps1 -Path C:\my-project
    .\deploy.ps1 -Path C:\my-project.zip -Name my-service
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$Path,
    
    [string]$Name = ""
)

# 配置
$Script:BaseUrl = "https://aitools-api.dicos.com.cn/api/v1"
$Script:ConfigPath = Join-Path $env:USERPROFILE ".workbuddy\skills\tke-deploy\config.json"

# 获取 Token
function Get-JwtToken {
    # 环境变量
    $token = $env:TKE_JWT_TOKEN
    if ($token) { return $token }
    
    # 配置文件 ~/.tke/config
    $tkeConfig = Join-Path $env:USERPROFILE ".tke\config"
    if (Test-Path $tkeConfig) {
        $content = Get-Content $tkeConfig -Raw
        if ($content -match 'TKE_JWT_TOKEN="([^"]+)"') {
            return $matches[1]
        }
    }
    
    # Skill 配置
    if (Test-Path $Script:ConfigPath) {
        $config = Get-Content $Script:ConfigPath | ConvertFrom-Json
        return $config.jwt_token
    }
    
    return $null
}

# API 请求
function Invoke-TkeApi {
    param(
        [string]$Method = "GET",
        [string]$Endpoint,
        [object]$Body = $null,
        [string]$Token
    )
    
    $url = "$Script:BaseUrl$Endpoint"
    $headers = @{
        "Authorization" = "Bearer $Token"
    }
    
    $params = @{
        Uri = $url
        Method = $Method
        Headers = $headers
        TimeoutSec = 300
        UseBasicParsing = $true
    }
    
    if ($Body) {
        if ($Body -is [string]) {
            $params["Body"] = $Body
            $headers["Content-Type"] = "application/json"
        } else {
            $params["Body"] = ($Body | ConvertTo-Json)
            $headers["Content-Type"] = "application/json"
        }
    }
    
    try {
        $response = Invoke-RestMethod @params
        return @{ Success = $true; Data = $response }
    } catch {
        $errorMessage = $_.Exception.Message
        if ($_.Exception.Response) {
            $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
            $errorBody = $reader.ReadToEnd()
            $reader.Close()
            try {
                $errorData = $errorBody | ConvertFrom-Json
                $errorMessage = $errorData.message
            } catch {}
        }
        return @{ Success = $false; Error = $errorMessage }
    }
}

# 打包工程
function New-ProjectZip {
    param([string]$ProjectPath)
    
    $tempDir = [System.IO.Path]::GetTempPath()
    $zipName = "tke-deploy-$(Get-Date -Format 'yyyyMMddHHmmss').zip"
    $zipPath = Join-Path $tempDir $zipName
    
    Write-Host "📦 打包工程..." -ForegroundColor Cyan
    Compress-Archive -Path "$ProjectPath\*" -DestinationPath $zipPath -Force
    
    $size = (Get-Item $zipPath).Length
    Write-Host "   ✅ ZIP创建成功: $([Math]::Round($size/1KB, 2)) KB" -ForegroundColor Green
    
    return $zipPath
}

# 上传代码包
function Send-CodePackage {
    param(
        [string]$ZipPath,
        [string]$ServiceName,
        [string]$Token
    )
    
    Write-Host "⬆️  上传代码包..." -ForegroundColor Cyan
    
    $url = "$Script:BaseUrl/services/upload"
    $boundary = "----WebKitFormBoundary$(Get-Random)"
    
    # 读取文件
    $fileBytes = [System.IO.File]::ReadAllBytes($ZipPath)
    $fileName = Split-Path $ZipPath -Leaf
    
    # 构建 multipart body
    $enc = [System.Text.Encoding]::UTF8
    $body = New-Object System.IO.MemoryStream
    
    # service_name
    $body.Write($enc.GetBytes("--$boundary`r`n"), 0, $boundary.Length + 4)
    $body.Write($enc.GetBytes("Content-Disposition: form-data; name=`"service_name`"`r`n`r`n"), 0, 44)
    $body.Write($enc.GetBytes("$ServiceName`r`n"), 0, $ServiceName.Length + 2)
    
    # description
    $body.Write($enc.GetBytes("--$boundary`r`n"), 0, $boundary.Length + 4)
    $body.Write($enc.GetBytes("Content-Disposition: form-data; name=`"description`"`r`n`r`n"), 0, 45)
    $body.Write($enc.GetBytes("Deployed from PowerShell`r`n"), 0, 26)
    
    # code_package
    $body.Write($enc.GetBytes("--$boundary`r`n"), 0, $boundary.Length + 4)
    $body.Write($enc.GetBytes("Content-Disposition: form-data; name=`"code_package`"; filename=`"$fileName`"`r`n"), 0, 66 + $fileName.Length)
    $body.Write($enc.GetBytes("Content-Type: application/zip`r`n`r`n"), 0, 33)
    $body.Write($fileBytes, 0, $fileBytes.Length)
    $body.Write($enc.GetBytes("`r`n"), 0, 2)
    
    # 结束
    $body.Write($enc.GetBytes("--$boundary--`r`n"), 0, $boundary.Length + 6)
    
    $bodyBytes = $body.ToArray()
    $body.Close()
    
    # 发送请求
    $request = [System.Net.WebRequest]::Create($url)
    $request.Method = "POST"
    $request.ContentType = "multipart/form-data; boundary=$boundary"
    $request.ContentLength = $bodyBytes.Length
    $request.Headers.Add("Authorization", "Bearer $Token")
    $request.Timeout = 300000
    
    $stream = $request.GetRequestStream()
    $stream.Write($bodyBytes, 0, $bodyBytes.Length)
    $stream.Close()
    
    try {
        $response = $request.GetResponse()
        $reader = New-Object System.IO.StreamReader($response.GetResponseStream())
        $result = $reader.ReadToEnd() | ConvertFrom-Json
        $reader.Close()
        
        if ($result.code -eq 0) {
            Write-Host "   ✅ 上传成功" -ForegroundColor Green
            return @{ Success = $true }
        } else {
            return @{ Success = $false; Error = $result.message }
        }
    } catch {
        return @{ Success = $false; Error = $_.Exception.Message }
    }
}

# 触发部署
function Start-Deployment {
    param(
        [string]$ServiceName,
        [string]$Token
    )
    
    Write-Host "🚀 触发部署..." -ForegroundColor Cyan
    Write-Host "   这可能需要几分钟时间..." -ForegroundColor Gray
    
    $body = @{
        service_name = $ServiceName
        description = "Deployed from PowerShell"
    } | ConvertTo-Json
    
    $result = Invoke-TkeApi -Method "POST" -Endpoint "/services/deploy" -Body $body -Token $Token
    
    if ($result.Success -and $result.Data.code -eq 0) {
        $data = $result.Data.data
        Write-Host "   ✅ 部署成功!" -ForegroundColor Green
        Write-Host ""
        Write-Host "🌐 访问地址: $($data.url)" -ForegroundColor Yellow
        Write-Host "📋 NodePort: $($data.node_port)" -ForegroundColor Gray
        return $true
    } else {
        Write-Host "   ❌ 部署失败: $($result.Error)" -ForegroundColor Red
        return $false
    }
}

# 主体逻辑
function Main {
    Write-Host ""
    Write-Host "╔════════════════════════════════════════╗" -ForegroundColor Blue
    Write-Host "║     TKE 部署工具 (PowerShell版本)      ║" -ForegroundColor Blue
    Write-Host "╚════════════════════════════════════════╝" -ForegroundColor Blue
    Write-Host ""
    
    # 1. 获取 Token
    Write-Host "🔑 检查 JWT Token..." -ForegroundColor Cyan
    $token = Get-JwtToken
    if (-not $token) {
        Write-Host "   ❌ 未找到 JWT Token" -ForegroundColor Red
        Write-Host ""
        Write-Host "请配置 Token（三选一）:" -ForegroundColor Yellow
        Write-Host "   1. 环境变量: `$env:TKE_JWT_TOKEN = 'your-token'"
        Write-Host "   2. 配置文件: ~/.tke/config"
        Write-Host "   3. Skill配置: ~/.workbuddy/skills/tke-deploy/config.json"
        exit 1
    }
    Write-Host "   ✅ Token 已加载" -ForegroundColor Green
    
    # 2. 确定服务名称
    $serviceName = if ($Name) { $Name } else { Split-Path $Path -Leaf }
    Write-Host "📋 服务名称: $serviceName" -ForegroundColor Gray
    
    # 3. 检查路径
    if (-not (Test-Path $Path)) {
        Write-Host "   ❌ 路径不存在: $Path" -ForegroundColor Red
        exit 1
    }
    
    # 4. 打包
    $zipPath = ""
    if ($Path -match '\.zip$') {
        $zipPath = $Path
        Write-Host "📦 使用现有 ZIP: $zipPath" -ForegroundColor Gray
    } else {
        $zipPath = New-ProjectZip -ProjectPath $Path
    }
    
    # 5. 上传
    $upload = Send-CodePackage -ZipPath $zipPath -ServiceName $serviceName -Token $token
    if (-not $upload.Success) {
        Write-Host "   ❌ 上传失败: $($upload.Error)" -ForegroundColor Red
        exit 1
    }
    
    # 6. 部署
    $deployed = Start-Deployment -ServiceName $serviceName -Token $token
    
    # 7. 清理
    if ($Path -notmatch '\.zip$') {
        Remove-Item $zipPath -ErrorAction SilentlyContinue
    }
    
    Write-Host ""
    if ($deployed) {
        Write-Host "✅ 部署完成!" -ForegroundColor Green
    } else {
        Write-Host "❌ 部署失败" -ForegroundColor Red
        exit 1
    }
}

# 执行
Main

#!/usr/bin/env python3
"""
TKE 服务状态查询
"""

import argparse
import json
import sys
import urllib.error
import urllib.request

CONFIG_DIR = os.path.expanduser("~/.tke-deploy")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")
DEFAULT_API_BASE = "https://deploy-api.yourcompany.com"


def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    return {}


def api_request(method, path):
    config = load_config()
    api_base = config.get("api_base", DEFAULT_API_BASE)
    token = config.get("deploy_token", "")

    if not token:
        print("❌ 未配置 Token")
        sys.exit(1)

    url = f"{api_base}{path}"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    req = urllib.request.Request(url, headers=headers, method=method)

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8")
        try:
            return json.loads(body)
        except json.JSONDecodeError:
            return {"code": -1, "message": f"HTTP {e.code}"}
    except Exception as e:
        return {"code": -1, "message": str(e)}


def cmd_status(args):
    """查看服务状态"""
    if args.list:
        cmd_list()
        return

    if args.quota:
        cmd_quota()
        return

    if not args.name:
        print("❌ 请指定服务名称：--name <service-name>")
        print("   或使用 --list 查看所有服务")
        sys.exit(1)

    result = api_request("GET", f"/api/v1/services/status/{args.name}")

    if result.get("code") != 0:
        print(f"❌ 查询失败：{result.get('message', '未知错误')}")
        sys.exit(1)

    data = result["data"]

    print(f"📋 服务状态：{args.name}")
    print(f"   阶段：{'🟢 运行中' if data.get('phase') == 'running' else '🔴 ' + data.get('phase', 'unknown')}")
    print(f"   命名空间：{data.get('namespace', 'N/A')}")
    print(f"   访问地址：{data.get('url', 'N/A')}")
    print(f"   健康检查：{data.get('health_url', 'N/A')}")
    print(f"   Pod 状态：{data.get('pod_status', 'N/A')}")
    print(f"   运行时长：{data.get('uptime', 'N/A')}")

    resources = data.get("resources", {})
    if resources:
        print(f"   资源使用：")
        print(f"     CPU：{resources.get('cpu', 'N/A')}")
        print(f"     内存：{resources.get('memory', 'N/A')}")

    conditions = data.get("conditions", [])
    if conditions:
        print(f"   状态详情：")
        for cond in conditions:
            status_icon = "✅" if cond.get("status") == "True" else "❌"
            print(f"     {status_icon} {cond.get('type', '')}: {cond.get('message', '')}")


def cmd_list():
    """列出所有服务"""
    result = api_request("GET", "/api/v1/services")

    if result.get("code") != 0:
        print(f"❌ 查询失败：{result.get('message', '未知错误')}")
        sys.exit(1)

    services = result.get("data", [])

    if not services:
        print("📋 当前没有部署的服务")
        return

    print(f"📋 已部署服务（共 {len(services)} 个）：")
    print(f"   {'服务名称':<25} {'状态':<12} {'运行时长':<15} {'访问地址'}")
    print(f"   {'-'*25} {'-'*12} {'-'*15} {'-'*40}")

    for svc in services:
        phase = svc.get("phase", "unknown")
        status_icon = "🟢" if phase == "running" else ("🟡" if phase == "stopped" else "🔴")
        print(f"   {svc.get('name', ''):<25} {status_icon} {phase:<10} {svc.get('uptime', 'N/A'):<15} {svc.get('url', 'N/A')}")


def cmd_quota():
    """查看资源配额"""
    result = api_request("GET", "/api/v1/auth/verify")

    if result.get("code") != 0:
        print(f"❌ 查询失败：{result.get('message', '未知错误')}")
        sys.exit(1)

    user_info = result["data"]
    quota = user_info.get("quota", {})

    print("📊 资源配额使用情况：")
    print()

    def print_quota_bar(label, used, limit, unit=""):
        if limit and limit > 0:
            pct = min(int(float(used.split(unit)[0]) / float(limit.split(unit)[0]) * 100) if unit else 0, 100)
        else:
            pct = 0
        bar_len = 30
        filled = int(bar_len * pct / 100) if pct > 0 else 0
        bar = "█" * filled + "░" * (bar_len - filled)
        print(f"   {label:<10} {used:>8}/{limit:<8} [{bar}] {pct}%")

    print_quota_bar("CPU", quota.get("cpu_used", "0"), quota.get("cpu_limit", "∞"), "")
    print_quota_bar("内存", quota.get("memory_used", "0"), quota.get("memory_limit", "∞"), "")
    print_quota_bar("磁盘", quota.get("storage_used", "0"), quota.get("storage_limit", "∞"), "")
    print_quota_bar("服务数", str(quota.get("services_used", 0)), str(quota.get("services_limit", "?")), "")

    print()
    print(f"   命名空间：{user_info.get('namespace', 'N/A')}")
    print(f"   用户名：{user_info.get('username', 'N/A')}")


def main():
    parser = argparse.ArgumentParser(description="TKE 服务状态查询")
    parser.add_argument("--name", help="服务名称")
    parser.add_argument("--list", action="store_true", help="列出所有服务")
    parser.add_argument("--quota", action="store_true", help="查看资源配额")

    args = parser.parse_args()
    cmd_status(args)


if __name__ == "__main__":
    main()

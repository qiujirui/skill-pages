#!/usr/bin/env python3
"""
TKE 服务自动排障
自动诊断服务问题并给出修复建议（非技术人员友好）
"""

import argparse
import json
import sys
import urllib.error
import urllib.request

CONFIG_DIR = os.path.expanduser("~/.tke-deploy")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")
DEFAULT_API_BASE = "https://deploy-api.yourcompany.com"


def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    return {}


def api_request(method, path):
    config = load_config()
    api_base = config.get("api_base", DEFAULT_API_BASE)
    token = config.get("deploy_token", "")

    if not token:
        print("❌ 未配置 Token")
        sys.exit(1)

    url = f"{api_base}{path}"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    req = urllib.request.Request(url, headers=headers, method=method)

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8")
        try:
            return json.loads(body)
        except json.JSONDecodeError:
            return {"code": -1, "message": f"HTTP {e.code}"}
    except Exception as e:
        return {"code": -1, "message": str(e)}


def cmd_troubleshoot(args):
    """自动排障"""
    if not args.name:
        print("❌ 请指定服务名称：--name <service-name>")
        sys.exit(1)

    print(f"🔍 正在诊断服务 [{args.name}]...")
    print()

    # 获取完整诊断信息
    result = api_request("GET", f"/api/v1/services/diagnose/{args.name}")

    if result.get("code") != 0:
        print(f"❌ 诊断失败：{result.get('message', '未知错误')}")
        sys.exit(1)

    data = result.get("data", {})
    checks = data.get("checks", [])
    has_problem = False

    for check in checks:
        name = check.get("name", "")
        status = check.get("status", "")
        message = check.get("message", "")
        suggestion = check.get("suggestion", "")

        if status == "pass":
            print(f"   ✅ {name}")
        elif status == "warn":
            has_problem = True
            print(f"   ⚠️  {name}")
            print(f"      问题：{message}")
            if suggestion:
                print(f"      建议：{suggestion}")
        else:
            has_problem = True
            print(f"   ❌ {name}")
            print(f"      问题：{message}")
            if suggestion:
                print(f"      建议：{suggestion}")
        print()

    # 最近日志中的错误
    recent_errors = data.get("recent_errors", [])
    if recent_errors:
        print("   📋 最近日志中的错误信息：")
        for err in recent_errors[:5]:
            print(f"      ⚠️ {err}")
        print()

    if not has_problem:
        print("=" * 50)
        print("✅ 所有检查通过，服务状态正常！")
        print()
        if data.get("url"):
            print(f"🌐 访问地址：{data['url']}")
        print()
        print("💡 如果仍然无法访问，可能是以下原因：")
        print("   1. DNS 解析未生效（等待 1-2 分钟）")
        print("   2. 浏览器缓存（尝试 Ctrl+Shift+R 强制刷新）")
        print("   3. 公司网络限制（尝试使用手机流量访问）")
    else:
        print("=" * 50)
        print("❌ 发现问题，请按上述建议修复")
        print()
        print("💡 如果无法自行解决，请联系运维团队：")
        print("   1. 运行 `python3 scripts/logs.py --name {name} --tail 100` 获取日志")
        print("   2. 将日志截图发送给运维团队")
        print(f"   3. 提供服务名称：{args.name}")


def main():
    parser = argparse.ArgumentParser(description="TKE 服务自动排障")
    parser.add_argument("--name", required=True, help="服务名称")

    args = parser.parse_args()
    cmd_troubleshoot(args)


if __name__ == "__main__":
    main()

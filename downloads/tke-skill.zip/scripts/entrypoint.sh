#!/bin/bash
# ============================================================
# TKE 部署 - 自动路径重定向 Entrypoint
# 
# 核心思路：三层兜底，让员工代码里任何 SQLite 路径都自动持久化
#   Layer 1: PVC 挂载到 WORKDIR /app → 相对路径天然持久化
#   Layer 2: entrypoint 扫描源码 → 识别绝对路径 → 自动创建 symlink
#   Layer 3: 环境变量覆盖 → 兜底常见框架的默认配置
# ============================================================

set -e

DATA_DIR="/app/data"
WORK_DIR="/app"
LOG_PREFIX="[tke-entrypoint]"

# ----------------------------------------------------------
# Layer 1: PVC 已经挂载到 /app（WORKDIR）
# 所有相对路径如 ./my.db、data/my.db 自动在 PVC 上
# ----------------------------------------------------------
mkdir -p "${DATA_DIR}"

echo "$LOG_PREFIX Layer 1: PVC 已挂载到 ${WORK_DIR}，相对路径自动持久化"

# ----------------------------------------------------------
# Layer 2: 扫描源码，识别 SQLite 绝对路径，自动创建 symlink
# ----------------------------------------------------------
echo "$LOG_PREFIX Layer 2: 扫描源码中的 SQLite 路径..."

# 收集所有找到的 SQLite 数据库路径
declare -A DETECTED_PATHS

scan_python() {
    local file="$1"
    # 匹配模式：
    #   sqlite3.connect("xxx") / sqlite3.connect('xxx') / sqlite3.connect(f"xxx")
    #   sqlite3.connect(os.path.join("xxx"))
    #   create_engine("sqlite:///xxx")
    #   "sqlite:////xxx"  (SQLAlchemy 绝对路径，4个斜杠)
    grep -oP '(?:sqlite3\.connect|create_engine|connect)\s*\(\s*(?:f?["\x27])([^"\x27]+)(?:["\x27])' "$file" 2>/dev/null | \
        sed 's/.*sqlite3\.connect\s*(\s*["\x27"]*//;s/["\x27"]*\s*$//' | while read -r path; do
        # SQLAlchemy sqlite:/// 路径：sqlite:////absolute/path → /absolute/path
        path=$(echo "$path" | sed 's|^sqlite:///+|/|')
        # 去除 f-string 前缀和 Python 变量
        path=$(echo "$path" | sed 's|^{.*}||;s|}.*||')
        if [[ -n "$path" && ! "$path" =~ ^\{ ]]; then
            echo "$path"
        fi
    done
}

scan_node() {
    local file="$1"
    # 匹配：better-sqlite3('xxx'), sqlite3('xxx'), new Database('xxx')
    grep -oP '(?:sqlite3|better-sqlite3|Database|open)\s*\(\s*(?:["\x27])([^"\x27]+\.(?:db|sqlite|sqlite3))' "$file" 2>/dev/null | \
        sed 's/.*["\x27"]//;s/["\x27"]*$//' | while read -r path; do
        echo "$path"
    done
}

# 递归扫描所有源码文件
while IFS= read -r -d '' srcfile; do
    case "$srcfile" in
        *.py)
            while IFS= read -r dbpath; do
                DETECTED_PATHS["$dbpath"]=1
            done < <(scan_python "$srcfile")
            ;;
        *.js|*.ts|*.mjs)
            while IFS= read -r dbpath; do
                DETECTED_PATHS["$dbpath"]=1
            done < <(scan_node "$srcfile")
            ;;
    esac
done < <(find "${WORK_DIR}" -maxdepth 5 -type f \( -name "*.py" -o -name "*.js" -o -name "*.ts" -o -name "*.mjs" \) -print0 2>/dev/null)

# 为检测到的路径创建 symlink
created_symlinks=0
for dbpath in "${!DETECTED_PATHS[@]}"; do
    # 跳过相对路径（Layer 1 已处理）
    if [[ "$dbpath" != /* ]]; then
        echo "$LOG_PREFIX   跳过相对路径: $dbpath (Layer 1 已覆盖)"
        continue
    fi

    # 跳过已在 /app/data 下的路径
    if [[ "$dbpath" == ${DATA_DIR}/* ]]; then
        echo "$LOG_PREFIX   已在数据目录: $dbpath ✅"
        continue
    fi

    # 计算目标路径（将绝对路径映射到 DATA_DIR 下，保留目录结构）
    # /tmp/myapp.db → /app/data/_redirected/tmp/myapp.db
    # /home/user/data.db → /app/data/_redirected/home/user/data.db
    relative_to_root="${dbpath#/}"
    target_path="${DATA_DIR}/_redirected/${relative_to_root}"

    # 创建目标目录
    mkdir -p "$(dirname "$target_path")"

    # 如果原路径已有文件且不是 symlink，先迁移
    if [[ -f "$dbpath" && ! -L "$dbpath" ]]; then
        echo "$LOG_PREFIX   迁移已有文件: $dbpath → $target_path"
        cp "$dbpath" "$target_path"
    fi

    # 创建 symlink（原路径 → PVC 路径）
    if [[ ! -L "$dbpath" ]]; then
        ln -sf "$target_path" "$dbpath"
        echo "$LOG_PREFIX   重定向: $dbpath → $target_path"
        ((created_symlinks++))
    fi
done

if [[ $created_symlinks -gt 0 ]]; then
    echo "$LOG_PREFIX Layer 2: 已创建 ${created_symlinks} 个路径重定向"
else
    echo "$LOG_PREFIX Layer 2: 未检测到需要重定向的绝对路径"
fi

# ----------------------------------------------------------
# Layer 3: 环境变量覆盖，兜底常见框架默认配置
# ----------------------------------------------------------
echo "$LOG_PREFIX Layer 3: 设置标准环境变量..."

# Django: 覆盖 DATABASES 中的 SQLite 路径
export TKE_DATA_DIR="${DATA_DIR}"
# 如果员工代码使用 DATA_DIR / DATABASE_DIR / DB_PATH 环境变量，提供默认值
export DATA_DIR="${DATA_DIR}"
export DATABASE_DIR="${DATA_DIR}"
export DB_PATH="${DATA_DIR}/default.db"

# SQLAlchemy: 如果没有设置 DATABASE_URL，给一个 SQLite 默认值
if [[ -z "$DATABASE_URL" ]]; then
    export DATABASE_URL="sqlite:///${DATA_DIR}/default.db"
    echo "$LOG_PREFIX   DATABASE_URL → ${DATA_DIR}/default.db"
fi

# Node.js 常见环境变量
if [[ -z "$DB_PATH" || "$DB_PATH" == "${DATA_DIR}/default.db" ]]; then
    export DB_PATH="${DATA_DIR}/default.db"
fi

echo "$LOG_PREFIX Layer 3: 环境变量就绪"

# ----------------------------------------------------------
# 启动应用（透传原始 CMD）
# ----------------------------------------------------------
echo "$LOG_PREFIX 启动应用..."
echo ""

# 执行传入的命令（Dockerfile CMD 会被作为参数传入）
exec "$@"

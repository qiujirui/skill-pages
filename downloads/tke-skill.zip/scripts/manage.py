#!/usr/bin/env python3
"""
TKE 服务管理：停止 / 启动 / 删除
"""

import argparse
import json
import sys
import urllib.error
import urllib.request

CONFIG_DIR = os.path.expanduser("~/.tke-deploy")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")
DEFAULT_API_BASE = "https://deploy-api.yourcompany.com"


def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    return {}


def api_request(method, path, data=None):
    config = load_config()
    api_base = config.get("api_base", DEFAULT_API_BASE)
    token = config.get("deploy_token", "")

    if not token:
        print("❌ 未配置 Token")
        sys.exit(1)

    url = f"{api_base}{path}"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    if data is not None:
        body = json.dumps(data).encode("utf-8")
        req = urllib.request.Request(url, data=body, headers=headers, method=method)
    else:
        req = urllib.request.Request(url, headers=headers, method=method)

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8")
        try:
            return json.loads(body)
        except json.JSONDecodeError:
            return {"code": -1, "message": f"HTTP {e.code}"}
    except Exception as e:
        return {"code": -1, "message": str(e)}


def cmd_stop(args):
    """停止服务"""
    result = api_request("POST", f"/api/v1/services/stop", data={"service_name": args.name})

    if result.get("code") != 0:
        print(f"❌ 停止失败：{result.get('message', '未知错误')}")
        sys.exit(1)

    print(f"✅ 服务 {args.name} 已停止")
    print(f"   💡 数据已保留，随时可重新启动：")
    print(f"   python3 scripts/start.py --name {args.name}")


def cmd_start(args):
    """启动服务"""
    result = api_request("POST", f"/api/v1/services/start", data={"service_name": args.name})

    if result.get("code") != 0:
        print(f"❌ 启动失败：{result.get('message', '未知错误')}")
        sys.exit(1)

    print(f"✅ 服务 {args.name} 已启动")
    print(f"   🌐 访问地址：{result['data'].get('url', 'N/A')}")


def cmd_delete(args):
    """删除服务"""
    if not args.force:
        print(f"⚠️  警告：即将删除服务 [{args.name}] 及其所有资源！")
        print(f"   包括：Deployment、Service、Ingress、PVC（数据卷）")
        print(f"   🗑️  删除后数据不可恢复！")
        print()

        confirm = input("   确认删除？请输入服务名称以确认：")
        if confirm != args.name:
            print("   ❌ 取消删除")
            return

    result = api_request("DELETE", f"/api/v1/services/{args.name}")

    if result.get("code") != 0:
        print(f"❌ 删除失败：{result.get('message', '未知错误')}")
        sys.exit(1)

    print(f"✅ 服务 {args.name} 已删除")


def main():
    parser = argparse.ArgumentParser(description="TKE 服务管理")
    subparsers = parser.add_subparsers(dest="command")

    # stop
    p_stop = subparsers.add_parser("stop", help="停止服务")
    p_stop.add_argument("name", help="服务名称")

    # start
    p_start = subparsers.add_parser("start", help="启动服务")
    p_start.add_argument("name", help="服务名称")

    # delete
    p_delete = subparsers.add_parser("delete", help="删除服务")
    p_delete.add_argument("name", help="服务名称")
    p_delete.add_argument("--force", action="store_true", help="跳过确认")

    args = parser.parse_args()

    if args.command == "stop":
        cmd_stop(args)
    elif args.command == "start":
        cmd_start(args)
    elif args.command == "delete":
        cmd_delete(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()

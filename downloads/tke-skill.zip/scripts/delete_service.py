#!/usr/bin/env python3
"""
删除服务

用法：
    python3 delete_service.py --name=my-app --namespace=user-username
"""

import argparse
import requests
import os

# 网关地址
GATEWAY_URL = os.getenv('TKE_GATEWAY_URL', 'https://devops.dicos.com.cn/api/v1')

def delete_service(service_name, namespace):
    """删除服务"""
    url = f"{GATEWAY_URL}/services/{service_name}"
    
    params = {'namespace': namespace}
    
    print(f"🗑️  删除服务: {service_name}")
    
    response = requests.delete(url, params=params)
    
    if response.status_code == 200:
        print(f"✅ 删除成功!")
    else:
        print(f"❌ 删除失败: {response.status_code} {response.text}")

def main():
    parser = argparse.ArgumentParser(description='删除 TKE 服务')
    parser.add_argument('--name', required=True, help='服务名称')
    parser.add_argument('--namespace', required=True, help='命名空间（如 user-tangqijun）')
    
    args = parser.parse_args()
    
    delete_service(args.name, args.namespace)

if __name__ == '__main__':
    main()

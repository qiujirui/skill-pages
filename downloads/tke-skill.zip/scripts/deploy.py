#!/usr/bin/env python3
"""
TKE Web 服务部署脚本（v2.0）

功能：
1. 检查 JWT Token 是否配置
2. 分析工程类型是否支持
3. 判断是否需要打包
4. 判断工程是否符合网关要求
5. 调用网关 API 部署
6. 转换结果为用户可理解的措辞

用法：
    python3 deploy.py --path=/path/to/project [--name=service-name]
"""

import argparse
import requests
import json
import os
import sys
import zipfile
import tempfile
import shutil
from pathlib import Path

# 网关地址
GATEWAY_URL = os.getenv('TKE_GATEWAY_URL', 'https://aitools-api.dicos.com.cn/api/v1')

# 支持的工程类型
SUPPORTED_FRAMEWORKS = {
    'frontend': ['vue', 'react', 'static'],
    'backend': ['flask', 'django', 'fastapi', 'express', 'spring'],
    'fullstack': ['flask', 'django', 'fastapi', 'express', 'spring'],
    'database': ['sqlite']  # 只有 SQLite 完整支持
}

# 部分支持的数据库（无 PVC）
PARTIAL_SUPPORT_DATABASES = ['mysql', 'postgresql', 'mongodb', 'redis']


class TKEDeployer:
    def __init__(self, jwt_token=None):
        self.jwt_token = jwt_token or self._get_jwt_token()
        self.headers = {
            'Authorization': f'Bearer {self.jwt_token}',
            'Content-Type': 'application/json'
        }
    
    def _get_jwt_token(self):
        """获取 JWT Token"""
        # 优先级：环境变量 > 配置文件 > Skill 配置
        token = os.getenv('TKE_JWT_TOKEN')
        if token:
            return token
        
        # 检查 ~/.tke/config
        config_path = os.path.expanduser('~/.tke/config')
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                for line in f:
                    if line.startswith('TKE_JWT_TOKEN='):
                        return line.split('=', 1)[1].strip().strip('"')
        
        # 检查 Skill 配置文件
        skill_config_path = os.path.expanduser('~/.workbuddy/skills/tke-deploy/config.json')
        if os.path.exists(skill_config_path):
            with open(skill_config_path, 'r') as f:
                config = json.load(f)
                return config.get('jwt_token')
        
        return None
    
    def _detect_sqlite_in_source(self, project_path):
        """扫描源码文件检测 SQLite 使用
        
        Returns:
            list: 使用 SQLite 的源码文件相对路径列表
        """
        import re
        
        sqlite_patterns = [
            r'import\s+sqlite3',
            r'from\s+sqlite3\s+import',
            r'sqlite3\.connect',
            r'SQLITE',
            r'sqlite',
        ]
        
        source_files = []
        
        # 扫描 Python 文件
        for root, dirs, files in os.walk(project_path):
            # 排除虚拟环境和缓存目录
            dirs[:] = [d for d in dirs if d not in ['venv', '.venv', '__pycache__', 'node_modules', '.git']]
            
            for f in files:
                if f.endswith('.py'):
                    file_path = os.path.join(root, f)
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as fh:
                            content = fh.read()
                            for pattern in sqlite_patterns:
                                if re.search(pattern, content, re.IGNORECASE):
                                    rel_path = os.path.relpath(file_path, project_path)
                                    source_files.append(rel_path)
                                    break
                    except:
                        pass
        
        return source_files
    
    def check_jwt_token(self):
        """检查 JWT Token 是否配置"""
        if not self.jwt_token:
            print("❌ 未检测到 JWT Token，无法部署服务。")
            print()
            print("请按以下步骤获取 Token：")
            print("1. 联系管理员：qijun_tang@dicos.com.cn 或微信 13681949855")
            print("2. 提供你的姓名和工号，申请创建账号")
            print("3. 获取 JWT Token 后，配置到环境变量：")
            print("   export TKE_JWT_TOKEN=\"your-token-here\"")
            print()
            print("⚠️ 注意：Token 无法找回，请妥善保管。")
            return False
        return True
    
    def create_namespace(self):
        """创建用户命名空间"""
        print()
        print("=== 创建命名空间 ===")
        
        url = f"{GATEWAY_URL}/admin/create-namespace"
        
        try:
            response = requests.post(url, headers=self.headers)
            
            if response.status_code == 200:
                result = response.json()
                print(f"✅ 命名空间已就绪: {result.get('namespace', 'unknown')}")
                return True
            elif response.status_code == 400 and 'already exists' in response.text:
                print("✅ 命名空间已存在")
                return True
            else:
                print(f"⚠️ 创建命名空间失败: {response.status_code} {response.text}")
                print("   将继续部署，如果失败请联系管理员")
                return True  # 继续尝试部署
        except Exception as e:
            print(f"⚠️ 创建命名空间异常: {e}")
            print("   将继续部署，如果失败请联系管理员")
            return True  # 继续尝试部署
    
    def analyze_project(self, project_path):
        """分析工程类型"""
        print(f"📁 分析工程: {project_path}")
        
        result = {
            'path': project_path,
            'type': None,
            'framework': None,
            'has_frontend': False,
            'has_backend': False,
            'frontend_framework': None,
            'backend_framework': None,
            'database': None,
            'has_project_yaml': False,
            'supported': False,
            'issues': []
        }
        
        # 检查是否是 zip 文件
        if project_path.endswith('.zip'):
            print("   检测到 zip 文件，需要先解压...")
            extract_dir = tempfile.mkdtemp()
            with zipfile.ZipFile(project_path, 'r') as zip_ref:
                zip_ref.extractall(extract_dir)
            
            # 查找解压后的根目录
            items = os.listdir(extract_dir)
            if len(items) == 1 and os.path.isdir(os.path.join(extract_dir, items[0])):
                project_path = os.path.join(extract_dir, items[0])
            else:
                project_path = extract_dir
            
            result['extract_dir'] = extract_dir
            result['path'] = project_path
        
        # 检查 project.yaml
        project_yaml = os.path.join(project_path, 'project.yaml')
        if os.path.exists(project_yaml):
            print("   ✅ 检测到 project.yaml 配置文件")
            result['has_project_yaml'] = True
            # TODO: 解析 project.yaml
        
        # 检测前端框架
        package_json = os.path.join(project_path, 'frontend', 'package.json')
        if not os.path.exists(package_json):
            package_json = os.path.join(project_path, 'package.json')
        
        if os.path.exists(package_json):
            print(f"   检测到 package.json: {package_json}")
            with open(package_json, 'r') as f:
                try:
                    pkg = json.load(f)
                    dependencies = pkg.get('dependencies', {})
                    
                    if 'vue' in dependencies:
                        result['frontend_framework'] = 'vue'
                        result['has_frontend'] = True
                        print("   ✅ 检测到 Vue 框架")
                    elif 'react' in dependencies:
                        result['frontend_framework'] = 'react'
                        result['has_frontend'] = True
                        print("   ✅ 检测到 React 框架")
                except:
                    pass
        
        # 检测静态文件
        if not result['has_frontend']:
            html_files = list(Path(project_path).rglob('*.html'))
            if html_files:
                result['frontend_framework'] = 'static'
                result['has_frontend'] = True
                print(f"   ✅ 检测到静态 HTML 文件: {len(html_files)} 个")
        
        # 检测后端框架
        requirements_txt = os.path.join(project_path, 'requirements.txt')
        if os.path.exists(requirements_txt):
            print(f"   检测到 requirements.txt: {requirements_txt}")
            with open(requirements_txt, 'r') as f:
                content = f.read().lower()
                if 'flask' in content:
                    result['backend_framework'] = 'flask'
                    result['has_backend'] = True
                    print("   ✅ 检测到 Flask 框架")
                elif 'django' in content:
                    result['backend_framework'] = 'django'
                    result['has_backend'] = True
                    print("   ✅ 检测到 Django 框架")
                elif 'fastapi' in content:
                    result['backend_framework'] = 'fastapi'
                    result['has_backend'] = True
                    print("   ✅ 检测到 FastAPI 框架")
        
        # 检测数据库（文件后缀 + README.md + 源码扫描）
        db_files = list(Path(project_path).rglob('*.db')) + \
                   list(Path(project_path).rglob('*.sqlite')) + \
                   list(Path(project_path).rglob('*.sqlite3'))
        
        if db_files:
            result['database'] = 'sqlite'
            print(f"   ✅ 检测到 SQLite 数据库文件: {len(db_files)} 个")
        
        # 扫描源码检测 SQLite 使用（即使没有 .db 文件）
        if not result['database']:
            sqlite_source_files = self._detect_sqlite_in_source(project_path)
            if sqlite_source_files:
                result['database'] = 'sqlite'
                result['sqlite_source_files'] = sqlite_source_files
                print(f"   ✅ 从源码检测到 SQLite 使用: {', '.join(sqlite_source_files)}")
        
        # 检查 README.md
        readme = os.path.join(project_path, 'README.md')
        if os.path.exists(readme):
            with open(readme, 'r') as f:
                content = f.read().lower()
                if 'sqlite' in content and not result['database']:
                    result['database'] = 'sqlite'
                    print("   ✅ 从 README.md 检测到 SQLite 数据库")
                elif 'mysql' in content and not result['database']:
                    result['database'] = 'mysql'
                    print("   ⚠️ 从 README.md 检测到 MySQL 数据库（无 PVC 支持）")
                elif 'postgresql' in content and not result['database']:
                    result['database'] = 'postgresql'
                    print("   ⚠️ 从 README.md 检测到 PostgreSQL 数据库（无 PVC 支持）")
        
        # 综合判断工程类型
        if result['has_frontend'] and result['has_backend']:
            result['type'] = 'fullstack'
            result['framework'] = result['backend_framework']
            print("   ✅ 检测到全栈工程（前端 + 后端）")
        elif result['has_backend']:
            result['type'] = 'backend'
            result['framework'] = result['backend_framework']
        elif result['has_frontend']:
            result['type'] = 'frontend'
            result['framework'] = result['frontend_framework']
        
        # 判断是否支持
        if result['type'] in SUPPORTED_FRAMEWORKS:
            if result['framework'] in SUPPORTED_FRAMEWORKS[result['type']]:
                if result['database']:
                    if result['database'] == 'sqlite':
                        result['supported'] = True
                    elif result['database'] in PARTIAL_SUPPORT_DATABASES:
                        result['supported'] = True
                        result['issues'].append(f"数据库 {result['database']} 无 PVC 支持，数据会丢失")
                else:
                    result['supported'] = True
            else:
                result['issues'].append(f"框架 {result['framework']} 不支持")
        else:
            result['issues'].append(f"工程类型 {result['type']} 不支持")
        
        return result
    
    def check_support(self, analysis):
        """检查工程是否支持"""
        print()
        print("=== 工程支持性检查 ===")
        
        if analysis['supported']:
            print("✅ 该工程类型支持部署")
            
            if analysis['issues']:
                print()
                print("⚠️ 注意事项：")
                for issue in analysis['issues']:
                    print(f"   - {issue}")
            
            return True
        else:
            print("❌ 不支持该工程类型")
            print()
            print("你的工程：")
            print(f"   - 类型: {analysis['type'] or '未知'}")
            print(f"   - 框架: {analysis['framework'] or '未知'}")
            print(f"   - 数据库: {analysis['database'] or '无'}")
            print()
            print("网关支持：")
            print("   - 前端框架: Vue, React, Static")
            print("   - 后端框架: Flask, Django, FastAPI, Express, Spring")
            print("   - 数据库: SQLite（完整支持）")
            print("   - 其他数据库: MySQL/PostgreSQL/MongoDB/Redis（无 PVC，不推荐）")
            print()
            print("建议：")
            print("   - 使用 SQLite 数据库替代其他数据库")
            print("   - 或联系管理员了解如何使用外部数据库服务")
            return False
    
    def validate_project_format(self, analysis):
        """验证工程格式是否符合要求"""
        print()
        print("=== 验证工程格式 ===")
        
        project_path = analysis['path']
        issues = []
        
        # 检查是否有 project.yaml
        project_yaml = os.path.join(project_path, 'project.yaml')
        if not os.path.exists(project_yaml):
            issues.append("缺少 project.yaml 配置文件")
        
        # 检查前端目录结构
        if analysis.get('has_frontend') or analysis['type'] == 'frontend':
            frontend_dir = os.path.join(project_path, 'frontend')
            if not os.path.exists(frontend_dir):
                issues.append("缺少 frontend 目录")
            else:
                # 检查 package.json（静态页面不需要）
                if analysis.get('frontend_framework') not in ['static', None]:
                    package_json = os.path.join(frontend_dir, 'package.json')
                    if not os.path.exists(package_json):
                        issues.append("frontend 目录缺少 package.json")
        
        # 检查数据库目录结构
        if analysis['database'] == 'sqlite':
            database_dir = os.path.join(project_path, 'database')
            if not os.path.exists(database_dir):
                issues.append("缺少 database 目录")
        
        # 检查后端启动文件
        if analysis['framework'] in ['flask', 'django', 'fastapi', 'express', 'spring']:
            backend_dir = os.path.join(project_path, 'backend')
            if not os.path.exists(backend_dir):
                issues.append("缺少 backend 目录")
            else:
                # 验证启动文件
                backend_issues = self._validate_backend_entry(backend_dir, analysis['framework'])
                issues.extend(backend_issues)
        
        if issues:
            print("⚠️ 工程格式不符合要求：")
            for issue in issues:
                print(f"   - {issue}")
            return False, issues
        else:
            print("✅ 工程格式符合要求")
            return True, []
    
    def _validate_backend_entry(self, backend_dir, framework):
        """验证后端启动文件是否存在"""
        issues = []
        
        if framework == 'flask':
            # Flask 入口文件：app.py, main.py, wsgi.py
            entry_files = ['app.py', 'main.py', 'wsgi.py']
            found = [f for f in entry_files if os.path.exists(os.path.join(backend_dir, f))]
            
            if not found:
                issues.append(f"❌ Flask 后端缺少入口文件: {entry_files} 之一")
                issues.append(f"   请在 backend/ 目录下创建其中任意一个文件")
                issues.append(f"   示例：backend/app.py")
            else:
                print(f"   ✅ 检测到 Flask 入口文件: {found[0]}")
        
        elif framework == 'django':
            # Django 入口文件：manage.py
            if not os.path.exists(os.path.join(backend_dir, 'manage.py')):
                issues.append("❌ Django 后端缺少 manage.py")
            else:
                print("   ✅ 检测到 Django 入口文件: manage.py")
        
        elif framework == 'fastapi':
            # FastAPI 入口文件：main.py, app.py
            entry_files = ['main.py', 'app.py']
            found = [f for f in entry_files if os.path.exists(os.path.join(backend_dir, f))]
            
            if not found:
                issues.append(f"❌ FastAPI 后端缺少入口文件: {entry_files} 之一")
            else:
                print(f"   ✅ 检测到 FastAPI 入口文件: {found[0]}")
        
        elif framework == 'express':
            # Express 入口文件：app.js, index.js, server.js
            entry_files = ['app.js', 'index.js', 'server.js']
            found = [f for f in entry_files if os.path.exists(os.path.join(backend_dir, f))]
            
            if not found:
                issues.append(f"❌ Express 后端缺少入口文件: {entry_files} 之一")
            else:
                print(f"   ✅ 检测到 Express 入口文件: {found[0]}")
        
        elif framework == 'spring':
            # Spring Boot 入口：target/*.jar
            target_dir = os.path.join(backend_dir, 'target')
            if not os.path.exists(target_dir):
                issues.append("❌ Spring Boot 后端缺少 target 目录（请先构建项目）")
            else:
                jar_files = [f for f in os.listdir(target_dir) if f.endswith('.jar')]
                if not jar_files:
                    issues.append("❌ Spring Boot 后端缺少 .jar 文件（请先构建项目）")
                else:
                    print(f"   ✅ 检测到 Spring Boot JAR: {jar_files[0]}")
        
        return issues
    
    def _move_files_to_subdir(self, project_path, subdir, patterns, exclude=None):
        """将匹配的文件从 project_path 移动到 subdir"""
        import glob as glob_module
        if exclude is None:
            exclude = []
        
        moved_files = []
        for pattern in patterns:
            for file_path in glob_module.glob(os.path.join(project_path, pattern)):
                filename = os.path.basename(file_path)
                # 跳过排除的目录
                if any(part in file_path.split(os.sep) for part in exclude):
                    continue
                # 跳过已存在的同名文件
                target_path = os.path.join(subdir, filename)
                if os.path.exists(target_path):
                    continue
                try:
                    shutil.move(file_path, target_path)
                    moved_files.append(filename)
                except Exception as e:
                    print(f"   ⚠️ 移动文件失败 {filename}: {e}")
        
        if moved_files:
            print(f"   📦 已移动文件到 {os.path.basename(subdir)}/: {', '.join(moved_files)}")
        return moved_files
    
    def adjust_project(self, analysis, issues):
        """调整工程格式"""
        print()
        print("=== 调整工程格式 ===")
        
        project_path = analysis['path']
        
        # 创建缺失的目录并移动文件
        if "缺少 frontend 目录" in issues:
            frontend_dir = os.path.join(project_path, 'frontend')
            os.makedirs(frontend_dir, exist_ok=True)
            print(f"✅ 创建目录: {frontend_dir}")
            # 移动前端文件到 frontend/ 目录
            self._move_files_to_subdir(project_path, frontend_dir, 
                ['*.html', '*.css', '*.js', '*.vue', '*.jsx', '*.tsx'],
                exclude=['node_modules', 'backend', 'frontend', 'database'])
        
        if "缺少 backend 目录" in issues:
            backend_dir = os.path.join(project_path, 'backend')
            os.makedirs(backend_dir, exist_ok=True)
            print(f"✅ 创建目录: {backend_dir}")
            # 移动后端文件到 backend/ 目录
            self._move_files_to_subdir(project_path, backend_dir,
                ['*.py', 'requirements.txt', 'package.json'],
                exclude=['node_modules', 'backend', 'frontend', 'database', '__pycache__'])
        
        if "缺少 database 目录" in issues:
            database_dir = os.path.join(project_path, 'database')
            os.makedirs(database_dir, exist_ok=True)
            print(f"✅ 创建目录: {database_dir}")
            # 移动数据库相关文件到 database/ 目录
            self._move_files_to_subdir(project_path, database_dir,
                ['*.db', '*.sqlite', '*.sqlite3', '*.sql'],
                exclude=['node_modules', 'backend', 'frontend', 'database'])
        
        # 创建 project.yaml
        if "缺少 project.yaml 配置文件" in issues:
            project_yaml = os.path.join(project_path, 'project.yaml')
            with open(project_yaml, 'w') as f:
                f.write(self._generate_project_yaml(analysis))
            print(f"✅ 创建配置文件: {project_yaml}")
        
        # 检查并修复后端数据库路径配置
        if analysis['database'] == 'sqlite' and analysis['framework'] in ['flask', 'django', 'fastapi']:
            self._check_and_fix_database_path(analysis)
        
        print("✅ 工程格式调整完成")
    
    def _check_and_fix_database_path(self, analysis):
        """检查并修复后端数据库路径配置（自动适配 TKE 部署规范）"""
        print()
        print("=== 检查数据库路径配置 ===")
        
        project_path = analysis['path']
        
        # 确定扫描目录：优先 backend/，否则扫描整个工程
        backend_dir = os.path.join(project_path, 'backend')
        if os.path.exists(backend_dir):
            scan_dirs = [backend_dir]
        else:
            scan_dirs = [project_path]
        
        # 扫描所有 Python 文件
        fixed_files = []
        for scan_dir in scan_dirs:
            for root, dirs, files in os.walk(scan_dir):
                for file in files:
                    if file.endswith('.py'):
                        file_path = os.path.join(root, file)
                        if self._check_and_fix_database_path_in_file(file_path):
                            fixed_files.append(file_path)
        
        if fixed_files:
            print()
            print("✅ 已自动修复数据库路径配置：")
            for f in fixed_files:
                print(f"   - {os.path.relpath(f, project_path)}")
            print()
            print("💡 修复说明：")
            print("   - 硬编码路径 → 支持环境变量 DATABASE_PATH")
            print("   - 本地开发：使用默认路径（原路径）")
            print("   - 云端部署：使用 PVC 挂载路径（/var/lib/data/app.db）")
        else:
            print("✅ 数据库路径配置符合规范（或未检测到硬编码路径）")
    
    def _check_and_fix_database_path_in_file(self, file_path):
        """检查单个文件的数据库路径配置并修复"""
        import re
        
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        original_content = content
        
        # 检查是否已经使用 os.getenv 配合 DATABASE_PATH
        if 'os.getenv' in content and ('DATABASE_PATH' in content or 'DB_PATH' in content):
            return False  # 已经修复过了
        
        # 匹配各种常见的数据库路径变量名（不区分大小写）
        # DATABASE_PATH, DB_PATH, DATABASE, database_path, db_path 等
        db_var_pattern = r"((?:DATABASE|DB)(?:_PATH|PATH)?)\s*=\s*['\"]([^'\"]+)['\"]"
        
        # 但只匹配看起来像数据库文件路径的值（包含 .db, .sqlite, .sqlite3）
        matches = re.findall(db_var_pattern, content, re.IGNORECASE)
        
        # 过滤：只修复看起来像数据库路径的（含 .db/.sqlite 或路径不以 / 开头且不为空）
        db_matches = [(var, path) for var, path in matches 
                      if any(ext in path.lower() for ext in ['.db', '.sqlite', '.sqlite3']) or path.endswith('.db')]
        
        if not db_matches:
            return False  # 没有找到数据库路径配置
        
        # 检查文件开头是否已导入 os
        has_os_import = 'import os' in content
        
        # 修复每个硬编码路径：保留原变量名，只修改值
        for var_name, original_path in db_matches:
            # 使用正则精确替换这个变量的赋值
            exact_pattern = rf"{re.escape(var_name)}\s*=\s*['\"]{re.escape(original_path)}['\"]"
            replacement = f"{var_name} = os.getenv('DATABASE_PATH', '{original_path}')"
            content = re.sub(exact_pattern, replacement, content, flags=re.IGNORECASE)
            fixed_var_name = var_name
        
        if content == original_content:
            return False  # 没有实际修改
        
        # 如果没有导入 os，在文件开头添加
        if not has_os_import:
            import_pattern = r'^(import |from )'
            if re.search(import_pattern, content, re.MULTILINE):
                content = re.sub(import_pattern, r'import os\n\n\1', content, count=1)
            else:
                content = 'import os\n\n' + content
        
        # 写回文件
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        return True
        content = re.sub(pattern1, replace_path, content)
        
        # 如果没有导入 os，在文件开头添加
        if not has_os_import:
            # 查找第一个 import 语句
            import_pattern = r'^(import |from )'
            if re.search(import_pattern, content, re.MULTILINE):
                # 在第一个 import 之前添加
                content = re.sub(import_pattern, r'import os\n\n\1', content, count=1)
            else:
                # 没有找到 import，在文件开头添加
                content = 'import os\n\n' + content
        
        # 写回文件
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        return True
    
    def _generate_project_yaml(self, analysis):
        """生成 project.yaml 配置文件"""
        yaml_content = f"""name: {os.path.basename(analysis['path'])}
version: 1.0.0
description: 自动生成的配置文件

components:
"""
        
        # 判断是否有前端组件
        has_frontend = analysis.get('has_frontend', False) or analysis['type'] == 'frontend'
        # 判断是否有后端组件
        has_backend = analysis.get('has_backend', False) or analysis['type'] == 'backend'
        
        # 添加前端组件
        if has_frontend:
            yaml_content += f"""  - name: frontend
    type: frontend
    framework: {analysis.get('frontend_framework', analysis['framework'] or 'static')}
    version: 18
    port: 80
    path: ./frontend

"""
        
        # 添加后端组件
        if has_backend:
            yaml_content += f"""  - name: backend
    type: backend
    framework: {analysis.get('backend_framework', analysis['framework'])}
    port: 5000
    path: ./backend

"""
        
        # 添加数据库组件
        if analysis['database'] == 'sqlite':
            yaml_content += """  - name: database
    type: database
    framework: sqlite
    path: ./database
    storage: 1Gi
"""
        
        return yaml_content
    
    def pack_project(self, project_path):
        """打包工程"""
        print()
        print("=== 打包工程 ===")
        
        if project_path.endswith('.zip'):
            print(f"✅ 工程已打包: {project_path}")
            return project_path
        
        # 创建临时 zip 文件
        temp_zip = tempfile.NamedTemporaryFile(delete=False, suffix='.zip')
        zip_path = temp_zip.name
        temp_zip.close()
        
        print(f"📦 打包工程到: {zip_path}")
        
        # 排除的文件和目录
        exclude = ['.git', 'node_modules', '__pycache__', '.DS_Store', 'venv', '.env']
        
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(project_path):
                # 排除目录
                dirs[:] = [d for d in dirs if d not in exclude]
                
                for file in files:
                    if file not in exclude:
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, project_path)
                        zipf.write(file_path, arcname)
        
        print(f"✅ 打包完成: {zip_path}")
        return zip_path
    
    def upload_code_package(self, zip_path, service_name):
        """上传代码包"""
        print()
        print("=== 上传代码包 ===")
        print(f"📤 上传: {zip_path}")
        print(f"📋 服务名称: {service_name}")
        
        url = f"{GATEWAY_URL}/services/upload"
        
        with open(zip_path, 'rb') as f:
            files = {'file': (os.path.basename(zip_path), f, 'application/zip')}
            data = {'service_name': service_name}
            response = requests.post(url, files=files, data=data, headers={'Authorization': f'Bearer {self.jwt_token}'})
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ 上传成功: {result.get('file_path')}")
            return result.get('file_path')
        else:
            print(f"❌ 上传失败: {response.status_code} {response.text}")
            return None
    
    def deploy_service(self, file_path, service_name):
        """部署服务"""
        print()
        print("=== 部署服务 ===")
        print(f"🚀 服务名称: {service_name}")
        
        url = f"{GATEWAY_URL}/services/deploy"
        
        payload = {
            'file_path': file_path,
            'service_name': service_name
        }
        
        response = requests.post(url, json=payload, headers=self.headers)
        
        if response.status_code in [200, 201]:
            result = response.json()
            print(f"✅ 部署成功!")
            return result
        else:
            print(f"❌ 部署失败: {response.status_code} {response.text}")
            return None
    
    def convert_result(self, result):
        """转换结果为用户可理解的措辞"""
        print()
        print("=== 部署结果 ===")
        
        # 检查是否有 access_urls
        access_urls = result.get('access_urls', [])
        service_name = result.get('service_name')
        
        if access_urls:
            print(f"✅ 部署成功！你的应用已经上线。")
            print()
            print(f"📋 服务信息：")
            print(f"   - 服务名称: {service_name}")
            print(f"   - 命名空间: {result.get('namespace')}")
            print()
            print(f"🌐 访问地址：")
            for url_info in access_urls:
                print(f"   - {url_info['component']}: {url_info['url']}")
            print()
            print(f"💡 提示：")
            print(f"   - 在浏览器中打开上述地址即可访问你的应用")
            print(f"   - 数据库文件已持久化存储，重启不会丢失")
            print(f"   - 如需更新，重新部署即可（服务名称相同会自动覆盖）")
            
            return True
        else:
            error = result.get('error', result.get('message', '未知错误'))
            print(f"❌ 部署失败: {error}")
            print()
            print(f"💡 建议：")
            print(f"   - 检查工程目录结构是否符合要求")
            print(f"   - 检查 JWT Token 是否有效")
            print(f"   - 联系管理员获取帮助")
            
            return False
    
    def deploy(self, project_path, service_name=None):
        """完整部署流程"""
        print("=== TKE Web 服务部署 ===")
        print()
        
        # 1. 检查 JWT Token
        if not self.check_jwt_token():
            return False
        
        # 2. 创建命名空间
        if not self.create_namespace():
            return False
        
        # 3. 分析工程
        analysis = self.analyze_project(project_path)
        
        # 3. 检查是否支持
        if not self.check_support(analysis):
            return False
        
        # 4. 验证工程格式
        is_valid, issues = self.validate_project_format(analysis)
        
        # 5. 调整工程格式（如需要）
        if not is_valid:
            self.adjust_project(analysis, issues)
        
        # 6. 确定服务名称
        if not service_name:
            service_name = os.path.basename(analysis['path']).replace('.zip', '')
        
        # 7. 打包工程
        zip_path = self.pack_project(analysis['path'])
        
        # 8. 上传代码包
        file_path = self.upload_code_package(zip_path, service_name)
        if not file_path:
            return False
        
        # 9. 部署服务
        result = self.deploy_service(file_path, service_name)
        if not result:
            return False
        
        # 9. 转换结果
        success = self.convert_result(result)
        
        # 清理临时文件
        if 'extract_dir' in analysis:
            shutil.rmtree(analysis['extract_dir'])
        
        return success


def main():
    parser = argparse.ArgumentParser(description='部署 Web 服务到 TKE')
    parser.add_argument('--path', required=True, help='工程路径（目录或 zip 文件）')
    parser.add_argument('--name', help='服务名称（可选）')
    parser.add_argument('--token', help='JWT Token（可选，优先使用环境变量）')
    
    args = parser.parse_args()
    
    deployer = TKEDeployer(jwt_token=args.token)
    success = deployer.deploy(args.path, args.name)
    
    sys.exit(0 if success else 1)


if __name__ == '__main__':
    main()

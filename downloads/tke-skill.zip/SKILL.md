# TKE Web 服务部署平台 - 用户端 Skill

> 版本：v3.1
> 最后更新：2026-05-10

## 概述

本 Skill 用于一键部署 Web 服务到腾讯云 TKE 集群。用户只需对小龙虾说"帮我部署 xxx"，即可自动分析工程、打包、部署并返回访问地址。

## 使用方法

### 方法 1：对小龙虾说（推荐）

```
帮我部署 my-project
```

或指定 zip 文件：

```
帮我部署 my-project.zip
```

### 方法 2：使用脚本

```bash
python3 scripts/deploy.py --path=/path/to/project
```

## 架构链路

### 本地端到云端全链路

```
┌─────────────────────────────────────────────────────────────────────┐
│                        用户本地端（小龙虾）                           │
│                                                                     │
│  1. 检查 JWT Token → 未找到则停止，提示联系管理员                     │
│  2. 调用 /admin/create-namespace → 确保 K8s 命名空间就绪             │
│  3. 分析工程类型（前端/后端/数据库）                                  │
│  4. 验证 & 调整工程格式                                              │
│  5. 打包工程为 zip                                                   │
│  6. 调用 /services/upload 上传代码包                                 │
│  7. 调用 /services/deploy 触发云端构建                               │
│  8. 等待部署完成，返回访问地址                                       │
└──────────────────────────┬──────────────────────────────────────────┘
                           │ HTTPS (JWT Token)
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│                   云端 API 网关（Flask）                              │
│                  aitools-api.dicos.com.cn                            │
│                                                                     │
│  /api/v1/services/upload   → 接收代码包，保存到 uploads/            │
│  /api/v1/services/deploy   → 触发构建和部署                         │
│  /api/v1/admin/create-namespace → 创建用户命名空间                  │
│                                                                     │
│  部署流程：                                                          │
│  ┌─────────────────────────────────────────────────────────┐       │
│  │ 1. 解压代码包                                            │       │
│  │ 2. 解析 project.yaml → 识别组件（前端/后端/数据库）      │       │
│  │ 3. 合并 SQLite 到后端组件（前端+后端模式）               │       │
│  │ 4. 为每个组件生成 Dockerfile                             │       │
│  │    - 前端：nginx:alpine + 反向代理到后端                  │       │
│  │    - 后端：python/node/java + SQLite + PVC 挂载          │       │
│  │ 5. Docker build → 构建镜像                               │       │
│  │ 6. Docker push → 推送到腾讯云 TCR                        │       │
│  │ 7. 创建 CFS PV + PVC（SQLite 持久化）                    │       │
│  │ 8. 创建 K8s Deployment（多容器 Pod）                     │       │
│  │ 9. 创建 K8s Service（NodePort 暴露服务）                 │       │
│  └─────────────────────────────────────────────────────────┘       │
└──────────────────────────┬──────────────────────────────────────────┘
                           │
              ┌────────────┼────────────┐
              ▼            ▼            ▼
┌──────────────────┐ ┌──────────────┐ ┌────────────────┐
│  腾讯云 TCR       │ │  TKE 集群    │ │  腾讯云 CFS     │
│  容器镜像仓库     │ │  K8s Pods   │ │  文件存储       │
│                  │ │             │ │                │
│  存储构建好的    │ │ 前端容器     │ │ PVC 挂载       │
│  Docker 镜像     │ │ 后端容器     │ │ /var/lib/data  │
│                  │ │             │ │ SQLite 数据库  │
└──────────────────┘ └──────────────┘ └────────────────┘
```

### Pod 内部架构（前端 + 后端 + SQLite）

```
┌─────────────────────────────────────────────────────┐
│                    K8s Pod                           │
│                                                     │
│  ┌─────────────────────────────────────────────┐   │
│  │          前端容器 (nginx:alpine)              │   │
│  │                                              │   │
│  │  /usr/share/nginx/html  → 前端静态文件        │   │
│  │  nginx 反向代理：                              │   │
│  │    /api/*  → http://localhost:5000 (后端)     │   │
│  │    /health → http://localhost:5000 (后端)     │   │
│  │                                              │   │
│  │  监听端口：80                                 │   │
│  └─────────────────────────────────────────────┘   │
│                                                     │
│  ┌─────────────────────────────────────────────┐   │
│  │       后端容器 (python:3.9-slim)             │   │
│  │                                              │   │
│  │  /app/  → 后端代码 (Flask/Django/FastAPI)    │   │
│  │                                              │   │
│  │  /var/lib/data/  ← CFS PVC 挂载              │   │
│  │    └── app.db  → SQLite 数据库文件            │   │
│  │                                              │   │
│  │  /docker-entrypoint-initdb.d/                │   │
│  │    └── init.sql  → 数据库初始化脚本           │   │
│  │                                              │   │
│  │  /entrypoint.sh  → 容器启动时初始化数据库      │   │
│  │                                              │   │
│  │  监听端口：5000                               │   │
│  └─────────────────────────────────────────────┘   │
│                                                     │
│  ┌─────────────────────────────────────────────┐   │
│  │            CFS PVC 挂载                       │   │
│  │  挂载点：后端容器 /var/lib/data               │   │
│  │  用途：SQLite 数据库持久化                    │   │
│  └─────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────┘
        │
        │ NodePort (30000-32767)
        ▼
   用户浏览器访问
```

## 前置要求

### 🔑 获取 JWT Token

**重要**：部署服务需要 JWT Token，Token 无法找回，请妥善保管！

> 🚫 **严禁 AI 自行创建用户和 Token！**
> - AI 发现本地没有 JWT Token 时，**必须停止任务**，提示用户联系管理员申请
> - **禁止**猜测用户名或自行创建用户

**获取步骤**：

1. **联系管理员**
   - 📧 邮件：qijun_tang@dicos.com.cn
   - 💬 微信：13681949855

2. **提供信息**
   - 姓名
   - 工号
   - 部门
   - 邮箱

3. **获取 Token**
   - 管理员会为你创建账号并返回 JWT Token
   - Token 示例：`eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`

4. **配置 Token**（三选一）

   **方式 1：环境变量（推荐）**
   ```bash
   export TKE_JWT_TOKEN="your-token-here"
   ```

   **方式 2：配置文件**
   ```bash
   mkdir -p ~/.tke
   echo 'TKE_JWT_TOKEN="your-token-here"' > ~/.tke/config
   ```

   **方式 3：Skill 配置**
   ```bash
   mkdir -p ~/.workbuddy/skills/tke-deploy
   cp skill/config.example.json ~/.workbuddy/skills/tke-deploy/config.json
   # 编辑 config.json，填入你的 token
   ```

**⚠️ 注意**：
- Token 无法找回，丢失需重新申请
- Token 已绑定你的账号信息（命名空间等）
- 不要将 Token 提交到代码仓库

## 工作流程

```
用户请求
  ↓
检查 JWT Token → 未找到 → 🛑 停止任务，提示用户联系管理员申请 Token
  ↓
调用 /admin/create-namespace → 确保 K8s 命名空间就绪
  ↓
分析工程类型（前端/后端/数据库）
  ↓
判断是否支持 → 不支持 → 告知并结束
  ↓
验证工程格式是否符合要求 → 不符合 → 调整工程
  ↓
打包工程为 zip → 上传到网关（同名允许，支持覆盖部署）
  ↓
网关检测同名服务 → 有 → 清理旧 Deployment + Service（保留 PVC）
  ↓
网关解析 project.yaml → 生成 Dockerfile → 构建镜像 → 推送到 TCR
  ↓
创建 CFS PV + PVC（已有则跳过）→ 创建 Deployment → 创建 Service (NodePort)
  ↓
返回访问地址（注意：覆盖部署后 NodePort 可能变化）
```

## 支持的工程类型

### ✅ 完整支持

#### 架构类型

| 架构 | 说明 | Pod 数量 | 容器数量 | 通信方式 |
|:---|:---|:---|:---|:---|
| **前端 + SQLite** | 前端和数据库合并到同一容器 | 1 | 1 | 文件读写（无需网络） |
| **后端 + SQLite** | 后端和数据库合并到同一容器 | 1 | 1 | 文件读写（无需网络） |
| **前端 + 后端 + SQLite** | 前端、后端在同一 Pod，数据库合并到后端容器 | 1 | 2 | nginx 反向代理 |
| **纯前端** | 仅前端静态页面 | 1 | 1 | 无 |
| **纯后端** | 仅后端 API 服务 | 1 | 1 | 无 |

**架构说明**：
- **前端 + SQLite**：前端容器包含 nginx + SQLite，数据库文件通过 PVC 持久化
- **后端 + SQLite**：后端容器包含 Flask/Django/FastAPI + SQLite，数据库文件通过 PVC 持久化
- **前端 + 后端 + SQLite**：前端 nginx 反向代理 `/api/*` 到后端容器，SQLite 合并到后端容器，PVC 挂载到后端

#### 前端框架
| 框架 | 版本 | 基础镜像 | 反向代理 | SQLite 支持 | PVC 支持 |
|:---|:---|:---|:---|:---|:---|
| Vue | 18 | node:18-alpine → nginx:alpine | ✅ /api/ → 后端 | ✅ 合并到后端容器 | ✅ |
| React | 18 | node:18-alpine → nginx:alpine | ✅ /api/ → 后端 | ✅ 合并到后端容器 | ✅ |
| Static | latest | nginx:alpine | ✅ /api/ → 后端 | ✅ 合并到后端容器 | ✅ |

#### 后端框架
| 框架 | 版本 | 基础镜像 | PyPI 镜像 | SQLite 支持 | PVC 支持 |
|:---|:---|:---|:---|:---|:---|
| Flask | 3.9 | python:3.9-slim | 阿里云 | ✅ entrypoint.sh 初始化 | ✅ |
| Django | 3.9 | python:3.9-slim | 阿里云 | ✅ entrypoint.sh 初始化 | ✅ |
| FastAPI | 3.9 | python:3.9-slim | 阿里云 | ✅ entrypoint.sh 初始化 | ✅ |
| Express | 18 | node:18-alpine | npm 淘宝 | ✅ entrypoint.sh 初始化 | ✅ |
| Spring | 11/17/21 | openjdk:xx-jdk-alpine | Maven 阿里云 | ✅ entrypoint.sh 初始化 | ✅ |

#### 数据库
| 数据库 | 版本 | 基础镜像 | PVC 支持 | 初始化脚本 | 说明 |
|:---|:---|:---|:---|:---|:---|
| **SQLite** | latest | 合并到后端/前端容器 | ✅ CFS | ✅ .sql 文件 | **唯一完整支持的数据库** |

### ⚠️ 部分支持（有 Dockerfile，但无 PVC）

以下数据库有 Dockerfile 生成逻辑，但**没有 PVC 持久化支持**，数据会随容器删除而丢失：

| 数据库 | 版本 | 基础镜像 | PVC 支持 | 初始化脚本 | 限制 |
|:---|:---|:---|:---|:---|:---|
| MySQL | 5.7/8.0 | mysql:5.7/8.0 | ❌ | ✅ .sql 文件 | 无持久化，不推荐生产使用 |
| PostgreSQL | 12-15 | postgres:12-15 | ❌ | ✅ .sql 文件 | 无持久化，不推荐生产使用 |
| MongoDB | 4-6 | mongo:4-6 | ❌ | ✅ .js 文件 | 无持久化，不推荐生产使用 |
| Redis | 6-7 | redis:6-7-alpine | ❌ | ❌ | 无持久化，不推荐生产使用 |

## 核心特性

### 1. 一键部署

用户无需指定：
- ❌ 规格配置（CPU、内存自动分配）
- ❌ 副本数量（默认 1 个副本）
- ❌ 命名空间（已绑定到账号，自动创建）

只需提供工程路径或 zip 文件即可。

### 2. 自动分析工程

Skill 会自动分析：
- ✅ 前端框架（Vue/React/Static）
- ✅ 后端框架（Flask/Django/FastAPI/Express/Spring）
- ✅ 数据库类型（SQLite/MySQL/PostgreSQL/MongoDB/Redis）
- ✅ 工程结构（project.yaml/package.json/requirements.txt）

### 3. 自动打包

如果工程未打包，Skill 会自动：
- ✅ 创建 zip 文件
- ✅ 排除不必要的文件（.git, node_modules, __pycache__）
- ✅ 保持正确的目录结构

### 4. 智能调整

如果工程格式不符合要求，Skill 会：
- ✅ 创建缺失的目录（frontend/、database/）
- ✅ 生成 project.yaml 配置文件
- ✅ 调整目录结构

### 5. nginx 反向代理

前端+后端架构自动配置 nginx 反向代理：
- ✅ `/api/*` → 转发到后端容器 `http://localhost:{后端端口}`
- ✅ `/health` → 转发到后端健康检查
- ✅ 前端代码使用**相对路径**调用 API（如 `/api/hello`）

### 6. SQLite 完整支持

**唯一完整支持的数据库**，特性包括：
- ✅ 自动检测 SQLite 文件（.db/.sqlite/.sqlite3）和 README.md 关键词
- ✅ 自动创建 CFS PV + PVC 持久化存储
- ✅ 支持初始化脚本（.sql 文件）
- ✅ entrypoint.sh 自动初始化数据库（首次启动时执行 .sql 文件）
- ✅ PVC 挂载到后端容器 `/var/lib/data`
- ✅ 数据库文件存储在 `/var/lib/data/app.db`

**SQLite 合并规则**：
| 架构 | SQLite 合并到 | PVC 挂载到 |
|:---|:---|:---|
| 前端+后端+SQLite | 后端容器 | 后端容器 `/var/lib/data` |
| 前端+SQLite（无后端） | 前端容器 | 前端容器 `/var/lib/data` |
| 后端+SQLite（无前端） | 后端容器 | 后端容器 `/var/lib/data` |

### 7. 命名空间自动创建

首次部署时自动创建用户命名空间，包含：
- ✅ K8s Namespace
- ✅ NetworkPolicy（跨命名空间隔离）
- ✅ TCR Secret（镜像拉取凭证）
- ⚠️ ResourceQuota 和 LimitRange 已暂时禁用

### 8. 覆盖部署

使用相同 `service_name` 重新部署时，自动覆盖旧版本：

- ✅ 清理旧 Deployment + Service（等待旧 Pod 终止）
- ✅ **保留 PVC/PV**，SQLite 数据库数据不丢失
- ✅ DB 服务记录自动重置为 pending
- ⚠️ NodePort 可能会变化，请使用返回的新访问地址
- ✅ 支持任意次数的覆盖部署

## 用户工程标准要求

### 目录结构

#### 前端 + 后端 + SQLite（推荐）

```
my-project/
├── project.yaml          # 工程配置文件（必需）
├── README.md             # 工程说明文档（可选）
├── frontend/             # 前端代码目录
│   ├── index.html        # 静态页面
│   └── ...
├── backend/              # 后端代码目录
│   ├── app.py            # Flask 入口
│   ├── requirements.txt  # Python 依赖
│   └── ...
└── database/             # 数据库目录
    ├── init.sql          # 初始化脚本
    └── ...
```

#### 前端 + SQLite（无后端）

```
my-project/
├── project.yaml
├── frontend/
│   ├── index.html
│   └── ...
└── database/
    ├── init.sql
    └── ...
```

#### 纯后端 + SQLite

```
my-project/
├── project.yaml
├── backend/
│   ├── app.py
│   ├── requirements.txt
│   └── ...
└── database/
    ├── init.sql
    └── ...
```

### project.yaml 配置文件

**完整示例（前端 + 后端 + SQLite）**：
```yaml
name: demo-app
version: 1.0.0
description: 前端 + 后端 + SQLite 测试工程

components:
  - name: frontend
    type: frontend
    framework: static
    port: 80
    path: ./frontend

  - name: backend
    type: backend
    framework: flask
    version: 3.9
    port: 5000
    path: ./backend

  - name: database
    type: database
    framework: sqlite
    path: ./database
    storage: 1Gi
```

**纯前端 + SQLite 示例**：
```yaml
name: demo-frontend
version: 1.0.0

components:
  - name: frontend
    type: frontend
    framework: vue
    version: 18
    port: 80
    path: ./frontend

  - name: database
    type: database
    framework: sqlite
    path: ./database
    storage: 1Gi
```

**字段说明**：
- `type`: 组件类型（frontend/backend/database）
- `framework`: 框架类型（vue/react/static/flask/django/fastapi/express/spring/sqlite）
- `version`: 版本号（可选，默认使用推荐版本）
- `port`: 端口号（前端默认 80，后端默认 5000）
- `path`: 代码路径（相对项目根目录）
- `storage`: 存储大小（仅数据库组件，默认 1Gi）

### 前端 API 调用规范

**重要**：前端 + 后端架构中，前端必须使用**相对路径**调用后端 API：

```javascript
// ✅ 正确：使用相对路径（nginx 会反向代理到后端）
const API_BASE = '';

fetch('/api/hello')
fetch('/health')

// ❌ 错误：使用 localhost（浏览器端 localhost 是用户电脑，不是 Pod）
const API_BASE = 'http://localhost:5000';
```

### 数据库初始化脚本

SQLite 初始化脚本放在 `database/` 目录下：

```sql
-- database/init.sql
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL
);

INSERT INTO users (name, email) VALUES ('admin', 'admin@example.com');
```

**初始化逻辑**：
1. 容器首次启动时，entrypoint.sh 检查 `/var/lib/data/app.db` 是否存在
2. 如果不存在，执行 `/docker-entrypoint-initdb.d/*.sql` 中的所有 SQL 文件
3. 如果已存在，跳过初始化，直接启动应用
4. 数据库文件持久化在 CFS 上，容器重启不会丢失

## 实战经验与踩坑记录

### 1. 打包方式决定成败（Windows 用户必看）

**问题**：使用 PowerShell `Compress-Archive` 打包的 zip 文件上传后，服务端报 `Docker build failed for frontend`（500错误）。

**原因**：`Compress-Archive` 生成的 zip 格式与 Python `zipfile` 存在差异，服务端解压后路径解析异常。

**解决**：必须使用 Python `zipfile` 模块打包：

```python
import zipfile
with zipfile.ZipFile('project.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk(project_path):
        for file in files:
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, project_path)
            z.write(file_path, arcname)
```

### 2. 工程目录结构必须严格标准化

**问题**：工程放在临时目录，目录结构不符合规范，即使打包成功也会导致构建失败。

**解决**：按照 Skill 支持的目录结构整理工程：

```
my-project/
├── project.yaml          # 必须在根目录
├── README.md             # 可选
├── frontend/             # 前端代码（必须有这个目录名）
│   ├── index.html
│   └── ...
├── backend/              # 后端代码（如有）
│   ├── app.py
│   └── requirements.txt
└── database/             # 数据库（如有）
    └── init.sql
```

**关键点**：
- `project.yaml` 必须在 zip 包的根目录
- `frontend/` 目录名不能改（即使是纯前端工程也必须叫 frontend）
- `backend/` 和 `database/` 目录名同样固定

### 3. API 调用字段名对照表

| 接口 | 字段 | 说明 |
|:---|:---|:---|
| `/services/upload` | `file` | 代码包字段名（不是 `code_package`） |
| `/services/upload` | `service_name` | 服务名称 |
| `/services/deploy` | `file_path` | 上传接口返回的路径 |
| `/services/deploy` | `service_name` | 服务名称（与上传时一致） |

### 4. Windows ACP 模式实际无限制

**误区**：之前以为 Windows ACP（Application Control Policy）模式会阻止 Python 脚本执行 multipart 上传。

**事实**：Python `urllib.request` 在 ACP 模式下可以正常执行，没有任何限制。问题出在打包方式（见第1条）。

### 5. 服务端 Docker 构建失败排查

如果持续报 `Docker build failed for frontend`：

1. 先用**最小化测试工程**验证（仅一个 `index.html` + `project.yaml`）
2. 如果最小工程也失败 → **服务端环境问题**，联系管理员
3. 如果最小工程成功 → 检查自己的工程目录结构

**最小化测试工程**：
```yaml
# project.yaml
name: test
version: 1.0.0
components:
  - name: frontend
    type: frontend
    framework: static
    port: 80
    path: ./frontend
```

```html
<!-- frontend/index.html -->
<!DOCTYPE html><html><body><h1>Test</h1></body></html>
```

### 6. 覆盖部署流程

无需先删除旧服务，直接重新上传 + 部署即可：
1. 重新打包工程
2. 调用 `/services/upload`（同名服务自动覆盖）
3. 调用 `/services/deploy`
4. 服务端自动清理旧 Deployment + Service，保留 PVC 数据

---

## 限制与注意事项

### 重要限制

1. **数据库持久化**：
   - ✅ **SQLite**: 完整支持 CFS PVC 持久化
   - ❌ **MySQL/PostgreSQL/MongoDB/Redis**: 无 PVC 支持，数据会丢失

2. **SQLite 合并策略**：
   - 前端+后端同时存在时，SQLite 合并到**后端容器**（PVC 挂载到后端）
   - 只有前端（无后端）时，SQLite 合并到前端容器
   - 前端通过 nginx 反向代理访问后端 API，后端直接读写数据库

3. **服务名称唯一性**：
   - 同一命名空间内同名服务支持**覆盖部署**
   - 覆盖部署自动清理旧 Deployment + Service，**保留 PVC 数据**
   - DB 服务记录重置为 pending 状态
   - NodePort 可能会变化，请关注返回的新访问地址

4. **资源配额**：
   - ResourceQuota 和 LimitRange 已暂时禁用
   - 后续可能重新启用

### 推荐使用场景

**推荐**：
- ✅ 前端 + 后端 + SQLite（nginx 反向代理 + PVC 持久化）
- ✅ 纯前端 + SQLite（轻量级应用）
- ✅ 纯后端 + SQLite（API 服务）
- ✅ 纯前端静态页面（无数据库）

**不推荐**：
- ❌ MySQL/PostgreSQL/MongoDB/Redis（无 PVC 支持，数据会丢失）
- ❌ 需要独立数据库服务器的应用

## 网关 API 端点

**网关地址**：`https://aitools-api.dicos.com.cn/api/v1`

| 端点 | 方法 | 说明 | 认证 |
|:---|:---|:---|:---|
| `/api/v1/auth/verify` | GET | 验证当前 Token 有效性 | JWT |
| `/api/v1/auth/refresh-token` | POST | 刷新 Token（旧 Token 立即失效） | JWT |
| `/api/v1/admin/create-namespace` | POST | 创建用户命名空间 | JWT |
| `/api/v1/services/upload` | POST | 上传代码包 | JWT |
| `/api/v1/services/deploy` | POST | 触发构建和部署 | JWT |
| `/api/v1/services` | GET | 列出用户所有服务 | JWT |
| `/api/v1/services/<name>` | GET | 获取服务详情 | JWT |
| `/api/v1/services/<name>/logs` | GET | 获取服务日志（`?container=` 指定容器） | JWT |
| `/api/v1/services/<name>` | DELETE | 删除服务及 K8s 资源 | JWT |
| `/health` | GET | 网关健康检查 | 无 |

> **Token 注意事项**：`refresh-token` 会重新生成 Token，旧 Token 立即失效，请务必保存最后一次返回的 Token。

## 获取帮助

- 📧 邮件：qijun_tang@dicos.com.cn
- 💬 微信：13681949855

---

**免责声明**：本平台仅供内部测试和学习使用，不保证生产环境稳定性。

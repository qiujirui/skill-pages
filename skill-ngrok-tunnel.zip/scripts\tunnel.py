#!/usr/bin/env python3
"""
ngrok-tunnel Skill 核心脚本（安全版本）
功能：启动安全 HTTP 服务器 + ngrok 内网穿透隧道，实现公网访问本地页面

安全特性：
- 禁止目录列表（Directory Listing Disabled）
- 白名单限制可访问文件类型
- 禁止访问敏感文件（.env, config, 密码文件等）
- 防止路径遍历攻击

用法：
  python tunnel.py start          # 启动服务器+隧道（一键启动）
  python tunnel.py start-server   # 仅启动 HTTP 服务器（安全版本）
  python tunnel.py start-tunnel   # 仅启动 ngrok 隧道
  python tunnel.py stop           # 停止所有服务
  python tunnel.py status         # 查看当前状态和公网地址
  python tunnel.py restart        # 重启所有服务
"""

import os
import sys
import time
import json
import signal
import socket
import subprocess
import threading
import requests
from pathlib import Path

# ============ 配置 ============
DEFAULT_PORT = 8099
DEFAULT_ROOT = r"D:\WorkBuddyOutput"
AUTHTOKEN_FILE = os.path.join(os.path.dirname(__file__), "config.env")
PID_FILE = os.path.join(os.path.dirname(__file__), ".tunnel_pids.json")
URL_FILE = os.path.join(DEFAULT_ROOT, "ngrok_url.txt")
PYTHON = sys.executable

def load_authtoken():
    """从 config.env 读取 authtoken"""
    if not os.path.exists(AUTHTOKEN_FILE):
        print("❌ 未找到 config.env，请在 Skill 目录下创建并写入 AUTHTOKEN=xxx")
        sys.exit(1)
    with open(AUTHTOKEN_FILE, 'r') as f:
        for line in f:
            line = line.strip()
            if line.startswith('AUTHTOKEN='):
                return line.split('=', 1)[1].strip()
    print("❌ config.env 中未找到 AUTHTOKEN=xxx")
    sys.exit(1)

def is_port_open(port, host='127.0.0.1'):
    """检查端口是否在监听"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        result = s.connect_ex((host, port))
        s.close()
        return result == 0
    except:
        return False

def save_pids(server_pid=None, tunnel_pid=None):
    """保存进程 PID"""
    data = {}
    if os.path.exists(PID_FILE):
        try:
            with open(PID_FILE, 'r') as f:
                data = json.load(f)
        except:
            pass
    if server_pid is not None:
        data['server_pid'] = server_pid
    if tunnel_pid is not None:
        data['tunnel_pid'] = tunnel_pid
    with open(PID_FILE, 'w') as f:
        json.dump(data, f)

def load_pids():
    """读取保存的 PID"""
    if not os.path.exists(PID_FILE):
        return {}
    try:
        with open(PID_FILE, 'r') as f:
            return json.load(f)
    except:
        return {}

def kill_process(pid):
    """安全终止进程"""
    try:
        os.kill(pid, signal.SIGTERM)
        time.sleep(0.5)
        return True
    except ProcessLookupError:
        return True
    except:
        try:
            os.kill(pid, signal.SIGKILL)
            return True
        except:
            return False

def start_server(port=DEFAULT_PORT, root=DEFAULT_ROOT):
    """启动安全 HTTP 服务器（禁止目录列表）"""
    if is_port_open(port):
        print(f"[OK] HTTP server already running on port {port}")
        return True

    # 使用安全服务器脚本
    secure_server_script = r"D:\WorkBuddyOutput\start_server_secure.py"
    if not os.path.exists(secure_server_script):
        print(f"[ERROR] Secure server script not found: {secure_server_script}")
        return False
    
    # 用 pythonw 静默启动
    pythonw = PYTHON.replace('python.exe', 'pythonw.exe')
    if not os.path.exists(pythonw):
        pythonw = PYTHON

    proc = subprocess.Popen(
        [pythonw, secure_server_script],
        creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE
    )
    
    # 等待服务器启动
    for i in range(15):
        time.sleep(0.5)
        if is_port_open(port):
            print(f"[OK] Secure HTTP server started (port {port}, PID {proc.pid})")
            print(f"     Security: Directory listing disabled, file type whitelist enabled")
            save_pids(server_pid=proc.pid)
            return True
    
    print(f"[ERROR] HTTP server failed to start")
    return False

def start_tunnel(port=DEFAULT_PORT):
    """启动 ngrok 隧道"""
    authtoken = load_authtoken()
    
    # 检查隧道是否已存在
    if os.path.exists(URL_FILE):
        try:
            with open(URL_FILE, 'r') as f:
                old_url = f.read().strip()
            if old_url:
                r = requests.get(old_url, headers={'ngrok-skip-browser-warning': 'true'}, timeout=5)
                if r.status_code == 200:
                    print(f"✅ ngrok 隧道已运行: {old_url}")
                    return old_url
        except:
            pass

    script = f'''
import time, sys
from pyngrok import ngrok, conf
conf.get_default().auth_token = '{authtoken}'
try:
    ngrok.kill()
except:
    pass
time.sleep(1)
tunnel = ngrok.connect({port}, 'http')
url = tunnel.public_url
with open(r'{URL_FILE}', 'w') as f:
    f.write(url)
print(f"TUNNEL_READY:{{url}}", flush=True)
# keep alive
while True:
    time.sleep(60)
'''
    
    proc = subprocess.Popen(
        [PYTHON, '-c', script],
        creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )
    
    # 等待隧道启动
    for i in range(30):
        time.sleep(1)
        if os.path.exists(URL_FILE):
            try:
                with open(URL_FILE, 'r') as f:
                    url = f.read().strip()
                if url and 'ngrok' in url:
                    # 验证
                    time.sleep(2)
                    try:
                        r = requests.get(url, headers={'ngrok-skip-browser-warning': 'true'}, timeout=10)
                        print(f"✅ ngrok 隧道启动成功: {url}")
                        print(f"   验证: {r.status_code} / {len(r.text)} bytes")
                    except Exception as e:
                        print(f"⚠️ 隧道已建立但验证失败: {e}")
                        print(f"   公网地址: {url}")
                    
                    pids = load_pids()
                    save_pids(tunnel_pid=proc.pid)
                    return url
            except:
                pass
    
    print("❌ ngrok 隧道启动超时")
    return None

def stop_all():
    """停止所有服务"""
    pids = load_pids()
    
    # 先杀隧道
    if 'tunnel_pid' in pids:
        kill_process(pids['tunnel_pid'])
        print(f"✅ 已停止隧道进程 (PID {pids['tunnel_pid']})")
    
    # 再杀服务器
    if 'server_pid' in pids:
        kill_process(pids['server_pid'])
        print(f"✅ 已停止服务器进程 (PID {pids['server_pid']})")
    
    # 也用 pyngrok 杀
    try:
        from pyngrok import ngrok
        ngrok.kill()
        print("✅ 已清理 ngrok 进程")
    except:
        pass
    
    # 清理 PID 文件
    if os.path.exists(PID_FILE):
        os.remove(PID_FILE)
    if os.path.exists(URL_FILE):
        os.remove(URL_FILE)
    
    print("✅ 所有服务已停止")

def show_status():
    """显示当前状态"""
    print("=" * 50)
    print("  ngrok-tunnel 状态")
    print("=" * 50)
    
    # HTTP 服务器
    if is_port_open(DEFAULT_PORT):
        print(f"  HTTP 服务器: ✅ 运行中 (端口 {DEFAULT_PORT})")
    else:
        print(f"  HTTP 服务器: ❌ 未运行")
    
    # 隧道
    if os.path.exists(URL_FILE):
        with open(URL_FILE, 'r') as f:
            url = f.read().strip()
        if url:
            try:
                r = requests.get(url, headers={'ngrok-skip-browser-warning': 'true'}, timeout=5)
                print(f"  ngrok 隧道: ✅ 运行中")
                print(f"  公网地址: {url}")
            except:
                print(f"  ngrok 隧道: ⚠️ 地址存在但无法访问")
                print(f"  上次地址: {url}")
        else:
            print(f"  ngrok 隧道: ❌ 未运行")
    else:
        print(f"  ngrok 隧道: ❌ 未运行")
    
    # PID 信息
    pids = load_pids()
    if pids:
        print(f"  进程 PID: {pids}")
    
    print("=" * 50)

def restart():
    """重启所有服务"""
    print("🔄 正在重启...")
    stop_all()
    time.sleep(2)
    start_server()
    url = start_tunnel()
    if url:
        print(f"\n🎉 重启成功！公网地址: {url}")
    else:
        print("\n❌ 重启失败")

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(0)
    
    cmd = sys.argv[1].lower()
    
    if cmd == 'start':
        print("🚀 启动本地服务器 + ngrok 隧道...")
        start_server()
        url = start_tunnel()
        if url:
            print(f"\n🎉 一键启动完成！")
            print(f"   本地: http://localhost:{DEFAULT_PORT}")
            print(f"   公网: {url}")
        else:
            print("\n❌ 启动失败，请检查网络和 authtoken")
    
    elif cmd == 'start-server':
        start_server()
    
    elif cmd == 'start-tunnel':
        url = start_tunnel()
        if url:
            print(f"公网地址: {url}")
    
    elif cmd == 'stop':
        stop_all()
    
    elif cmd == 'status':
        show_status()
    
    elif cmd == 'restart':
        restart()
    
    else:
        print(f"未知命令: {cmd}")
        print(__doc__)

if __name__ == '__main__':
    main()

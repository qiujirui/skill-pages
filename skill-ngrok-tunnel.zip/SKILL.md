---
name: ngrok-tunnel
description: "内网穿透，将本地服务暴露到公网。当用户提到'内网穿透'、'公网访问'、'外网访问'、'远程访问'、'ngrok'、'tunnel'、'让别人看到'、'外部访问'、'穿透到公网'时，使用本 Skill。"
version: 1.0.0
---

# ngrok-tunnel Skill

将本地 HTTP 服务通过 ngrok 暴露到公网，让外部用户可以通过公网 URL 访问本地页面。

## 前置依赖

- Python 3.x + pyngrok 包
- ngrok 账号 + authtoken（已配置在 config.env）
- 本地 HTTP 服务器（默认端口 8099）

## 安全特性

**本 Skill 使用安全 HTTP 服务器，默认启用以下防护：**

| 防护措施 | 说明 |
|----------|------|
| 禁止目录列表 | 访问文件夹不会显示文件列表（返回 403）|
| 白名单限制 | 只允许 HTML/CSS/JS/图片等媒体文件 |
| 黑名单过滤 | 禁止访问 .env, config, 密码文件等敏感文件 |
| 路径遍历防护 | 阻止 `../` 等方式访问上级目录 |

**允许的文件类型：** `.html`, `.htm`, `.css`, `.js`, `.json`, `.png`, `.jpg`, `.jpeg`, `.gif`, `.webp`, `.svg`, `.ico`, `.woff`, `.woff2`, `.ttf`, `.mp4`, `.webm`, `.mp3`, `.wav`, `.pdf`, `.txt`, `.xml`, `.md`

**禁止的文件类型：** `.py`, `.exe`, `.bat`, `.sh`, `.zip`, `.rar`, `.7z`, `.env` 等

## 使用流程

### 1. 一键启动

```bash
python scripts/tunnel.py start
```

自动完成：启动 HTTP 服务器 → 建立 ngrok 隧道 → 验证公网访问 → 输出公网地址

### 2. 仅启动服务器

```bash
python scripts/tunnel.py start-server
```

### 3. 仅启动隧道

```bash
python scripts/tunnel.py start-tunnel
```

### 4. 查看状态

```bash
python scripts/tunnel.py status
```

### 5. 重启

```bash
python scripts/tunnel.py restart
```

### 6. 停止

```bash
python scripts/tunnel.py stop
```

## 配置说明

| 配置项 | 位置 | 说明 |
|--------|------|------|
| AUTHTOKEN | config.env | ngrok authtoken，从 dashboard.ngrok.com 获取 |
| 默认端口 | 8099 | 本地 HTTP 服务器端口 |
| 根目录 | D:\WorkBuddyOutput | HTTP 服务器根目录 |

## 注意事项

- ngrok 免费版每次重启后公网地址会变
- 首次访问 ngrok 地址会出现"Visit Site"确认页，点击即可
- authtoken 失效时需重新配置 config.env
- 重启电脑后需要重新运行 `tunnel.py start`

## 故障排查

| 问题 | 原因 | 解决 |
|------|------|------|
| 隧道建立但无法访问 | 本地服务器未启动 | 先运行 `tunnel.py start-server` |
| authtoken 错误 | token 过期或格式错误 | 去 ngrok Dashboard 重新获取 |
| 端口被占用 | 8099 已有其他进程 | 修改脚本中的 DEFAULT_PORT |
| 访问出现 Visit Site 页面 | ngrok 免费版正常行为 | 点击确认即可 |

## 文件结构

```
ngrok-tunnel/
├── SKILL.md          # 技能说明
├── config.env        # authtoken 配置
└── scripts/
    └── tunnel.py     # 核心脚本
```

#!/usr/bin/env python3
"""
github-pages Skill 核心脚本
功能：通过 GitHub API 部署 HTML 页面到 GitHub Pages（无需安装 Git）

用法：
  python github_pages.py deploy <local_file> <remote_path>   # 上传单个文件
  python github_pages.py deploy-all                           # 上传所有 Skill 页面
  python github_pages.py create-repo                          # 创建仓库
  python github_pages.py enable-pages                         # 启用 GitHub Pages
  python github_pages.py status                               # 查看部署状态
  python github_pages.py list                                 # 列出仓库中的文件
  python github_pages.py delete <remote_path>                 # 删除远程文件
"""

import os
import sys
import json
import base64
import time
import requests
from pathlib import Path
from datetime import datetime

# ============ 配置 ============
CONFIG_FILE = os.path.join(os.path.dirname(__file__), "config.env")

def load_config():
    """从 config.env 读取配置"""
    config = {}
    if not os.path.exists(CONFIG_FILE):
        print("❌ 未找到 config.env，请创建并写入配置")
        sys.exit(1)
    with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                key, val = line.split('=', 1)
                config[key.strip()] = val.strip()
    
    required = ['GITHUB_USERNAME', 'GITHUB_TOKEN', 'REPO_NAME']
    for k in required:
        if k not in config:
            print(f"❌ config.env 缺少 {k}")
            sys.exit(1)
    return config

def get_headers(token):
    return {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json"
    }

def api_call(config, method, path, json_data=None, params=None, timeout=30):
    url = f"https://api.github.com{path}"
    headers = get_headers(config['GITHUB_TOKEN'])
    r = getattr(requests, method)(url, headers=headers, json=json_data, params=params, timeout=timeout)
    return r

def create_repo(config):
    """创建 GitHub 仓库"""
    print(f"📦 创建仓库 {config['GITHUB_USERNAME']}/{config['REPO_NAME']}...")
    
    r = api_call(config, "get", f"/repos/{config['GITHUB_USERNAME']}/{config['REPO_NAME']}")
    if r.status_code == 200:
        print("   ✅ 仓库已存在")
        return True
    
    r = api_call(config, "post", "/user/repos", {
        "name": config['REPO_NAME'],
        "description": "Skill showcase pages - powered by WorkBuddy",
        "public": True,
        "auto_init": True
    })
    
    if r.status_code == 201:
        print("   ✅ 仓库创建成功")
        return True
    else:
        print(f"   ❌ 创建失败: {r.status_code} {r.text[:200]}")
        return False

def enable_pages(config):
    """启用 GitHub Pages（从 main 分支直接部署，不用 workflow）"""
    print("🌐 启用 GitHub Pages...")
    
    # ⚠️ 重要：不能用 build_type: workflow，否则需要 .github/workflows/ 配置文件才能构建，会 404
    # 正确做法：直接从分支部署
    
    # 先删除旧配置（可能用了 workflow 模式）
    r = api_call(config, "delete", f"/repos/{config['GITHUB_USERNAME']}/{config['REPO_NAME']}/pages")
    
    # 重新创建，从 main 分支直接部署
    r = api_call(config, "post", f"/repos/{config['GITHUB_USERNAME']}/{config['REPO_NAME']}/pages", {
        "source": {"branch": "main", "path": "/"}
    })
    
    if r.status_code in [201, 202]:
        print("   ✅ GitHub Pages 已启用（从 main 分支直接部署）")
        return True
    elif r.status_code == 409:
        # Already exists, 先删再建
        api_call(config, "delete", f"/repos/{config['GITHUB_USERNAME']}/{config['REPO_NAME']}/pages")
        time.sleep(1)
        r = api_call(config, "post", f"/repos/{config['GITHUB_USERNAME']}/{config['REPO_NAME']}/pages", {
            "source": {"branch": "main", "path": "/"}
        })
        if r.status_code in [201, 202]:
            print("   ✅ GitHub Pages 已重新启用")
            return True
    
    print(f"   ⚠️ Pages 状态: {r.status_code} {r.text[:200]}")
    print("   你可以手动到 Settings > Pages 开启（选择 Deploy from branch > main）")
    return False

def upload_file(config, local_path, remote_path, commit_msg=None):
    """上传单个文件到 GitHub"""
    if not os.path.exists(local_path):
        print(f"   ❌ 文件不存在: {local_path}")
        return False
    
    with open(local_path, "rb") as f:
        content = base64.b64encode(f.read()).decode("utf-8")
    
    if not commit_msg:
        commit_msg = f"Update {remote_path} ({datetime.now().strftime('%Y-%m-%d %H:%M')})"
    
    # Check if file exists (get SHA)
    sha = None
    r = api_call(config, "get", f"/repos/{config['GITHUB_USERNAME']}/{config['REPO_NAME']}/contents/{remote_path}")
    if r.status_code == 200:
        sha = r.json().get("sha")
    
    data = {
        "message": commit_msg,
        "content": content,
        "branch": "main"
    }
    if sha:
        data["sha"] = sha
    
    r = api_call(config, "put", f"/repos/{config['GITHUB_USERNAME']}/{config['REPO_NAME']}/contents/{remote_path}", data, timeout=60)
    
    if r.status_code in [200, 201]:
        print(f"   ✅ {remote_path} 上传成功")
        return True
    else:
        print(f"   ❌ {remote_path} 上传失败: {r.status_code} {r.text[:200]}")
        return False

def upload_string(config, content_str, remote_path, commit_msg=None):
    """上传字符串内容到 GitHub"""
    content = base64.b64encode(content_str.encode("utf-8")).decode("utf-8")
    
    if not commit_msg:
        commit_msg = f"Update {remote_path} ({datetime.now().strftime('%Y-%m-%d %H:%M')})"
    
    sha = None
    r = api_call(config, "get", f"/repos/{config['GITHUB_USERNAME']}/{config['REPO_NAME']}/contents/{remote_path}")
    if r.status_code == 200:
        sha = r.json().get("sha")
    
    data = {
        "message": commit_msg,
        "content": content,
        "branch": "main"
    }
    if sha:
        data["sha"] = sha
    
    r = api_call(config, "put", f"/repos/{config['GITHUB_USERNAME']}/{config['REPO_NAME']}/contents/{remote_path}", data, timeout=60)
    
    if r.status_code in [200, 201]:
        print(f"   ✅ {remote_path} 上传成功")
        return True
    else:
        print(f"   ❌ {remote_path} 上传失败: {r.status_code} {r.text[:200]}")
        return False

def delete_file(config, remote_path):
    """删除远程文件"""
    r = api_call(config, "get", f"/repos/{config['GITHUB_USERNAME']}/{config['REPO_NAME']}/contents/{remote_path}")
    if r.status_code != 200:
        print(f"   ❌ 文件不存在: {remote_path}")
        return False
    
    sha = r.json().get("sha")
    data = {
        "message": f"Delete {remote_path}",
        "sha": sha,
        "branch": "main"
    }
    
    r = api_call(config, "delete", f"/repos/{config['GITHUB_USERNAME']}/{config['REPO_NAME']}/contents/{remote_path}", data)
    
    if r.status_code in [200, 204]:
        print(f"   ✅ {remote_path} 已删除")
        return True
    else:
        print(f"   ❌ 删除失败: {r.status_code} {r.text[:200]}")
        return False

def list_files(config, path=""):
    """列出仓库中的文件"""
    r = api_call(config, "get", f"/repos/{config['GITHUB_USERNAME']}/{config['REPO_NAME']}/contents/{path}")
    if r.status_code == 200:
        items = r.json()
        print(f"\n📂 /{path} 目录内容:")
        for item in items:
            icon = "📁" if item['type'] == 'dir' else "📄"
            size = f" ({item['size']} bytes)" if item['type'] == 'file' else ""
            print(f"   {icon} {item['name']}{size}")
    else:
        print(f"   ❌ 获取失败: {r.status_code}")

def show_status(config):
    """显示部署状态"""
    username = config['GITHUB_USERNAME']
    repo = config['REPO_NAME']
    
    print("=" * 50)
    print("  GitHub Pages 部署状态")
    print("=" * 50)
    
    # Check auth
    r = api_call(config, "get", "/user")
    if r.status_code == 200:
        print(f"  账号: ✅ {r.json().get('login')}")
    else:
        print(f"  账号: ❌ 认证失败")
        return
    
    # Check repo
    r = api_call(config, "get", f"/repos/{username}/{repo}")
    if r.status_code == 200:
        repo_data = r.json()
        print(f"  仓库: ✅ {username}/{repo}")
        print(f"  可见: {'公开' if repo_data.get('private') == False else '私有'}")
    else:
        print(f"  仓库: ❌ 不存在")
        return
    
    # Check Pages
    r = api_call(config, "get", f"/repos/{username}/{repo}/pages")
    if r.status_code == 200:
        pages = r.json()
        print(f"  Pages: ✅ 已启用")
        print(f"  URL:   {pages.get('html_url', 'N/A')}")
    else:
        print(f"  Pages: ❌ 未启用")
    
    print(f"\n  🔗 https://{username}.github.io/{repo}")
    print("=" * 50)

def deploy_all(config):
    """一键部署：创建仓库 + 上传所有页面 + 启用 Pages"""
    print("🚀 一键部署到 GitHub Pages...\n")
    
    # Step 1: Verify
    print("1. 验证凭证...")
    r = api_call(config, "get", "/user")
    if r.status_code != 200:
        print(f"   ❌ 认证失败: {r.text[:200]}")
        return
    print(f"   ✅ {r.json().get('login')}")
    
    # Step 2: Create repo
    print("\n2. 创建仓库...")
    create_repo(config)
    
    # Step 3: Find and upload HTML files
    print("\n3. 上传 Skill 页面...")
    output_dir = r"D:\WorkBuddyOutput\2026-04"
    if os.path.exists(output_dir):
        for f in os.listdir(output_dir):
            if f.endswith('-skill.html') or f == 'index.html':
                local = os.path.join(output_dir, f)
                upload_file(config, local, f)
    
    # Step 4: Upload/update index
    print("\n4. 更新首页...")
    index_html = generate_index(config)
    upload_string(config, index_html, "index.html", "Update index page")
    
    # Step 5: Enable Pages
    print("\n5. 启用 GitHub Pages...")
    time.sleep(2)
    enable_pages(config)
    
    print(f"\n🎉 部署完成！")
    print(f"   仓库: https://github.com/{config['GITHUB_USERNAME']}/{config['REPO_NAME']}")
    print(f"   页面: https://{config['GITHUB_USERNAME']}.github.io/{config['REPO_NAME']}")

def generate_index(config):
    """生成首页 HTML"""
    username = config['GITHUB_USERNAME']
    repo = config['REPO_NAME']
    
    # Scan for skill pages
    output_dir = r"D:\WorkBuddyOutput\2026-04"
    skills = []
    if os.path.exists(output_dir):
        for f in sorted(os.listdir(output_dir)):
            if f.endswith('-skill.html'):
                name = f.replace('-skill.html', '')
                skills.append({"file": f, "name": name})
    
    skill_cards = ""
    icons = {"zip-to-rar": "📦", "ngrok-tunnel": "🌐", "github-pages": "🚀"}
    descs = {
        "zip-to-rar": "文件打包转换技能，7-Zip + CloudConvert 自动化流程",
        "ngrok-tunnel": "内网穿透技能，本地服务一键暴露到公网",
        "github-pages": "GitHub Pages 部署技能，API 直推无需 Git",
    }
    
    for s in skills:
        icon = icons.get(s["name"], "⚡")
        desc = descs.get(s["name"], f'{s["name"]} Skill 展示页面')
        skill_cards += f"""
        <a class="card" href="{s['file']}">
            <div class="card-icon">{icon}</div>
            <div class="card-title">{s['name']}</div>
            <div class="card-desc">{desc}</div>
        </a>"""
    
    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Skill Showcase - WorkBuddy</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: #0f172a; color: #e2e8f0; min-height: 100vh;
            display: flex; align-items: center; justify-content: center;
        }}
        .container {{ max-width: 600px; width: 90%; text-align: center; padding: 3rem 0; }}
        h1 {{ font-size: 2.5rem; margin-bottom: 0.5rem; background: linear-gradient(135deg, #60a5fa, #a78bfa); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }}
        .subtitle {{ color: #94a3b8; margin-bottom: 3rem; font-size: 1.1rem; }}
        .card {{
            background: #1e293b; border: 1px solid #334155; border-radius: 16px;
            padding: 2rem; margin-bottom: 1.5rem; transition: all 0.3s;
            text-decoration: none; color: inherit; display: block;
        }}
        .card:hover {{ border-color: #60a5fa; transform: translateY(-4px); box-shadow: 0 8px 30px rgba(96,165,250,0.15); }}
        .card-icon {{ font-size: 2.5rem; margin-bottom: 1rem; }}
        .card-title {{ font-size: 1.3rem; font-weight: 600; margin-bottom: 0.5rem; }}
        .card-desc {{ color: #94a3b8; font-size: 0.95rem; }}
        .footer {{ margin-top: 3rem; color: #475569; font-size: 0.85rem; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>Skill Showcase</h1>
        <p class="subtitle">WorkBuddy 技能展示页面</p>
        {skill_cards}
        <p class="footer">Powered by WorkBuddy AI 🐾</p>
    </div>
</body>
</html>"""

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(0)
    
    config = load_config()
    cmd = sys.argv[1].lower()
    
    if cmd == "deploy" and len(sys.argv) >= 4:
        local_path = sys.argv[2]
        remote_path = sys.argv[3]
        upload_file(config, local_path, remote_path)
    
    elif cmd == "deploy-all":
        deploy_all(config)
    
    elif cmd == "create-repo":
        create_repo(config)
    
    elif cmd == "enable-pages":
        enable_pages(config)
    
    elif cmd == "status":
        show_status(config)
    
    elif cmd == "list":
        path = sys.argv[2] if len(sys.argv) > 2 else ""
        list_files(config, path)
    
    elif cmd == "delete" and len(sys.argv) >= 3:
        delete_file(config, sys.argv[2])
    
    elif cmd == "upload-str" and len(sys.argv) >= 4:
        upload_string(config, sys.argv[2], sys.argv[3])
    
    else:
        print(f"未知命令: {cmd}")
        print(__doc__)

if __name__ == '__main__':
    main()

---
name: github-pages
description: "GitHub Pages 部署技能，通过 GitHub API 直接推送页面到 GitHub Pages，无需安装 Git。当用户提到'部署到GitHub'、'GitHub Pages'、'推送到GitHub'、'部署页面'、'发布页面'、'上线'、'deploy'、'发布到线上'时，使用本 Skill。"
version: 1.0.0
---

# github-pages Skill

通过 GitHub API 直接推送 HTML 页面到 GitHub Pages，无需安装 Git。

## 前置依赖

- Python 3.x + requests 包
- GitHub 账号 + Personal Access Token（已配置在 config.env）
- Token 需要 `repo` 权限

## 使用流程

### 1. 一键部署所有页面

```bash
python scripts/github_pages.py deploy-all
```

自动完成：验证凭证 → 创建仓库 → 上传页面 → 更新首页 → 启用 Pages

### 2. 上传单个文件

```bash
python scripts/github_pages.py deploy <本地文件路径> <远程路径>
```

示例：
```bash
python scripts/github_pages.py deploy D:/WorkBuddyOutput/2026-04/my-page.html my-page.html
```

### 3. 创建仓库

```bash
python scripts/github_pages.py create-repo
```

### 4. 启用 GitHub Pages

```bash
python scripts/github_pages.py enable-pages
```

### 5. 查看状态

```bash
python scripts/github_pages.py status
```

### 6. 列出远程文件

```bash
python scripts/github_pages.py list
```

### 7. 删除远程文件

```bash
python scripts/github_pages.py delete <远程路径>
```

## 配置说明

| 配置项 | 位置 | 说明 |
|--------|------|------|
| GITHUB_USERNAME | config.env | GitHub 用户名 |
| GITHUB_TOKEN | config.env | Personal Access Token（需 repo 权限）|
| REPO_NAME | config.env | 仓库名称（默认 skill-pages）|

## 注意事项

- Token 失效时需重新生成，到 GitHub Settings > Developer settings > Personal access tokens
- GitHub Pages 构建需要 1-3 分钟生效
- 每次上传会自动检测文件是否存在，存在则更新
- 首页会自动扫描 Skill 页面并生成导航

## 故障排查

| 问题 | 原因 | 解决 |
|------|------|------|
| 401 认证失败 | Token 过期 | 重新生成 Token |
| 404 仓库不存在 | 未创建仓库 | 先运行 create-repo |
| Pages 404 访问不到 | build_type 用了 workflow（需 Actions 配置）| 确保从分支直接部署，运行 enable-pages 重新配置 |
| Pages 正在构建 | 构建需 1-3 分钟 | 等待后刷新 |
| 文件上传 409 | 并发冲突 | 稍后重试 |
| API 限流 | 请求频率过高 | 等待 1 小时后重试 |

## 踩坑经验

- **build_type 不能用 workflow**：`build_type: workflow` 需要 `.github/workflows/` 下的 Actions 配置文件，没有的话 Pages 永远不会构建（status 一直为 None），访问 404。正确做法是用 `source: {branch: main, path: /}` 从分支直接部署。
- **Pages 修改后需重新构建**：删除旧 Pages 配置 → 重新创建 → 等 1-3 分钟生效。

## 文件结构

```
github-pages/
├── SKILL.md              # 技能说明
├── config.env            # GitHub 凭证配置
└── scripts/
    └── github_pages.py   # 核心脚本
```

## 与其他 Skill 配合

- **zip-to-rar** / **ngrok-tunnel**：制作完 Skill 介绍页面后，用本 Skill 部署到 GitHub Pages
- **ngrok-tunnel**：临时预览用 ngrok，正式发布用 GitHub Pages
